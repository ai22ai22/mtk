package com.mediatek.iot.data.bt;

import com.mediatek.iot.data.BaseData;
import com.mediatek.iot.data.DataParser;
import com.mediatek.iot.utils.DataConverter;
import java.io.IOException;

public class BTDataParser extends DataParser {
  private static final int PACKAGE_LENGTH = 64;
  byte[] packageData = new byte[PACKAGE_LENGTH];
  int packageDataIndex = 0;

  @Override protected BaseData parseData(byte[] data) {
    int[] rawData = bytesToIntArray(data);
    switch (rawData[1]) {
      case 0: {
        return new AccData(rawData);
      }
      case 5: {
        return new EKGData(rawData);
      }
      case 9: {
        return new PPG1Data(rawData);
      }
      case 12: {
        return new PPG1_512Data(rawData);
      }
      case 13: {
        return new PedometerData(rawData);
      }
      case 22: {
        return new HeartRateData(rawData);
      }
      case 23: {
        return new HRVData(rawData);
      }
      case 24: {
        return new BloodPressureData(rawData);
      }
      case 8001: {
        return new PWTTData(rawData);
      }
      case 3001:{
        return new ReturnData(rawData);
      }
      default: {
        return new UnknownData(rawData);
      }
    }
  }

  @Override public void receiveData(byte[] buffer) throws IOException {
    for (int i = 0; i < buffer.length; ) {
      int j = Math.min(buffer.length, i + PACKAGE_LENGTH - packageDataIndex);
      System.arraycopy(buffer, i, packageData, packageDataIndex, j - i);
      packageDataIndex += j - i;
      i = j;
      if (packageDataIndex == PACKAGE_LENGTH) {
        byte[] temp = new byte[PACKAGE_LENGTH];
        System.arraycopy(packageData, 0, temp, 0, PACKAGE_LENGTH);
        postData(temp);
        packageDataIndex = 0;
      }
    }
  }

  @Override public void reset() {
    packageDataIndex = 0;
  }

  private static int[] bytesToIntArray(byte[] bytes) {
    int[] result = new int[bytes.length / 4];
    int data_length = bytes.length;
    int i = 0;
    int j = 0;
    while (j + 4 <= data_length) {
      result[i ++] = (bytes[j++] & 0xFF)
          |( (bytes[j++] & 0xFF) << 8)
          |( (bytes[j++] & 0xFF) << 16)
          |( (bytes[j++] & 0xFF) << 24);
    }
    return result;
  }
}
