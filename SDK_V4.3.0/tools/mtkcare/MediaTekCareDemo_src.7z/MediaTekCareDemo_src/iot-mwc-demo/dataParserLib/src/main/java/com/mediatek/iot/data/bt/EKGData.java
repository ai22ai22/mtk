package com.mediatek.iot.data.bt;

public class EKGData extends BTBaseData {

  public EKGData(int[] rawData) {
    super(rawData);
  }

  public int[] getEkgData(){
    int[] data = new int[12];
    System.arraycopy(rawData, 3, data,0, 12);
    return data;
  }
}
