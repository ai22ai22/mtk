package com.mediatek.iot.data.bt;

public class HRVData extends BTBaseData {
  public static final int INDEX_SDNN = 3;
  public static final int INDEX_LF = 4;
  public static final int INDEX_HF = 5;
  public static final int INDEX_LF_HF = 6;
  public static final int INDEX_HR_BPM = 7;
  public static final int INDEX_STATUS = 8;

  public HRVData(int[] rawData) {
    super(rawData);
  }
}
