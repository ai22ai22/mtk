package com.mediatek.iot.data.bt;

public class ReturnData extends BTBaseData {

  public ReturnData(int[] rawData) {
    super(rawData);
  }
  public int getResponseCode(){
    return rawData[3];
  }


}
