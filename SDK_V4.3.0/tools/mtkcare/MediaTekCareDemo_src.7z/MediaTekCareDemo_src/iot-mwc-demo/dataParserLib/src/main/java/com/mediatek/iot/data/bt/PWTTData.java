package com.mediatek.iot.data.bt;

import java.util.ArrayList;

public class PWTTData extends BTBaseData {
  public PWTTData(int[] rawData)  {
    super(rawData);
  }
  public Integer[] getPWTT(){
    ArrayList<Integer> list = new ArrayList<>();
    for(int i = 6; i < rawData.length ; ++i){
      if(rawData[i] == 12345 | rawData[i] == 54321){
        break;
      }
      list.add(rawData[i]);
    }
    return list.toArray(new Integer[list.size()]);
  }

}
