package com.mediatek.iot.data.bt;

public class PPG1Data extends BTBaseData {

  public PPG1Data(int[] rawData)  {
    super(rawData);
  }

  public int[] getPPGData(){
    //3-14
    int[] data = new int[12];
    System.arraycopy(rawData, 3, data,0, 12);
    return data;
  }
}
