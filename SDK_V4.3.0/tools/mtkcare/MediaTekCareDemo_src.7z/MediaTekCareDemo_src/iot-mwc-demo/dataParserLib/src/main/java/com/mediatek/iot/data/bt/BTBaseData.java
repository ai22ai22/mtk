package com.mediatek.iot.data.bt;

import com.mediatek.iot.data.BaseData;
import com.mediatek.iot.utils.DataConverter;

public abstract class BTBaseData extends BaseData {
  public static final int INDEX_MAGIC = 0;
  public static final int INDEX_SENSOR_TYPE = 1;
  public static final int FEATURE_TYPE = 3;
  public static final int INDEX_SEQUENCE = 2;

  public static final int INDEX_STATUS = 4;

  public static final int SENSOR_TYPE_ECG = 5;
  public static final int SENSOR_TYPE_PPG_3 = 12;
  public static final int SENSOR_TYPE_PPG_9 = 9;
  public static final int SENSOR_TYPE_HR = 22;
  public static final int SENSOR_TYPE_HRV = 23;
  public static final int SENSOR_TYPE_ACCELEROMETER = 0;
  public static final int SENSOR_TYPE_PEDOMETER = 13;
  public static final int SENSOR_TYPE_PWTT = 8001;
  public static final int SENSOR_TYPE_BLOOD_PRESSURE = 24;
  protected int[] rawData;

  public BTBaseData(int[] rawData) {
    super();
    this.rawData = rawData;
  }

  public int[] getRawData() {
    return rawData;
  }

  public int get(int index) {
    return rawData[index];
  }

  @Override public String toString() {
    return getClass().getSimpleName() + ":" + DataConverter.intArrayToString(rawData, 0);
  }
}
