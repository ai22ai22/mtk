package com.mediatek.iot.data.bt;

public class UnknownData extends BTBaseData {

  public UnknownData(int[] rawData) {
    super(rawData);
  }
}
