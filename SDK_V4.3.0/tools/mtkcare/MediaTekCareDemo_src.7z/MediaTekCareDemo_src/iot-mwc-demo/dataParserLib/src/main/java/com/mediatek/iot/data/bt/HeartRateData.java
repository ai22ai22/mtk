package com.mediatek.iot.data.bt;

public class HeartRateData extends BTBaseData {
  public static final int FIELD_BPM = 3;
  public static final int FIELD_STATUS = 4;
  public static final int FIELD_TIMESTAMP = 5;

  public HeartRateData(int[] rawData) {
    super(rawData);
  }
}
