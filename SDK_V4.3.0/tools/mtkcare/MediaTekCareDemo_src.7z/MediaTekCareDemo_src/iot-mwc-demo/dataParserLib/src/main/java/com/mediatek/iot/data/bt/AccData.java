package com.mediatek.iot.data.bt;

public class AccData extends BTBaseData {

  public AccData(int[] rawData) {
    super(rawData);
  }
  //index :0-2
  public AccItem getAccItem(int index){
    int i = index * 4 + 3;
    return new AccItem(rawData[i],rawData[i +1], rawData[i+2], rawData[i+3]);
  }

  public static class AccItem {
    private final int timestamp;
    private final int x;
    private final int y;
    private final int z;

    public AccItem(int x, int y, int z, int timestamp) {
      this.x = x;
      this.y = y;
      this.z = z;
      this.timestamp = timestamp;
    }

    public int getTimestamp() {
      return timestamp;
    }

    public int getX() {
      return x;
    }

    public int getY() {
      return y;
    }

    public int getZ() {
      return z;
    }
  }
}
