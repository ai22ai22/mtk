package com.mediatek.iot.command.bt;

import com.mediatek.iot.utils.DataConverter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class SetProfileFieldCommand extends BTBaseCommand {
  public static final int SENSOR_TYPE = 3001;
  private String userId;
  private int height;
  private int weight;
  private int gender;
  private int age;
  private int handLen;
  private SetProfileFieldCommand(Builder builder) {
    super(SENSOR_TYPE);
    userId = builder.userId;
    height = builder.height;
    weight = builder.weight;
    age = builder.age;
    handLen = builder.handLen;
    gender = builder.gender;
  }
  private static SetProfileFieldCommand create(Builder builder){
    return new SetProfileFieldCommand(builder);
  }
   public byte[] toBytes() {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    //length
    byteArrayOutputStream.write(0);
    try {
      byteArrayOutputStream.write(DataConverter.intToBytes(SENSOR_TYPE));
      //userid
      byteArrayOutputStream.write(0x01);
      byte[] data = userId.getBytes();
      byteArrayOutputStream.write(data.length);
      byteArrayOutputStream.write(data);
      //height
      byteArrayOutputStream.write(0x02);
      byteArrayOutputStream.write(4);
      byteArrayOutputStream.write(DataConverter.intToBytes(height));
      //weight
      byteArrayOutputStream.write(0x03);
      byteArrayOutputStream.write(4);
      byteArrayOutputStream.write(DataConverter.intToBytes(weight));
      //gender
      byteArrayOutputStream.write(0x04);
      byteArrayOutputStream.write(4);
      byteArrayOutputStream.write(DataConverter.intToBytes(gender));
      //age
      byteArrayOutputStream.write(0x05);
      byteArrayOutputStream.write(4);
      byteArrayOutputStream.write(DataConverter.intToBytes(age));

      //gendor
      byteArrayOutputStream.write(0x06);
      byteArrayOutputStream.write(4);
      byteArrayOutputStream.write(DataConverter.intToBytes(handLen));


    } catch (IOException e) {
      e.printStackTrace();
    }

    byte[] commandBytes = byteArrayOutputStream.toByteArray();
    commandBytes[0] = (byte) (commandBytes.length & 0xff);
    return commandBytes;
  }

  @Override public InputStream getInputStream() {
    return new ByteArrayInputStream(toBytes());
  }

  public static class Builder{
    private String userId;
    private int height;
    private int weight;
    private int gender;
    private int age;
    private int handLen;

    public Builder(){

    }
    public Builder setUserId(String userId){
      this.userId = userId;
      return this;
    }
    public Builder setHeight(int height){
      this.height = height;
      return this;
    }

    public Builder setWeight(int weight){
      this.weight = weight;
      return this;
    }
    public Builder setGender(int genderFlag){
      this.gender = genderFlag;
      return this;
    }
    public Builder setAge(int age){
      this.age = age;
      return this;
    }
    public Builder setHandLen(int handLen){
      this.handLen = handLen;
      return this;
    }

    public SetProfileFieldCommand create(){
      return SetProfileFieldCommand.create(this);
    }
  }
}
