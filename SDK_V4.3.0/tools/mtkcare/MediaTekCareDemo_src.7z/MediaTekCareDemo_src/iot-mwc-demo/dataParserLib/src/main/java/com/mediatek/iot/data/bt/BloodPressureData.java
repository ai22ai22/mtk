package com.mediatek.iot.data.bt;

public class BloodPressureData extends BTBaseData {
  public static final int FIELD_SBP = 3;
  public static final int FIELD_DBP = 4;
  public static final int FIELD_HR_BPM = 5;

  public BloodPressureData(int[] rawData) {
    super(rawData);
  }
}
