package com.mediatek.iot.command.bt;

import com.mediatek.iot.command.BaseCommand;
import com.mediatek.iot.data.BaseData;
import com.mediatek.iot.data.bt.ReturnData;

public abstract class BTBaseCommand extends BaseCommand {

  private final int commandId;

  public BTBaseCommand(int commandId){
    this.commandId = commandId;
  }


  @Override public boolean isResponseData(BaseData baseData) {
    if(baseData instanceof ReturnData){
      ReturnData returnData = (ReturnData) baseData;
      return returnData.get(ReturnData.INDEX_SENSOR_TYPE) == commandId;
    }
    return false;
  }

  @Override public boolean isOKResponse(BaseData baseData) {
    if (!isResponseData(baseData)){
      return false;
    }
    ReturnData returnData = (ReturnData) baseData;
    return returnData.getResponseCode() == 0;
  }
}
