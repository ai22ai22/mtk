package com.mediatek.iot.data.bt;

public class PedometerData extends BTBaseData {
  public static final int INDEX_STEP_COUNT = 3;
  public static final int INDEX_STEP_TYPE = 4;

  public PedometerData(int[] rawData) {
    super(rawData);
  }
}
