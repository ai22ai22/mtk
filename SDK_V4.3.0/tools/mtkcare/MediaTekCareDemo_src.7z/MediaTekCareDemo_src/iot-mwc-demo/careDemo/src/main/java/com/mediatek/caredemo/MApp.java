package com.mediatek.caredemo;

import com.mediatek.mt2511.AppConstants;
import com.mediatek.mt2511.MBaseApp;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.branch.IMContext;
import com.mediatek.mt2511.fragments.AddRecordFragment;
import com.mediatek.mt2511.fragments.BPMeasureFragment;
import com.mediatek.mt2511.fragments.BPMeasurePersonalFragment;
import com.mediatek.mt2511.fragments.FormFragment;
import com.mediatek.mt2511.fragments.GeneralBPMeasureFragment;
import io.realm.Realm;
import io.realm.RealmConfiguration;

public class MApp extends MBaseApp {
  @Override public void onCreate() {
    super.onCreate();
    Realm.init(this);
    RealmConfiguration config =
        new RealmConfiguration.Builder().deleteRealmIfMigrationNeeded().build();
    Realm.setDefaultConfiguration(config);
    MContext.getInstance().init(this, new IMContext() {
      @Override public String getEndPoint() {
        return MContext.getInstance().getApplication().getString(R.string.conf_api_end_point);
      }

      @Override public String getApplicationId() {
        return BuildConfig.APPLICATION_ID;
      }

      @Override public String[] getFeatureFragment() {
        return new String[] {
            AppConstants.FRAGMENT_MEASURE, AppConstants.FRAGMENT_HRV,
            GeneralBPMeasureFragment.class.getName(), BPMeasurePersonalFragment.class.getName(),
            //  AppConstants.FRAGMENT_BP_MEASURE,
            AppConstants.FRAGMENT_REPORTS
        };
      }

      @Override public boolean isSelfSignedCA() {
        return MContext.getInstance()
            .getApplication()
            .getResources()
            .getBoolean(R.bool.conf_import_self_signed_ca);
      }

      @Override public FormFragment[] createAddRecordFragments() {
        return new FormFragment[] { new AddRecordFragment() };
      }

      @Override public boolean isForceAddRecord() {
        return false;
      }
    });
  }
}
