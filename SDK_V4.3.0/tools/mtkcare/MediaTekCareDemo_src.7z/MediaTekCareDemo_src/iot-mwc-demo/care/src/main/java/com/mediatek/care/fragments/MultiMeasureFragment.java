package com.mediatek.care.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.mediatek.mt2511.AppConstants;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.activities.BLEDeviceSelectActivity;
import com.mediatek.mt2511.fragments.MeasureFragment;

/**
 * Created by MTK40526 on 4/26/2016.
 */
public class MultiMeasureFragment extends MeasureFragment {
  public MultiMeasureFragment() {
    super();
    setTitle(MContext.getInstance().getApplication().getString(R.string.multi_connect));
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = super.onCreateView(inflater, container, savedInstanceState);

    Intent intent = new Intent(getActivity(), BLEDeviceSelectActivity.class);
    getActivity().startActivityForResult(intent, AppConstants.REQUEST_BLE);
    return view;
  }
}
