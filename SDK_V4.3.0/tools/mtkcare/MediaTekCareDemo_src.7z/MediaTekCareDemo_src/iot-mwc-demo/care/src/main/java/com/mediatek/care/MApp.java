package com.mediatek.care;

import com.mediatek.mt2511.fragments.BPMeasureFragment;
import com.mediatek.care.fragments.MultiMeasureFragment;
import com.mediatek.mt2511.AppConstants;
import com.mediatek.mt2511.MBaseApp;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.branch.IMContext;
import com.mediatek.mt2511.fragments.AddRecordFragment;
import com.mediatek.mt2511.fragments.FormFragment;
import com.mediatek.mt2511.fragments.QuesFragment;

public class MApp extends MBaseApp {
  @Override public void onCreate() {
    super.onCreate();
    MContext.getInstance().init(this, new IMContext() {
      @Override public String getEndPoint() {
        return MContext.getInstance().getApplication().getString(R.string.conf_api_end_point);
      }

      @Override public String getApplicationId() {
        return BuildConfig.APPLICATION_ID;
      }

      @Override public String[] getFeatureFragment() {
        return new String[] {
            AppConstants.FRAGMENT_MEASURE, AppConstants.FRAGMENT_HRV,
            BPMeasureFragment.class.getName(), AppConstants.FRAGMENT_REPORTS,
            MultiMeasureFragment.class.getName()
        };
      }

      @Override public boolean isSelfSignedCA() {
        return MContext.getInstance()
            .getApplication()
            .getResources()
            .getBoolean(R.bool.conf_import_self_signed_ca);
      }

      @Override public FormFragment[] createAddRecordFragments() {
        return new FormFragment[] { new AddRecordFragment(), new QuesFragment() };
      }

      @Override public boolean isForceAddRecord() {
        return true;
      }
    });
  }
}
