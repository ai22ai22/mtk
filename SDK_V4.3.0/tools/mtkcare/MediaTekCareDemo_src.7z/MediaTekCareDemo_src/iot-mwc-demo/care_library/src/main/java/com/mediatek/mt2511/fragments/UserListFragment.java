package com.mediatek.mt2511.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.interfaces.Titled;
import com.mediatek.mt2511.models.PersonalProfileEntity;
import com.mediatek.mt2511.presentation.UserListFragmentPresenter;
import io.realm.RealmResults;
import java.util.ArrayList;
import java.util.HashMap;

public class UserListFragment extends Fragment implements Titled{

  private View mBtnCreatePersonalModel;
  private ListView mListView;
  private ArrayList<HashMap<String, String>> personalModels;
  private UserListFragmentPresenter presenter;

  public UserListFragment() {
    presenter = new UserListFragmentPresenter();
    presenter.setView(this);
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_user_list, container, false);
    initView(view);
    initEvents(view);
    return view;
  }

  private void initEvents(View view) {
    mBtnCreatePersonalModel.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View view) {
        ((BPMeasurePersonalFragment)getParentFragment()).showCalibration();
      }
    });
    mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
      @Override public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String sId = personalModels.get(position).get("id");
        ((BPMeasurePersonalFragment)getParentFragment()).showApplyPersonalFragment(sId);
      }
    });
  }

  private void initView(View view) {
    mBtnCreatePersonalModel = view.findViewById(R.id.btn_create_personal_model);
    mListView = (ListView) view.findViewById(R.id.list_personal_model);
    personalModels = new ArrayList<>();
    RealmResults<PersonalProfileEntity> items = presenter.getAllPersonalModel();
    for (PersonalProfileEntity entity : items) {
      HashMap<String, String> item = new HashMap<>();
      item.put("text", entity.getUserId());
      item.put("id", entity.getId());
      personalModels.add(item);
    }
    SimpleAdapter simpleAdapter =
        new SimpleAdapter(getContext(), personalModels, R.layout.list_item_personal_model,
            new String[] { "text" }, new int[] { android.R.id.text1 });
    mListView.setAdapter(simpleAdapter);
  }

  @Override public String getTitle() {
    return MContext.getInstance().getApplication().getString(R.string.user_list);
  }

  @Override public boolean isActive() {
    return false;
  }
}
