package com.mediatek.mt2511.models.pojo;

public class CareLoginResponse {
  public String authToken;
}
