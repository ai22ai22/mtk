package com.mediatek.mt2511.jni;

public class JniUtils {
  //static {
  //  System.loadLibrary("demoKit-jni");
  //}
  //public static native int get_fatigue_index_from_hrv(float lf,float hf);
  //public static native int get_pressure_index_from_sdnn(float sdnn, float age);

  public static int get_fatigue_index_from_hrv(float lf, float hf) {
    float total_energy;
    int fatigue_index;
    total_energy = (lf + hf - 330) / 10 + 50;
    if (total_energy > 92) {
      total_energy = 92;
    }
    if (total_energy < 12) {
      total_energy = 12;
    }
    fatigue_index = 100 - (int) total_energy;
    return fatigue_index;
  }

  public static int get_pressure_index_from_sdnn(float sdnn, float age) {
    float SDNN_a = (float) -1.04;
    float SDNN_b = (float) 80.4;
    int pressure_index;
    int sdnn_index;
    sdnn_index = (int) (((sdnn - (SDNN_a * age + SDNN_b))) + 50);
    if (sdnn_index > 92) {
      sdnn_index = 92;
    }
    if (sdnn_index < 13) {
      sdnn_index = 13;
    }
    pressure_index = 100 - sdnn_index;
    return pressure_index;
  }
}
