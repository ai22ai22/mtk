package com.mediatek.mt2511.fragments;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.jni.JniUtils;

/**
 * Created by MTK40526 on 3/29/2016.
 */
public class HRVResultFragment extends Fragment {
  TextView mTxtSDNN;
  TextView mTxtHF;
  TextView mTxtLF;
  TextView mTxtLFHF;
  TextView mTxtPressure;
  TextView mTxtFatigue;
  private float mSDNN;
  private int mAge;
  private float mLF;
  private float mHF;
  private float mLFHF;
  private int mHR;

  public HRVResultFragment() {
    super();
  }

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    if (savedInstanceState == null) {
      savedInstanceState = getActivity().getIntent().getExtras();
    }
    mAge = savedInstanceState.getInt("age");
    mSDNN = savedInstanceState.getFloat("sdnn");
    mLF = savedInstanceState.getFloat("lf");
    mHF = savedInstanceState.getFloat("hf");
    mLFHF = savedInstanceState.getFloat("lfhf");
    mHR = savedInstanceState.getInt("hr");
  }

  @Nullable @Override public View onCreateView(LayoutInflater inflater, ViewGroup container,
      Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_hrv_result, container, false);
    initView(view);
    mTxtSDNN.setText(String.format("%.3f", mSDNN));
    mTxtHF.setText(String.format("%.3f", mHF));
    mTxtLF.setText(String.format("%.3f", mLF));
    mTxtLFHF.setText(String.format("%.3f", mLFHF));

    int pressure = JniUtils.get_pressure_index_from_sdnn(mSDNN, mAge);
    int fatigue = JniUtils.get_fatigue_index_from_hrv(mLF, mHF);

    mTxtPressure.setText(String.format("%d", pressure));
    mTxtPressure.setTextColor(getValueColor(pressure));

    mTxtFatigue.setText(String.format("%d", fatigue));
    mTxtFatigue.setTextColor(getValueColor(fatigue));

    return view;
  }

  private void initView(View view) {
    mTxtSDNN = (TextView) view.findViewById(R.id.txt_sdnn);
    mTxtHF = (TextView) view.findViewById(R.id.txt_hf);
    mTxtLF = (TextView) view.findViewById(R.id.txt_lf);
    mTxtLFHF = (TextView) view.findViewById(R.id.txt_lfhf);
    mTxtPressure = (TextView) view.findViewById(R.id.txt_pressure);
    mTxtFatigue = (TextView) view.findViewById(R.id.txt_fatigue);
  }

  private int getValueColor(int percent) {
    if (percent < 40) {
      return 0xFF555555;
    } else if (percent < 60) {
      return 0xFFf59b00;
    } else if (percent < 80) {
      return 0xFFea7b00;
    } else {
      return 0xFFeb5638;
    }
  }
}
