package com.mediatek.mt2511.logs;

import com.mediatek.mt2511.MContext;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by MTK40526 on 6/21/2016.
 */
public class AddNoteLog {
  private static final String TAG = "AddNoteLog";
  private static AddNoteLog instance = null;
  private final File mFile;

  public AddNoteLog(String userId, String age, String height, String weight, String armLen) {
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
    String fileName = dateFormat.format(new Date()) + "_" + userId + "_bp.txt";
    fileName = fileName.replaceAll("[\\\\\\/\\:\\?\\*]", "_");
    mFile = new File(MContext.getInstance().getLogPath() + "/" + fileName);
    try {
      writeLine(String.format("%s,%s,%s,%s", age, height, weight, armLen));
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public static void init(String userId, String age, String height, String weight, String armLen,String sex) {
    instance = new AddNoteLog(userId, age, height, weight, armLen);
  }

  public static AddNoteLog getCurrent() {
    return instance;
  }

  public void writeLine(String v1) throws IOException {
    File dir = mFile.getParentFile();
    if(!dir.exists()){
      dir.mkdirs();
    }
    FileWriter fileWriter = new FileWriter(mFile, true);
    fileWriter.write(v1);
    fileWriter.write("\r\n");
    fileWriter.close();
  }

  public File getFile() {
    return mFile;
  }
}
