package com.mediatek.mt2511.views.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.SleepContent.Stage;
import com.mediatek.mt2511.utils.UIUtils;
import java.util.Locale;

public class SleepStatusTitle extends LinearLayout {

  TextView tv_status_label;

  public SleepStatusTitle(Context context) {
    super(context);
    initViews();
  }

  public SleepStatusTitle(Context context, AttributeSet attrs) {
    super(context, attrs);
    initViews();
  }

  public SleepStatusTitle(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    initViews();
  }

  public void setTitle(Stage stage) {
    tv_status_label.setText(String.format(Locale.getDefault(), "%s%d%%", stage.getStageText(),
        UIUtils.roundDown(stage.getPercentage())));
  }

  private void initViews() {
    View view = inflate(getContext(), R.layout.widget_sleep_status_title, this);
    tv_status_label = (TextView) view.findViewById(R.id.tv_status_label);
  }
}
