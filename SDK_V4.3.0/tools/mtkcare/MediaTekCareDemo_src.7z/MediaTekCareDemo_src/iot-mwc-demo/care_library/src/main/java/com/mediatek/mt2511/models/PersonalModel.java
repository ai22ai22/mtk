package com.mediatek.mt2511.models;

import android.content.Context;
import com.mediatek.mt2511.MContext;
import io.realm.Realm;
import io.realm.RealmResults;

public class PersonalModel {
  private static PersonalModel instance;
  private Context context;
  private PersonalProfileEntity defaultProfile;

  private PersonalModel() {
    context = MContext.getInstance().getApplication();
  }

  public static PersonalModel getDefault() {
    if (instance == null) {
      instance = new PersonalModel();
    }
    return instance;
  }

  public LastInputEntity getLastInput() {
    Realm realm = Realm.getDefaultInstance();
    LastInputEntity entity = realm.where(LastInputEntity.class).findFirst();
    if (entity != null) {
      return entity;
    }
    return new LastInputEntity();
  }

  public void saveInput(LastInputEntity lastInputEntity) {
    Realm realm = Realm.getDefaultInstance();
    realm.beginTransaction();
    realm.copyToRealmOrUpdate(lastInputEntity); // Persist unmanaged objects
    realm.commitTransaction();
  }

  public void saveNewProfile(PersonalProfileEntity personalProfileEntity){
    Realm realm = Realm.getDefaultInstance();
    realm.beginTransaction();
    realm.copyToRealmOrUpdate(personalProfileEntity); // Persist unmanaged objects
    realm.commitTransaction();
  }

  public RealmResults<PersonalProfileEntity> getAllPersonalModel(){
    Realm realm = Realm.getDefaultInstance();
    return realm.where(PersonalProfileEntity.class).findAll();
  }

  public PersonalProfileEntity loadById(String id){
    Realm realm = Realm.getDefaultInstance();

    PersonalProfileEntity result =
        realm.where(PersonalProfileEntity.class).equalTo("id", id).findFirst();
    return result;
  }

  public void setDefaultProfile(PersonalProfileEntity defaultProfile){
    this.defaultProfile = defaultProfile;
  }
  public PersonalProfileEntity getDefaultProfile(){
    return defaultProfile;
  }
}
