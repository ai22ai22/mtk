package com.mediatek.mt2511.logs;

import android.util.Log;
import com.mediatek.mt2511.BuildConfig;
import com.mediatek.mt2511.MContext;
import java.io.IOException;
import timber.log.Timber;

public class CrashReportingDebugTree extends Timber.DebugTree {
  private static final String LOG_PATTERN = "%s %d/%s:%s";
  private LogToFileService toFileService = new LogToFileService(new FileNameGenerator() {
    @Override public String generate() {
      String fileName =
          LogUtils.format(System.currentTimeMillis()).replaceAll("[\\:\\/]", "_") + ".txt";
      return LogUtils.getExternalStorageDir()
          + "/mtklog/"
          + MContext.getInstance().getApplicationId()
          + "/"
          + fileName;
    }
  });

  public CrashReportingDebugTree() {
    super();
    toFileService.start();
  }

  @Override protected void log(int priority, String tag, String message, Throwable t) {
    super.log(priority, tag, message, t);
    String log =
        String.format(LOG_PATTERN, LogUtils.format(System.currentTimeMillis()), priority,
            tag, message);
    try {
      toFileService.reciveLog(log);
    } catch (IOException e) {
      Log.e("Timber", e.getMessage(), e);
    }
  }
}