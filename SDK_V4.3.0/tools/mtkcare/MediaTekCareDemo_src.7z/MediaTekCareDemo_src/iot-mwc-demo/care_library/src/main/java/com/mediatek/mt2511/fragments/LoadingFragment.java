package com.mediatek.mt2511.fragments;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.mediatek.mt2511.R;

/**
 * Created by MTK40526 on 3/8/2016.
 */
public class LoadingFragment extends BaseFragment {
  public static final String TAG = "LoadingFragment";

  @Override public void onDestroy() {
    super.onDestroy();
  }

  @Override public void onResume() {
    super.onResume();
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_loading, container, false);
    ImageView iv = (ImageView) view.findViewById(R.id.loading_bar);
    AnimationDrawable animationDrawable = (AnimationDrawable) iv.getDrawable();
    animationDrawable.start();
    return view;
  }
}
