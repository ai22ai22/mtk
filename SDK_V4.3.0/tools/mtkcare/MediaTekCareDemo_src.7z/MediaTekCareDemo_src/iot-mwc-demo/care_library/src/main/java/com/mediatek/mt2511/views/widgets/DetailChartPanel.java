package com.mediatek.mt2511.views.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.SleepContent;
import com.mediatek.mt2511.views.chart.SleepStagesChart;

public class DetailChartPanel extends LinearLayout {

  SleepStagesChart chart_stages;
  TextView tv_detail_efficiency;
  TextView tv_detail_duration;

  public DetailChartPanel(Context context) {
    super(context);
    initViews();
  }

  public DetailChartPanel(Context context, AttributeSet attrs) {
    super(context, attrs);
    initViews();
  }

  public DetailChartPanel(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    initViews();
  }

  private void initViews() {
    View view = inflate(getContext(), R.layout.detail_chart_panel, this);

    chart_stages = (SleepStagesChart) findViewById(R.id.chart_stages);
    tv_detail_efficiency = (TextView) findViewById(R.id.tv_detail_efficiency);
    tv_detail_duration = (TextView) findViewById(R.id.tv_detail_duration);
  }

  public void setSleepContent(SleepContent content) {
    tv_detail_efficiency.setText(String.valueOf(content.getEfficiency()));
    tv_detail_duration.setText(content.getDuration().toDurationString());
    chart_stages.setChartData(content.getChartData());
  }
}
