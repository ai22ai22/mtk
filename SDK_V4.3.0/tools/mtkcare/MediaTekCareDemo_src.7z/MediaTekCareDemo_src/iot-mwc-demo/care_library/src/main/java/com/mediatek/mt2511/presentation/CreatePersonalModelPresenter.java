package com.mediatek.mt2511.presentation;

import com.mediatek.mt2511.models.ApiModel;
import com.mediatek.mt2511.models.BTCommandModel;
import com.mediatek.mt2511.models.LastInputEntity;
import com.mediatek.mt2511.models.PersonalModel;
import com.mediatek.mt2511.models.PersonalProfileEntity;
import com.mediatek.mt2511.views.CreatePersonalDialog;
import rx.Observable;

public class CreatePersonalModelPresenter implements Presenter<CreatePersonalDialog> {

  private final PersonalModel personalModel;
  private final BTCommandModel btCommandModel;
  private ApiModel apiModel = new ApiModel();

  public CreatePersonalModelPresenter(PersonalModel personalModel, BTCommandModel btCommandModel) {
    this.personalModel = personalModel;
    this.btCommandModel = btCommandModel;
  }


  @Override public void setView(CreatePersonalDialog view) {

  }

  public LastInputEntity getLastInput() {
    return personalModel.getLastInput();
  }

  public void saveInput(LastInputEntity lastInputEntity) {
    personalModel.saveInput(lastInputEntity);
  }

  public Observable<String> writeProfile(PersonalProfileEntity personalProfileEntity) {
    Observable<String> ob1 = btCommandModel.writeProfile(personalProfileEntity);
    Observable<String> ob2 = apiModel.requestApi(personalProfileEntity);
    return Observable.concat(ob1, ob2);
  }
}
