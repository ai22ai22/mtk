package com.mediatek.mt2511.exceptions;

public class AbortException extends Exception {
  public AbortException(String message) {
    super(message);
  }
}
