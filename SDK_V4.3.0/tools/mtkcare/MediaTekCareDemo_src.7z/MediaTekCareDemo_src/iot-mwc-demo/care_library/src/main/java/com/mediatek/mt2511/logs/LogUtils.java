package com.mediatek.mt2511.logs;

import android.os.Environment;
import java.text.SimpleDateFormat;

public class LogUtils {
  public static final String FOLDER_NAME_CATCH_LOG = "/CatchLog";
  private static final SimpleDateFormat simpleDateFormat =
      new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");

  public static String getExternalStorageDir() {
    if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
      return Environment.getExternalStorageDirectory().getAbsolutePath() ;
    } else {
      return Environment.getRootDirectory().getAbsolutePath();
    }
  }

  public static String getCatchLogPath() {
    return getExternalStorageDir() + FOLDER_NAME_CATCH_LOG ;
  }

  public static String format(Long timestamp) {
    return simpleDateFormat.format(timestamp);
  }

  public static String formatFileName(String fileName){
    return fileName.replaceAll("[\\\\\\/\\:\\@\\*\\?\\<\\>\\|]", "_");
  }
}
