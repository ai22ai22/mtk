package com.mediatek.mt2511.framework;

/**
 * Created by MTK40526 on 1/8/2016.
 */
public class DeviceSupportException extends Exception {
    public DeviceSupportException(String detailMessage) {
        super(detailMessage);
    }
}
