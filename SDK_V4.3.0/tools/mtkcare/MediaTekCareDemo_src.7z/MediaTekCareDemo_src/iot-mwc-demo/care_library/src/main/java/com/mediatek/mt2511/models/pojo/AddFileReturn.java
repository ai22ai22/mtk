package com.mediatek.mt2511.models.pojo;

import java.util.HashMap;

public class AddFileReturn {
  public HashMap<String, String> uploadURLs;
}
