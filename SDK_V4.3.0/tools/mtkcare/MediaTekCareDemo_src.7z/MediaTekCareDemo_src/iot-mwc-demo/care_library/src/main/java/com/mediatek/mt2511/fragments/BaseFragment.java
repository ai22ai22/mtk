package com.mediatek.mt2511.fragments;

import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import rx.Subscription;

/**
 * Created by MTK40526 on 3/8/2016.
 */
public class BaseFragment extends Fragment {
  private Subscription mSubscription;

  protected View inflate(int layoutResId, LayoutInflater inflater, ViewGroup container) {
    View v = inflater.inflate(layoutResId, container, false);
    setHasOptionsMenu(true);
    return v;
  }
}
