package com.mediatek.mt2511.presentation;

public interface Presenter<T> {
  void setView(T view);
}
