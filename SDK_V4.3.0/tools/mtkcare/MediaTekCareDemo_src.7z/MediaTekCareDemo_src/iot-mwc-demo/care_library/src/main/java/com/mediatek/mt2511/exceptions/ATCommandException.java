package com.mediatek.mt2511.exceptions;

public class ATCommandException  extends  Exception{
  public ATCommandException(String detailMessage) {
    super(detailMessage);
  }
}
