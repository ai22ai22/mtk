package com.mediatek.mt2511.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;
import com.mediatek.mt2511.R;

/**
 * Created by MTK40526 on 3/30/2016.
 */
public class HRVResultView extends RelativeLayout {
    private int mAge;
    private int mHR;
    private float mSDNN;

    public HRVResultView(Context context) {
        this(context, null);
    }

    public HRVResultView(Context context, AttributeSet attrs) {
        this(context, attrs, 0 );
    }

    public HRVResultView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        int width = right - left;
        int height = bottom - top;

        View icon = findViewById(R.id.img_point);
        float sdnn_normal =  -1.04f  * mAge + 80.4f;
        float hr_normal  = 80f;

        int y = (int) ((hr_normal +20 - mHR ) / 40f * height);
        int x = (int) ((mSDNN -(sdnn_normal -20)) / 40f * width);
        int point_width = icon.getWidth();
        int point_height = icon.getHeight();
        y = Math.max(Math.min(y,height - point_height / 2), point_height / 2);
        x = Math.max(Math.min(x,width - point_width / 2 ), point_width / 2);

        RelativeLayout.LayoutParams params =
              (RelativeLayout.LayoutParams) icon.getLayoutParams();
        x -= point_width / 2;
        y -= point_height / 2;
        params.leftMargin = x;
        params.topMargin = y;
        icon.setLayoutParams(params);

    }

    public void setup(int age,int hr,float sdnn){
        this.mAge = age;
        this.mHR = hr;
        this.mSDNN = sdnn;
        requestLayout();
    }
}
