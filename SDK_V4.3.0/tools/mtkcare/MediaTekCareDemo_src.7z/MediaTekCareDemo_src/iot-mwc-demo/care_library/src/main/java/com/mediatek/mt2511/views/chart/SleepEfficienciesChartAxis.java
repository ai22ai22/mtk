package com.mediatek.mt2511.views.chart;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

public class SleepEfficienciesChartAxis extends View {
  private SleepEfficienciesChartConstant chart_constant = new SleepEfficienciesChartConstant();
  private Canvas canvas = new Canvas();

  public SleepEfficienciesChartAxis(Context context) { super(context); }

  public void setCanvas(Canvas canvas) {
    this.canvas = canvas;
  }

  public void onDraw(Canvas canvas) {
    super.onDraw(canvas);
  }

  public void drawAxis(float position_y, float axis_interval, String[] scale_text) {
    int textHeight;
    int textWidth;
    float text_x;
    float text_y;

    chart_constant.convertUnit(getContext());
    float line_start_x = chart_constant.getPx_margin_left();
    float line_end_x = canvas.getWidth() - chart_constant.getPx_margin_right();

    Paint paint_axis = new Paint();
    paint_axis.setColor(Color.GRAY);
    paint_axis.setAlpha(200);
    canvas.drawLine(line_start_x, position_y, line_end_x, position_y, paint_axis);

    Paint paint_y_axis_text = new Paint();
    paint_y_axis_text.setAntiAlias(true);
    paint_y_axis_text.setTextSize(chart_constant.getPx_text_size());
    paint_y_axis_text.setColor(Color.GRAY);
    paint_y_axis_text.setAlpha(200);
    Rect textBounds = new Rect();

    for (int i = 0; i < scale_text.length; i++) {
      paint_y_axis_text.getTextBounds(scale_text[i], 0, scale_text[i].length(), textBounds);
      textHeight = textBounds.height();
      textWidth = textBounds.width();
      text_x = line_end_x - textWidth;
      text_y = position_y - axis_interval * i
          + chart_constant.getPx_axis_and_text_interval()
          + textHeight;

      canvas.drawLine(line_start_x, position_y - axis_interval * i, line_end_x,
          position_y - axis_interval * i, paint_axis);
      canvas.drawText(scale_text[i], text_x, text_y, paint_y_axis_text);
    }
  }
}
