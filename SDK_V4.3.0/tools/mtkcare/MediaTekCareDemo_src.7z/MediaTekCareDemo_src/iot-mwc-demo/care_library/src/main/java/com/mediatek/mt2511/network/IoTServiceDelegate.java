package com.mediatek.mt2511.network;

import android.text.TextUtils;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.pojo.AddFileRequest;
import com.mediatek.mt2511.models.pojo.AddFileReturn;
import com.mediatek.mt2511.models.pojo.HRSaveRequest;
import com.mediatek.mt2511.models.pojo.HRVRequest;
import com.mediatek.mt2511.models.pojo.LoginRequest;
import com.mediatek.mt2511.models.pojo.LoginResponse;
import com.mediatek.mt2511.models.pojo.RecordResult;
import com.mediatek.mt2511.models.pojo.UploadCareRequest;
import com.mediatek.mt2511.services.UserSession;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;
import java.io.File;
import java.io.IOException;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.util.Map;
import retrofit.RestAdapter;
import retrofit.client.OkClient;
import retrofit.http.Body;
import rx.Observable;
import rx.Subscriber;
import rx.functions.Func1;

public class IoTServiceDelegate {
  private final IoTService impl;

  public IoTServiceDelegate() {
    OkHttpClient httpClient = NetworkUtils.createOkHttpClient();
    CookieManager cookieManager = new CookieManager();
    cookieManager.setCookiePolicy(CookiePolicy.ACCEPT_ALL);
    httpClient.setCookieHandler(cookieManager);
    String endPoint =
        MContext.getInstance().getEndPoint();
    RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(endPoint)
        // Out-comment the following line if you want to use the default converter Gson.
        .setConverter(new GsonConverter()).setClient(new OkClient(httpClient)).build();
    this.impl = restAdapter.create(IoTService.class);
  }

  private boolean isSignInAddRecord() {
    UserSession.RecordInfo recordInfo = UserSession.getInstance().getRecordInfo();
    return (UserSession.getInstance().getState() == UserSession.STATE_SIGNED_IN)
        && recordInfo != null
        && !TextUtils.isEmpty(recordInfo.recordId);
  }

  public Observable<LoginResponse> login(@Body LoginRequest loginRequest) {
    return impl.login(loginRequest);
  }

  public Observable<RecordResult> createRecord(@Body final UploadCareRequest recordRequest) {
    return Observable.create(new Observable.OnSubscribe<RecordResult>() {
      @Override public void call(Subscriber<? super RecordResult> subscriber) {
        if (UserSession.getInstance().getState() == UserSession.STATE_SIGNED_IN) {
          impl.createRecord(recordRequest).subscribe(subscriber);
        } else {
          RecordResult recordResult = new RecordResult();
          recordResult.recordId = "";
          recordResult.userNickname = recordRequest.userNickname;
          recordResult.age = recordRequest.age;
          recordResult.gender = recordRequest.gender;
          subscriber.onNext(recordResult);
          subscriber.onCompleted();
        }
      }
    });
  }

  public Observable<String> saveHRV(@Body final HRVRequest hrvRequest) {
    return Observable.create(new Observable.OnSubscribe<String>() {
      @Override public void call(Subscriber<? super String> subscriber) {
        if (UserSession.getInstance().getState() == UserSession.STATE_SIGNED_IN) {
          impl.saveHRV(UserSession.getInstance().getRecordInfo().recordId, hrvRequest)
              .subscribe(subscriber);
        } else {
          subscriber.onNext("");
          subscriber.onCompleted();
        }
      }
    });
  }

  public Observable<String> saveHR(@Body final HRSaveRequest hrSaveRequest) {
    return Observable.create(new Observable.OnSubscribe<String>() {
      @Override public void call(Subscriber<? super String> subscriber) {
        if (isSignInAddRecord()) {
          impl.saveHR(UserSession.getInstance().getRecordInfo().recordId, hrSaveRequest)
              .subscribe(subscriber);
        } else {
          subscriber.onNext("");
          subscriber.onCompleted();
        }
      }
    });
  }

  public Observable<String> uploadLogFile(final File... files) {
    return Observable.create(new Observable.OnSubscribe<String>() {
      @Override public void call(final Subscriber<? super String> subscriber) {
        if (isSignInAddRecord()) {
          UploadCareRequest uploadCareRequest = new UploadCareRequest();
          uploadCareRequest.age = UserSession.getInstance().getRecordInfo().age;
          uploadCareRequest.gender = UserSession.getInstance().getRecordInfo().gender;
          uploadCareRequest.userNickname = UserSession.getInstance().getRecordInfo().userId;
          uploadCareRequest.comment =
              "This chart represent the physiological age of yourscomparing with others ";
          for (File file : files) {
            if (file != null) {
              uploadCareRequest.fileList.add(file.getName());
            }
          }

          impl.addFile(UserSession.getInstance().getRecordInfo().recordId, uploadCareRequest)
              .flatMap(new Func1<AddFileReturn, Observable<String>>() {
                @Override public Observable<String> call(final AddFileReturn addFileReturn) {
                  return Observable.create(new Observable.OnSubscribe<String>() {
                    @Override public void call(Subscriber<? super String> subscriber) {
                      OkHttpClient client = MOkHttpClient.createOkHttpClient();
                      for (Map.Entry<String, String> stringStringEntry : addFileReturn.uploadURLs.entrySet()) {
                        File file = new File(
                            MContext.getInstance().getLogPath() + "/" + stringStringEntry.getKey());
                        if (!file.exists()) {
                          file = new File(MContext.getInstance().getLogPath()
                              + "_Temp"
                              + "/"
                              + stringStringEntry.getKey());
                        }

                        RequestBody requestBody =
                            RequestBody.create(MediaType.parse("application/octet-stream"), file);
                        Request request = new Request.Builder().url(stringStringEntry.getValue())
                            .header("Content-Type", "application/octet-stream")
                            .put(requestBody)
                            .build();
                        try {
                          Response response = client.newCall(request).execute();
                          if (response.isSuccessful()) {
                          } else {
                            subscriber.onError(new Exception("http Code :" + response.code()));
                            return;
                          }
                        } catch (IOException e) {
                          e.printStackTrace();
                          subscriber.onError(e);
                          return;
                        }
                      }
                      subscriber.onNext("Uploaded Successfully");
                      subscriber.onCompleted();
                    }
                  }).retry(3);
                }
              })
              .subscribe(subscriber);
        } else {
          subscriber.onNext("");
          subscriber.onCompleted();
        }
      }
    });
  }
}
