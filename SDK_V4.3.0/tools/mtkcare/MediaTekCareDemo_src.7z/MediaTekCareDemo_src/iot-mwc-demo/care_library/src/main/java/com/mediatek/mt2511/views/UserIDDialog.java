package com.mediatek.mt2511.views;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.mediatek.mt2511.R;

import rx.Observable;
import rx.Subscriber;


public class UserIDDialog extends AlertDialog implements View.OnClickListener {
    public interface UserIDListener {
        public void returnInput(String userID);
    }
	
	private UserIDListener callback = null;
	private EditText edtUserID = null;
	private View btnClose = null;
	private Button btnStart = null;
	private SharedPreferences sp;
	public UserIDDialog(Context context) {
		super(context);
		sp  =context.getSharedPreferences("UIDefaultValue", Context.MODE_PRIVATE); 
		// TODO Auto-generated constructor stub
		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		
		View view = inflater.inflate(R.layout.record_dialog, null);

		edtUserID = (EditText) view.findViewById(R.id.record_user_id);
		btnClose = view.findViewById(R.id.record_cancel_btn);
		btnStart = (Button)view.findViewById(R.id.record_start_btn);

		bindEvent();
		setDefaultValue();
		setView(view);
	}
	
	private void setDefaultValue() {
	   edtUserID.setText(sp.getString("userID","MWC|Demo User"));
	}
	
	

	private void bindEvent(){
		btnStart.setOnClickListener(this);
		btnClose.setOnClickListener(this);
	}
	@Override
	public void onClick(View v) {
		if (v == btnClose){
			dismiss();
		}else if (v == btnStart){
			if (callback != null){
				callback.returnInput(edtUserID.getText().toString());
			}
			Editor editor = sp.edit();
			editor.putString("userID", edtUserID.getText().toString());
			editor.commit();
			dismiss();
		}
	}
	
	public void setDefaultUserID(String userID){
		edtUserID.setText(userID);
	}
	
	public void setOKButtonText(String text){
		btnStart.setText(text);
	}
	public UserIDListener getCallback() {
		return callback;
	}
	public void setUserIDListener(UserIDListener userIDListener) {
		this.callback = userIDListener;
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		super.show();
		this.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM); 
		this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);

	}

	public Observable<String>  show2(){
		return Observable.create(new Observable.OnSubscribe<String>() {
			@Override
			public void call(final Subscriber<? super String> subscriber) {

				UserIDDialog.this.show();
				btnStart.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						if (!TextUtils.isEmpty(edtUserID.getText())) {
							subscriber.onNext(edtUserID.getText().toString());
							Editor editor = sp.edit();
							editor.putString("userID", edtUserID.getText().toString());
							editor.commit();
							UserIDDialog.this.dismiss();
						}
					}
				});
				btnClose.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						subscriber.onCompleted();
						UserIDDialog.this.dismiss();
					}
				});
			}
		});
	}




}
