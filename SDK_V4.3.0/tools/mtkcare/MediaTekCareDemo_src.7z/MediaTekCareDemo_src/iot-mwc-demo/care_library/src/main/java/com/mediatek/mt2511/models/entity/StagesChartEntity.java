package com.mediatek.mt2511.models.entity;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import java.util.List;
import lombok.Getter;

@Getter public class StagesChartEntity {
  private List<Chart> charts;

  @Getter public static class Chart {
    @SerializedName("bspmeta") private BspMeta bspMeta;
    private Data data;

    @Getter public static class BspMeta {
      private String time;
      private YTickMap ytickmap;
      private Ratios ratios;
      @SerializedName("sleep_efficiency") private String sleepEfficiency;
      @SerializedName("sleep_duration") private List<String> sleepDuration;
      @SerializedName("asleep_time") private List<String> asleepTime;
      /**
       * HH, mm
       *
       * e.g. "asleep_time": [
       *   "23",
       *   "37"
       * ],
       */

      @Getter public static class YTickMap {
        private List<Integer> ss_num;
        private List<String> ss_text;
        /**
         * e.g. "ss_num": [
         *   0,
         *   -1,
         *   -2,
         *   -3
         * ],
         * "ss_text": [
         *   "AWAKE",
         *   "REM",
         *   "LIGHT",
         *   "DEEP"
         * ]
         */
      }

      @Getter public static class Ratios {
        private List<String> Light;
        private List<String> Deep;
        private List<String> REM;
        /**
         * HH, mm, %
         *
         * e.g. "Light": [
         *   "4",
         *   "28",
         *   "77.80"
         * ]
         */
      }
    }

    @Getter public static class Data {
      private String xFormat;

      /**
       * Should skip first index, it is header
       */
      private List<Object> columns;

      /**
       * "columns": [
       *   [
       *     "ss_num",
       *     0,
       *     -2,
       *     -1,
       *     0
       *   ],
       *   [
       *     "time",
       *     "07-23 23:24:11",
       *     "07-23 23:24:41",
       *     "07-24 06:03:11",
       *     "07-24 06:03:41"
       *   ]
       * ]
       */
    }
  }

  public StagesChartEntity fromJson(String json) {
    return new Gson().fromJson(json, StagesChartEntity.class);
  }

  public String toJson() {
    return new Gson().toJson(this);
  }
}
