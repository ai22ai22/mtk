package com.mediatek.mt2511.logs;


public interface FileNameGenerator {

  String generate();
}
