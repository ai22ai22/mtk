package com.mediatek.mt2511.custom;

import com.mediatek.mt2511.MContext;
import com.mediatek.iot.Device;
import com.mediatek.iot.Scanner;
import com.mediatek.iot.bt.BTDevice;
import com.mediatek.iot.bt.BTDeviceScanner;
import com.mediatek.iot.data.bt.BTDataParser;

public class BTDeviceFactory {
  private static Scanner sBTScanner;
  private static Device sBTDevice;

  public static Scanner getBTScanner() {
    if (sBTScanner == null) {
      sBTScanner = new BTDeviceScanner(MContext.getInstance().getApplication());
    }
    return sBTScanner;
  }

  public static Device getBTDevice() {
    if (sBTDevice == null) {
      sBTDevice = new BTDevice(MContext.getInstance().getApplication(), new BTDataParser());
    }
    return sBTDevice;
  }
}
