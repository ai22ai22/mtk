package com.mediatek.mt2511.models;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class PersonalProfileEntity extends RealmObject {
  public static final String MODE_GENERAL = "0";
  public static final String MODE_PERSONAL = "127";
  public static final String MODE_CALIBRATION = "1023";

  @PrimaryKey private String id = String.valueOf(System.currentTimeMillis());
  private String userId;
  private Integer age;
  private Integer weight;
  private Integer height;
  private Integer gender;
  private Integer armLength;
  private CalibrationResult calibrationResult;
  private String mode = MODE_CALIBRATION;

  public String getMode() {
    return mode;
  }

  public void setMode(String mode) {
    this.mode = mode;
  }

  public CalibrationResult getCalibrationResult() {
    return calibrationResult;
  }

  public void setCalibrationResult(CalibrationResult calibrationResult) {
    this.calibrationResult = calibrationResult;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public Integer getAge() {
    return age;
  }

  public void setAge(Integer age) {
    this.age = age;
  }

  public Integer getWeight() {
    return weight;
  }

  public void setWeight(Integer weight) {
    this.weight = weight;
  }

  public Integer getHeight() {
    return height;
  }

  public void setHeight(Integer height) {
    this.height = height;
  }

  public Integer getGender() {
    return gender;
  }

  public void setGender(Integer gender) {
    this.gender = gender;
  }

  public Integer getArmLength() {
    return armLength;
  }

  public void setArmLength(Integer armLength) {
    this.armLength = armLength;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }
}
