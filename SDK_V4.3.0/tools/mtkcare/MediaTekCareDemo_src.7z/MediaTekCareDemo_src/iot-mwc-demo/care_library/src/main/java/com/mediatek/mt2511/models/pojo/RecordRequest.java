package com.mediatek.mt2511.models.pojo;

public class RecordRequest {

  public String userNickname;

  public Integer age;

  public String gender;

  public String comment;
}
