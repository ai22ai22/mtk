package com.mediatek.mt2511.network;

class ApiConstants {

    // Just examples. Replace however you need!
    public static final String BASE_URL_HEALTH = "https://health.mediatek.io/care";
    public static final String BASE_URL_CARE = "https://care.mediatek.cn/care";
    public static final int HTTP_CONNECT_TIMEOUT =  6000; // milliseconds
    public static final int HTTP_READ_TIMEOUT = 10000; // milliseconds
    public static String RESPONSE_VALUE_SUCCESS = "success";
    public static String PARAM_VALUE_OFF = "0";
    public static String PARAM_VALUE_ON = "1";
}
