package com.mediatek.mt2511.views.chart;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.SleepReport;
import com.mediatek.mt2511.utils.DateUtils;
import com.mediatek.mt2511.utils.MContextCompat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SleepEfficienciesChart extends LinearLayout {
  private SleepEfficienciesChartConstant chart_constant = new SleepEfficienciesChartConstant();
  private Canvas canvas;
  private float axis_interval = 0;
  private float line_start_y = 0;

  private List<String> sleepDates = new ArrayList<>();
  private List<Integer> efficiencies = new ArrayList<>();

  public SleepEfficienciesChart(Context context) {
    super(context);
    initViews();
  }

  public SleepEfficienciesChart(Context context, AttributeSet attributeSet) {
    super(context, attributeSet);
    initViews();
  }

  public void setReports(List<SleepReport> reports) {
    final int BARS_LIMIT = 7;
    sleepDates = new ArrayList<>();
    efficiencies = new ArrayList<>();

    int counter = reports.size() < BARS_LIMIT ? reports.size() : BARS_LIMIT;
    for (int i = 0; i < counter; i++) {
      sleepDates.add(reports.get(i).getAsleepDate());
      efficiencies.add(reports.get(i).getEfficiency());
    }
  }

  private void initViews() {
    LayoutInflater inflater = LayoutInflater.from(getContext());
    inflater.inflate(R.layout.report_ring, this, true);
    setWillNotDraw(false);
  }

  @Override protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    this.canvas = canvas;
    chart_constant.convertUnit(getContext());
    chart_constant.setPx_chart_height(canvas.getHeight()
        - chart_constant.getPx_margin_top()
        - chart_constant.getPx_margin_bottom());
    chart_constant.setPx_chart_width(canvas.getWidth()
        - chart_constant.getPx_margin_left()
        - chart_constant.getPx_margin_right());
    this.axis_interval = (canvas.getHeight()
        - chart_constant.getPx_margin_bottom()
        - chart_constant.getPx_margin_top()
        - chart_constant.getPx_line_stroke_width() * 3)
        / 2;

    Paint paint_bgColor = new Paint();
//    paint_bgColor.setColor(ContextCompat.getColor(getContext(), R.color.gs_x_dark_blue));
    paint_bgColor.setColor(MContextCompat.getColor(getContext(), R.color.white));
    paint_bgColor.setStyle(Paint.Style.FILL);
    canvas.drawPaint(paint_bgColor);

    this.line_start_y = canvas.getHeight() - chart_constant.getPx_margin_bottom();
    SleepEfficienciesChartAxis chart_axis = new SleepEfficienciesChartAxis(getContext());
    chart_axis.setCanvas(canvas);
    String scale_text[] = { "0", "50", "100" };
    chart_axis.drawAxis(this.line_start_y, this.axis_interval, scale_text);

    int bar_count = sleepDates.size();
    if (bar_count > 0) {
      drawBar(bar_count);
      setTitle(sleepDates.get(bar_count - 1));
    }
  }

  protected void drawBar(int count) {
    chart_constant.convertUnit(getContext());
    float position_x = chart_constant.getPx_margin_left() + chart_constant.getPx_bar_interval();

    for(int i = 0; i < count; i++) {
      SleepEfficiencyBar single_bar = new SleepEfficiencyBar(getContext());
      single_bar.setCanvas(this.canvas);
      single_bar.isHighlighted(isToday(sleepDates.get(i)));
      single_bar.drawSingleBar(position_x, efficiencies.get(i), reFormatDate(sleepDates.get(i)));
      position_x += chart_constant.getPx_bar_width()
          + chart_constant.getPx_bar_interval();
    }
  }

  private void setTitle(String title_date) {
    String title_efficiency = "Sleep Efficiency";
    String percentage_operator = "%";
    String percentageStr = getPercentageString(title_date);
    String dateStr = "Today";
    int textWidth;
    float text_x;
    float text_y = this.line_start_y - this.axis_interval * 2
        - chart_constant.getPx_line_stroke_width() * 3
        - chart_constant.getPx_title_margin_bottom();

    Paint paint_text = new Paint();
    paint_text.setColor(Color.BLACK);
    paint_text.setAntiAlias(true);
    paint_text.setTextSize(chart_constant.getPx_text_size());

    Paint paint_text_percentage = new Paint();
    paint_text_percentage.setColor(Color.BLACK);
    paint_text_percentage.setAntiAlias(true);
    paint_text_percentage.setTextSize(chart_constant.getPx_text_size_percentage());
    paint_text_percentage.setFakeBoldText(true);

    canvas.drawText(title_efficiency, chart_constant.getPx_margin_left(),
        text_y, paint_text);

    Rect textBounds = new Rect();
    paint_text.getTextBounds(percentage_operator, 0, percentage_operator.length(), textBounds);
    textWidth = textBounds.right - textBounds.left;
    text_x = canvas.getWidth() - chart_constant.getPx_margin_left() - textWidth;
    canvas.drawText(percentage_operator, text_x, text_y, paint_text);

    paint_text_percentage.getTextBounds(percentageStr, 0, percentageStr.length(), textBounds);
    textWidth = textBounds.right - textBounds.left;
    text_x = text_x - textWidth - 5;
    canvas.drawText(percentageStr, text_x, text_y, paint_text_percentage);

    paint_text.getTextBounds(dateStr, 0, dateStr.length(), textBounds);
    textWidth = textBounds.right - textBounds.left;
    text_x = text_x - textWidth - 10;
    canvas.drawText(dateStr, text_x, text_y, paint_text);
  }

  private String getPercentageString(String dateString) {
//    return (isToday(dateString)) ? String.valueOf(efficiencies.get(efficiencies.size() - 1)) : "-";
    return String.valueOf(efficiencies.get(efficiencies.size() - 1));
  }

  private boolean isToday(String dateString) {
    Date date = new Date();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
    String today = sdf.format(date);
    return dateString.equals(today);
  }

  private String reFormatDate(String inputDate) {
    String inputSdfPattern = "yyyy/MM/dd";
    String outputSdfPattern = "dd";
    return DateUtils.formatDate(inputDate, inputSdfPattern, outputSdfPattern);
  }
}
