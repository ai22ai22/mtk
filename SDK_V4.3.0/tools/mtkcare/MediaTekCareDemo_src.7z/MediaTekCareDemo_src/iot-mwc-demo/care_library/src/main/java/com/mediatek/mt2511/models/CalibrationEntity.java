package com.mediatek.mt2511.models;

public class CalibrationEntity {
  public SPPack[] spPacks = new SPPack[] { new SPPack(), new SPPack(), new SPPack() };
  public Paras[] parases = new Paras[] {new Paras(), new Paras()};

  public CalibrationEntity() {

  }

  public static class SPPack {
    public int sbp = -1;
    public int ddp = -1;
    public int timestamp = -1;
  }

  public static class Paras {
    //public int[] values = new int[] { -1, -1, -1, -1, -1, -1 };
    public int[] values ;
    public int timestamp = -1;
  }
}
