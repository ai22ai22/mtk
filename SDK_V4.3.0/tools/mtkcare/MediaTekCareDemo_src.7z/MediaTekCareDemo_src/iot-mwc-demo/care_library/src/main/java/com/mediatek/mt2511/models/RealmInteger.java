package com.mediatek.mt2511.models;

import io.realm.RealmObject;

public class RealmInteger extends RealmObject {
  private Integer value;

  public Integer getValue() {
    return value;
  }

  public void setValue(Integer value) {
    this.value = value;
  }
}
