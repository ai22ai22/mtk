package com.mediatek.mt2511.network;

import com.google.gson.Gson;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import retrofit.converter.ConversionException;
import retrofit.converter.Converter;
import retrofit.mime.TypedByteArray;
import retrofit.mime.TypedInput;
import retrofit.mime.TypedOutput;

/**
 * A {@link Converter} which uses Jackson for reading and writing entities.
 */
class GsonConverter implements Converter {
  private static final String MIME_TYPE = "application/json; charset=UTF-8";

  private final Gson gson;

  public GsonConverter() {
    this(new Gson());
  }

  public GsonConverter(Gson gson) {
    this.gson = gson;
  }

  @Override public Object fromBody(TypedInput body, Type type) throws ConversionException {
    try {
      InputStreamReader reader = new InputStreamReader(body.in());
      return gson.fromJson(reader, type);
    } catch (IOException e) {
      throw new ConversionException(e);
    }
  }

  @Override public TypedOutput toBody(Object object) {
    try {
      String json = gson.toJson(object);
      return new TypedByteArray(MIME_TYPE, json.getBytes("UTF-8"));
    } catch (UnsupportedEncodingException e) {
      e.printStackTrace();
      throw new AssertionError(e);
    }
  }
}
