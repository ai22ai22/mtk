package com.mediatek.mt2511.interfaces;

import rx.Observable;

public interface closeable {
  Observable<String> preClose();
  void close();
}
