package com.mediatek.mt2511;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.os.Environment;
import android.support.v4.app.Fragment;
import com.mediatek.mt2511.branch.IMContext;
import com.mediatek.mt2511.custom.BTDeviceFactory;
import com.mediatek.mt2511.fragments.FormFragment;
import com.mediatek.mt2511.logs.CrashReportingDebugTree;
import com.mediatek.mt2511.services.RecordService;
import java.io.File;
import timber.log.Timber;

public class MContext {
  private static MContext sInstance;
  private Application application;
  private String macAddress;
  private Class<?> frontActivityClass;
  private IMContext imContextImpl;

  public static MContext getInstance() {
    if (sInstance == null) {
      sInstance = new MContext();
    }
    return sInstance;
  }

  public void init(Application application, IMContext imContext) {
    this.application = application;
    this.imContextImpl = imContext;
    RecordService.getInstance().init();
    BTDeviceFactory.getBTDevice();
    Timber.plant(new CrashReportingDebugTree());
  }

  public Application getApplication() {
    return application;
  }

  public String getLogPath() {
    String logPath;
    if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
      logPath = Environment.getExternalStorageDirectory() + "/CatchLog";
    } else {
      logPath = Environment.getRootDirectory() + "/CatchLog";
    }
    File file = new File(logPath + "/");
    if (!file.exists()) {
      file.mkdirs();
    }
    return logPath;
  }

  public String getEndPoint() {
    return imContextImpl.getEndPoint();
  }

  public String getApplicationId() {
    return imContextImpl.getApplicationId();
  }

  public String[] getFeatureFragment() {
    return imContextImpl.getFeatureFragment();
  }

  public boolean isSelfSignedCA(){
    return imContextImpl.isSelfSignedCA();
  }

  public void backToFrontActivity(Activity fromActivity) {
    if (frontActivityClass != null) {
      Intent upIntent = new Intent(application, frontActivityClass);
      upIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
      fromActivity.startActivity(upIntent);
    }
  }

  public void registerFrontActivity(Activity activity) {
    frontActivityClass = activity.getClass();
  }

  public FormFragment[] createAddRecordFragments() {
    return imContextImpl.createAddRecordFragments();
  }

  public boolean isForceAddRecord(){
    return imContextImpl.isForceAddRecord();
  }
}
