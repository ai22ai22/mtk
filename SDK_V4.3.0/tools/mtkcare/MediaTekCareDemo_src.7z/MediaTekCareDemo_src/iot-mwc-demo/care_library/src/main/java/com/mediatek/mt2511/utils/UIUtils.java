package com.mediatek.mt2511.utils;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import com.jakewharton.rxbinding.widget.RxTextView;
import com.jakewharton.rxbinding.widget.TextViewTextChangeEvent;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import java.util.Calendar;
import rx.Observable;
import rx.functions.Action1;

public class UIUtils {

  public static Snackbar makeSnackbar(Activity activity, String message) {
    return makeSnackbar(activity, message, Snackbar.LENGTH_SHORT);
  }

  public static Snackbar makeSnackbar(Activity activity, String message, int length) {
    return Snackbar.make(activity.findViewById(android.R.id.content), message, length);
  }

  public static int dpToPx(float dp, Context context) {
    return (int) (dp * getDensity(context));
  }

  public static int pxToDp(float px, Context context) {
    return (int) (px / getDensity(context));
  }

  public static float getDensity(Context context) {
    return context.getResources().getDisplayMetrics().density;
  }

  public static int roundDown(String percentage) {
    try {
      Double p = Double.parseDouble(percentage);
      return (int) Math.floor(p);
    } catch (NumberFormatException e) {
      //      GsLog.e(e);
      return 0;
    }
  }

  public static Observable<TextViewTextChangeEvent> createRequiredObservable(
      final EditText editText) {
    editText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
      @Override public void onFocusChange(View v, boolean hasFocus) {
        if (!hasFocus && TextUtils.isEmpty(editText.getText())) {
          TextInputLayout textInputLayout = (TextInputLayout) v.getParent();
          textInputLayout.setError(
              MContext.getInstance().getApplication().getString(R.string.invalid_value));
        }
      }
    });
    return RxTextView.textChangeEvents(editText)
        //  .skip(1)
        .doOnNext(new Action1<TextViewTextChangeEvent>() {
          private boolean isFirst = true;

          @Override public void call(TextViewTextChangeEvent textViewTextChangeEvent) {
            if (!isFirst) {
              TextInputLayout textInputLayout =
                  (TextInputLayout) textViewTextChangeEvent.view().getParent();
              if (TextUtils.isEmpty(textViewTextChangeEvent.text())) {
                textInputLayout.setError(
                    MContext.getInstance().getApplication().getString(R.string.invalid_value));
              } else {
                textInputLayout.setErrorEnabled(false);
              }
            }
            isFirst = false;
          }
        });
  }

  public static int getResIdByName(Context context, String type, String name) {
    String packageName = context.getPackageName();
    int resId = context.getResources().getIdentifier(name, type, packageName);
    return resId;
  }


  public static String getIdName(View view){
    int id = view.getId();
    if(id >0) {
      return view.getContext().getResources().getResourceEntryName(id);
    }
    return "";
  }


  public static String getSelectedCheckeBoxs(ViewGroup parent){
    boolean isFirst = true;
    StringBuilder sb = new StringBuilder();
    for(int i =0;i < parent.getChildCount(); ++i){
      if(parent.getChildAt(i) instanceof  CheckBox){
        CheckBox checkBox = (CheckBox) parent.getChildAt(i);
        if(checkBox.isChecked()){
          if(!isFirst){
            sb.append(",");
          }
          sb.append(getIdName(checkBox));
          isFirst = false;
        }
      }
    }
    return sb.toString();
  }

  public static void selectCheckbox(String selected, ViewGroup parent){
    for(int i =0;i < parent.getChildCount(); ++i){
      if(parent.getChildAt(i) instanceof  CheckBox){
        CheckBox checkBox = (CheckBox) parent.getChildAt(i);
        checkBox.setChecked(false);
      }
    }
    String[] checkboxIds = selected.split(",");
    Resources resource = parent.getResources();
    for(String idName: checkboxIds){
      int id = getResIdByName(parent.getContext(), "id", idName);
      if(id > 0){
        View view = parent.findViewById(id);
        if(view instanceof CheckBox){
          ((CheckBox)view).setChecked(true);
        }
      }
    }
  }

  public static void setFormEdit(EditText editText, String value) {
    ViewGroup parentView = (ViewGroup) editText.getParent();
    int index = parentView.indexOfChild(editText);
    TextInputLayout textInputLayout = (TextInputLayout) parentView.getChildAt(index - 1);
    parentView.removeView(editText); // disable hint animation
    editText.setText(value);
    textInputLayout.addView(editText);
  }

  public static int getYear(){
    Calendar calendar = Calendar.getInstance();
    return calendar.get(Calendar.YEAR);
  }

}
