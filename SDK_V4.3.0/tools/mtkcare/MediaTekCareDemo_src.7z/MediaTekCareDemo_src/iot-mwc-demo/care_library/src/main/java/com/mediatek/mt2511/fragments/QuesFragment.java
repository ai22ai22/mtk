package com.mediatek.mt2511.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.Question;
import com.mediatek.mt2511.views.widgets.NoDefaultSpinner;
import java.util.Arrays;
import rx.Observable;

/**
 * Created by MTK40526 on 6/29/2016.
 */
public class QuesFragment extends FormFragment implements AdapterView.OnItemSelectedListener {
  public static final String SP_QUES = "ques";
  NoDefaultSpinner mSpinner_pressure;
  NoDefaultSpinner mSpinner_tired;
  NoDefaultSpinner mSpinner_relaxed;
  NoDefaultSpinner mSpinner_excited;
  NoDefaultSpinner mSpinner_sleepy;
  NoDefaultSpinner mSpinner_sick;
  private ArrayAdapter<String> mAnswerAdapter;
  private NoDefaultSpinner[] mSpinners;

  public QuesFragment() {
    setTitle(MContext.getInstance().getApplication().getString(R.string.ques_do_you_feel));
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_ques, container, false);
    initView(view);
    return view;
  }

  private void initView(View view) {

    mSpinner_pressure = (NoDefaultSpinner) view.findViewById(R.id.spinner_pressure);
    mSpinner_tired = (NoDefaultSpinner) view.findViewById(R.id.spinner_tired);
    mSpinner_relaxed = (NoDefaultSpinner) view.findViewById(R.id.spinner_relaxed);
    mSpinner_excited = (NoDefaultSpinner) view.findViewById(R.id.spinner_excited);
    mSpinner_sleepy = (NoDefaultSpinner) view.findViewById(R.id.spinner_sleepy);
    mSpinner_sick = (NoDefaultSpinner) view.findViewById(R.id.spinner_sick);
    mAnswerAdapter =
        new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item,
            getResources().getStringArray(R.array.string_array_answer));
    mSpinner_pressure.setAdapter(mAnswerAdapter);
    mSpinner_tired.setAdapter(mAnswerAdapter);
    mSpinner_relaxed.setAdapter(mAnswerAdapter);
    mSpinner_excited.setAdapter(mAnswerAdapter);
    mSpinner_sleepy.setAdapter(mAnswerAdapter);
    mSpinner_sick.setAdapter(mAnswerAdapter);

    mSpinner_pressure.setOnItemSelectedListener(this);
    mSpinner_tired.setOnItemSelectedListener(this);
    mSpinner_relaxed.setOnItemSelectedListener(this);
    mSpinner_excited.setOnItemSelectedListener(this);
    mSpinner_sleepy.setOnItemSelectedListener(this);
    mSpinner_sick.setOnItemSelectedListener(this);

    mSpinners = new NoDefaultSpinner[] {
        mSpinner_pressure, mSpinner_tired, mSpinner_relaxed, mSpinner_excited, mSpinner_sleepy,
        mSpinner_sick
    };

    setSpinnerSelect();

    checkFormValid();
  }

  private void setSpinnerSelect() {
    SharedPreferences sp = getActivity().getSharedPreferences(SP_QUES, Context.MODE_PRIVATE);
    String[] arr = getResources().getStringArray(R.array.string_array_answer);
    for (NoDefaultSpinner spinner : mSpinners) {
      String idName = getResources().getResourceName(spinner.getId());
      int idx = Arrays.asList(arr).indexOf(sp.getString(idName, ""));
      spinner.setSelection(idx);
    }
  }

  @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
    checkFormValid();
  }

  @Override public void onNothingSelected(AdapterView<?> parent) {

  }

  private void checkFormValid() {
    boolean isValid = true;
    for (NoDefaultSpinner spinner : mSpinners) {
      String value = (String) spinner.getSelectedItem();
      if (TextUtils.isEmpty(value)) {
        isValid = false;
        break;
      }
    }
    setValidation(isValid);
  }

  public void preSubmit() {
    SharedPreferences.Editor editor =
        getActivity().getSharedPreferences(SP_QUES, Context.MODE_PRIVATE).edit();
    for (NoDefaultSpinner spinner : mSpinners) {
      String idName = getResources().getResourceName(spinner.getId());
      String value = (String) spinner.getSelectedItem();
      editor.putString(idName, value);
    }
    editor.commit();
  }

  @Override public Observable<Question> submit() {
    preSubmit();
    Question question = new Question();
    question.desc = getQuesString(getActivity());
    return Observable.just(question);
  }


  public static String getQuesString(Context context) {
    SharedPreferences sp =
            context.getSharedPreferences(SP_QUES, Context.MODE_PRIVATE);
    int[] ids = new int[] {
            R.id.spinner_pressure, R.id.spinner_tired, R.id.spinner_relaxed, R.id.spinner_excited,
            R.id.spinner_sleepy, R.id.spinner_sick
    };
    String result = "";
    for (int id : ids) {
      String key = context.getResources().getResourceName(id);
      String value = sp.getString(key, "");
      if (value.equals("YES")) {
        value = "1";
      } else if (value.equals("NA")) {
        value = "2";
      } else if (value.equals("NO")) {
        value = "3";
      }
      if (TextUtils.isEmpty(result)) {
        result = value;
      } else {
        result += "," + value;
      }
    }
    return result;
  }
}
