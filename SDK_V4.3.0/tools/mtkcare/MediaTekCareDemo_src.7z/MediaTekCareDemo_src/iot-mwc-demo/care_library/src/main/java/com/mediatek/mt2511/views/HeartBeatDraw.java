package com.mediatek.mt2511.views;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.Pair;

/**
 * Created by MTK40526 on 3/21/2016.
 */
public class HeartBeatDraw {
    private final Paint paint;
    private Pair<Float, Long> lastData = null;
    private float xFactor = 1;
    private float yFactor = 1;
    private int width;
    private int height;
    private Path path = new Path();
    private long startTimeStamp;
    private long lastTimeStamp;
    private Drawable icon;
    public HeartBeatDraw(Drawable icon,Paint paint) {
        path.moveTo(0, 0);
        startTimeStamp = 0;
        lastTimeStamp = startTimeStamp;
        this.paint = paint;
        this.icon = icon;
        this.icon.setBounds(0,0, icon.getIntrinsicWidth(),icon.getIntrinsicHeight());

    }

    public void addECG(float mv, long timeStamp) {
        if (startTimeStamp == 0){
            startTimeStamp = timeStamp;
            lastTimeStamp = startTimeStamp;
        }
     //   Log.v("draw_", count +"\t\t" +toX(timeStamp) +"\t\t" + timeStamp);
        if (lastData != null && toX(timeStamp) >= width) {
         //   Log.v("draw_count", count +"");
            path.reset();
            startTimeStamp = timeStamp;
            path.moveTo(toX(timeStamp), toY(mv));
            lastData = new Pair<>(mv, timeStamp);
        }
        //Log.v("ecg pair", mv +"--" + timeStamp);
        if (lastData != null && lastData.first == mv && lastData.second == timeStamp){
            return;
        }

       // timeStamp = lastTimeStamp + 200;
        lastTimeStamp = timeStamp;
        float fx = toX(timeStamp);
        float fy = toY(mv);
       // Log.v("fx-fy",fx +"-" + fy);
        path.lineTo(fx, fy);
        lastData = new Pair<>(mv, timeStamp);
        Rect rect = new Rect(icon.getBounds());
        rect.offsetTo((int)fx, (int)(fy - rect.height() /2));
        icon.setBounds(rect);

    }

    private float toX(long timeStamp) {
        return  ((timeStamp - startTimeStamp) * xFactor);
    }

    private float toY(float mv) {
        float v = - (mv * yFactor);
        if (v < 0- height * 2) {
            return 0 - height * 2;
        }else if (v > height * 2){
            return  height * 2;
        }
        return  v;
    }

    public void draw(Canvas canvas) {
        canvas.drawPath(path, paint);
        if (lastData != null) {
            icon.draw(canvas);
        }
    }

    public void layout(int width, int height) {
        this.width = width;
        this.height = height;
        reset();
    }

    public void reset() {
        xFactor = width / 4000f;
        yFactor = height / 2;

        path.reset();
        startTimeStamp = 0;
        lastTimeStamp = startTimeStamp;
        path.moveTo(0, 0);
        lastData = null;
    }
}
