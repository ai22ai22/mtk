package com.mediatek.mt2511.events;

public class RecordChangeEvent {
  private String userId;
  public RecordChangeEvent(String userId){
    this.userId = userId;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }
}
