package com.mediatek.mt2511.models;

import com.mediatek.mt2511.utils.DatatypeConverter;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Date;

/**
 * Created by MTK40526 on 1/29/2016.
 */
public class HRData{
    private int algoId;

    public int getLength() {
        return length;
    }

    public int getAlgoId() {
        return algoId;
    }

    public Integer[] getData() {
        return data;
    }

    public Date getDate() {
        return date;
    }

    public int getFeatureId() {
        return featureId;
    }

    private int length;
    private Date date;
    private int featureId;
    private Integer[] data;
    public HRData(byte[] bytes) throws IOException {
        if (bytes != null && bytes.length > 0) {

            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
            algoId = byteArrayInputStream.read();
            if (algoId != 1){
                throw new IOException("invalid algoId");
            }
            length = byteArrayInputStream.read();
            if(length - 2 != byteArrayInputStream.available()){
                throw new IOException("invalid format");
            }
            byte[] buffer = new byte[4];
            byteArrayInputStream.read(buffer);
            date = new Date(DatatypeConverter.byte4ToInt(buffer) * 1000);
            featureId = byteArrayInputStream.read();
            buffer = new byte[byteArrayInputStream.available()];
            data = new Integer[byteArrayInputStream.available()];
            byteArrayInputStream.read(buffer);
            for(int i = 0;i< length - 7; ++i){
                data[i] = buffer[i] & 0xFF;
            }
        }

    }
    public String getHRString(){
        if (data != null && data.length > 0){
            return data[data.length -1] +"";
        }
        return "--";
    }
}
