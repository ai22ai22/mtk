package com.mediatek.mt2511.views;

import android.content.Context;
import android.support.v4.util.Pair;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.Toast;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.adapters.ExpandableListViewAdapter;
import com.mediatek.mt2511.fragments.CustomFragment;
import java.util.ArrayList;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action0;
import rx.subjects.PublishSubject;
import timber.log.Timber;

public class NavigationListView extends ExpandableListView {
  private ExpandableListViewAdapter adapter;
  private ArrayList<CustomFragment> fragments;
  private CustomFragment currentFragment = null;
  private PublishSubject<CustomFragment> fragmentSubject = PublishSubject.create();

  public NavigationListView(Context context) {
    super(context);
  }

  public NavigationListView(Context context, AttributeSet attrs) {
    super(context, attrs);
  }

  public NavigationListView(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
  }

  public void initFragmentMenu(ArrayList<CustomFragment> fragments) {
    this.fragments = fragments;
    this.adapter = new ExpandableListViewAdapter(getContext(), fragments, R.layout.list_item_title,
        R.layout.list_item_sub_title);
    setAdapter(adapter);
    doSelectItem(fragments.get(0));

    setOnGroupClickListener(new OnGroupClickListener() {
      @Override
      public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
        ArrayList<Pair<String, CustomFragment>> children = adapter.getGroup(groupPosition).second;
        if (children.size() == 1) {
          doSelectItem(children.get(0).second);
          return true;
        }
        return false;
      }
    });

    setOnChildClickListener(new OnChildClickListener() {
      @Override public boolean onChildClick(ExpandableListView parent, View v, int groupPosition,
          int childPosition, long id) {
        Pair<String, CustomFragment> child = adapter.getChild(groupPosition, childPosition);
        doSelectItem(child.second);
        return true;
      }
    });
    for (int i = 0; i < adapter.getGroupCount(); ++i) {
      expandGroup(i);
    }
  }

  private Observable<String> selectItem(final CustomFragment fragment) {
    return Observable.create(new Observable.OnSubscribe<String>() {
      @Override public void call(Subscriber<? super String> subscriber) {
        if (currentFragment == null) {
          subscriber.onNext("");
          subscriber.onCompleted();
        } else {
          currentFragment.preClose().subscribe(subscriber);
        }
      }
    }).doOnCompleted(new Action0() {
      @Override public void call() {
        fragmentSubject.onNext(fragment);
        currentFragment = fragment;
        for (CustomFragment item : fragments) {
          item.setActive(item == currentFragment);
        }
        invalidateViews();
      }
    }).subscribeOn(AndroidSchedulers.mainThread());
  }

  private void doSelectItem(CustomFragment currentFragment) {
    selectItem(currentFragment).subscribe(new Subscriber<String>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {
        Timber.e(e, e.getMessage());
        Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_LONG).show();
      }

      @Override public void onNext(String s) {

      }
    });
  }

  public Observable<String> closeCurrent() {
    return selectItem(null);
  }

  public Observable<CustomFragment> getFragmentObservable() {
    return fragmentSubject.asObservable();
  }
}
