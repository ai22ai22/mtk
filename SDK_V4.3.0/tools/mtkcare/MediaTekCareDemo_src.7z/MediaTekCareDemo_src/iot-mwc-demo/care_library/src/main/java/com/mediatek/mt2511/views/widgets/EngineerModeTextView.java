package com.mediatek.mt2511.views.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.mediatek.mt2511.services.ErrorMessageMonitor;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;

public class EngineerModeTextView extends TextView {
  private CompositeSubscription mSubscriptions = new CompositeSubscription();

  public EngineerModeTextView(Context context) {
    super(context);
  }

  public EngineerModeTextView(Context context, AttributeSet attrs) {
    super(context, attrs);
  }

  public EngineerModeTextView(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
  }

  @Override protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    mSubscriptions.add(
        ErrorMessageMonitor.getsInstance().getEngModeObservable().doOnNext(new Action1<Boolean>() {
          @Override public void call(Boolean enabled) {
            setVisibility(enabled ? View.VISIBLE : View.GONE);
          }
        }).skip(1).observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<Boolean>() {
          @Override public void call(Boolean enabled) {

            Toast.makeText(getContext(), "Engineering Mode " + (enabled ? "Opened." : "Closed."),
                Toast.LENGTH_SHORT).show();
          }
        }));
  }

  @Override protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    mSubscriptions.clear();
  }
}
