package com.mediatek.mt2511.views.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

import rx.Observable;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;

/**
 * Created by MTK40526 on 3/10/2016.
 */
public class ClockTextView extends TextView {
    private long mStartTimpStamp;
    private Subscription mSubscription;

    public ClockTextView(Context context) {
        super(context, null);
        reset();
    }


    public ClockTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        reset();
    }

    public ClockTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

    }


    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stop();
    }

    public void reset(){
        setText("00:00:00");
        mStartTimpStamp = 0;
    }
    public void restoreTimeStamp(long timeStamp){
        mStartTimpStamp = timeStamp;
    }
    public void start(long timeStamp){
        mStartTimpStamp = timeStamp;
        if(mSubscription != null){
            mSubscription.unsubscribe();
        }
        mSubscription = Observable.interval(1, TimeUnit.SECONDS)
                .onBackpressureDrop()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<Long>() {
                    @Override
                    public void call(Long aLong) {
                        long delta = (System.currentTimeMillis() - mStartTimpStamp ) / 1000;
                        int second = (int) (delta  % 60);
                        int minute = (int) (((delta - second) / 60) % 60);
                        int hour = (int) ((delta - second - minute * 60) / 3600);
                        setText(String.format("%02d:%02d:%02d", hour, minute, second));
                    }
                });
    }
    public void start(){
        start(System.currentTimeMillis());
    }
    public void stop(){
        if(mSubscription != null){
            mSubscription.unsubscribe();
        }
    }
}
