package com.mediatek.mt2511.views;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.mediatek.mt2511.R;

import rx.Observable;
import rx.Subscriber;

/**
 * Created by MTK40526 on 2/16/2016.
 */
public class ConfirmDialog  extends AlertDialog {
    private TextView mTxtTitle;
    private View mBtnClose;
    private View mBtnOK;
    private View mBtnCancel;
    private TextView mTxtMessage;


    public ConfirmDialog(Context context) {
        super(context);

        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_confrim, null);
        mTxtTitle = (TextView) view.findViewById(R.id.txtTitle);
        mBtnCancel = view.findViewById(R.id.btnDismiss);
        mBtnClose = view.findViewById(R.id.btnCancel);
        mTxtMessage = (TextView) view.findViewById(R.id.txtMessage);
        mBtnOK = view.findViewById(R.id.btnOK);
        setView(view);
        setCancelable(false);
    }

    public void setTitleMsg(int title, int msg){
        mTxtMessage.setText(msg);
        mTxtTitle.setText(title);
    }

    public Observable<String> show2(){
        return Observable.create(new Observable.OnSubscribe<String>() {

            private   Subscriber<? super String> mSubscriber;
            private View.OnClickListener btnClick = new View.OnClickListener(){

                @Override
                public void onClick(View v) {
                    if(v instanceof Button) {
                        mSubscriber.onNext(((Button)v).getText().toString());
                    }else{
                        mSubscriber.onNext("");
                    }
                    ConfirmDialog.this.dismiss();
                }
            };
            @Override
            public void call(Subscriber<? super String> subscriber) {
                mSubscriber = subscriber;
                ConfirmDialog.this.show();
                mBtnOK.setOnClickListener(btnClick);
                mBtnClose.setOnClickListener(btnClick);
                mBtnCancel.setOnClickListener(btnClick);
            }
        });
    }
    @Override
    public void show() {
        // TODO Auto-generated method stub
        super.show();
        this.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);

    }

}
