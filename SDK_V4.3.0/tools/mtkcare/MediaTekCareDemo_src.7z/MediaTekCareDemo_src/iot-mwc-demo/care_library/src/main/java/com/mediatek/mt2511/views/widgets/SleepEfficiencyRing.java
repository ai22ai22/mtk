package com.mediatek.mt2511.views.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.RelativeLayout;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.SleepReport;
import com.mediatek.mt2511.utils.MContextCompat;

public class SleepEfficiencyRing extends RelativeLayout {
  private LayoutInflater inflater;
  private Paint paint = null;
  private int efficiency = 0;
  private int colorResId;

  public SleepEfficiencyRing(Context context, AttributeSet attributeSet) {
    super(context, attributeSet);
    inflater = LayoutInflater.from(context);
    inflater.inflate(R.layout.report_ring, this, true);
    paint = new Paint();
    setWillNotDraw(false);
  }

  public void setSleepReport(SleepReport report) {
    this.efficiency = report.getEfficiency();
    this.colorResId = report.getStatusColor();
  }

  @Override protected void onDraw(Canvas canvas) {
    int center_x = canvas.getWidth() / 2;
    int center_y = canvas.getHeight() / 2;
    int circle_radius = 83;

    super.onDraw(canvas);
    paint.setColor(MContextCompat.getColor(getContext(),R.color.gs_light_gray));
    paint.setStyle(Paint.Style.STROKE);
    paint.setAntiAlias(true);
    paint.setStrokeWidth(10);
    canvas.drawCircle(center_x, center_y, circle_radius, paint);

    paint.setColor(MContextCompat.getColor(getContext(), colorResId));
    int left = center_x-circle_radius;
    int width = circle_radius*2;
    int top = center_y-circle_radius;
    RectF rect = new RectF();
    rect.set(left, top, left + width, top + width);
    canvas.drawArc(rect, -90, 360 * ((float) efficiency) / 100, false, paint);

    paint.setColor(Color.BLACK);
    paint.setTextSize(40);
    paint.setStrokeWidth(1);
    paint.setStyle(Paint.Style.FILL);
    Rect textBounds = new Rect();
    String percentStr = String.valueOf(efficiency) + "%";
    paint.getTextBounds(percentStr, 0, percentStr.length(), textBounds);
    int percentage_textHeight = textBounds.bottom - textBounds.top;
    int percentage_textWidth = textBounds.right - textBounds.left;
    canvas.drawText(percentStr, center_x - percentage_textWidth / 2,
        center_y - percentage_textHeight / 3, paint);

    paint.setColor(Color.GRAY);
    paint.setTextSize(30);
    textBounds = new Rect();
    String efficiencyStr = "efficiency";
    paint.getTextBounds(efficiencyStr, 0, efficiencyStr.length(), textBounds);
    int efficiency_textHeight = textBounds.bottom - textBounds.top;
    int efficiency_textWidth = textBounds.right - textBounds.left;
    canvas.drawText(efficiencyStr, center_x - efficiency_textWidth / 2,
        center_y + efficiency_textHeight, paint);

    invalidate();
  }
}
