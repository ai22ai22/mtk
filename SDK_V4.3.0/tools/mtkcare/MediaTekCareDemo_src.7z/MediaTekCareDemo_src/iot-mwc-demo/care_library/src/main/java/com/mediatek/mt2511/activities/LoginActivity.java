package com.mediatek.mt2511.activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.util.Pair;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.jakewharton.rxbinding.widget.RxTextView;
import com.jakewharton.rxbinding.widget.TextViewTextChangeEvent;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.pojo.LoginRequest;
import com.mediatek.mt2511.models.pojo.LoginResponse;
import com.mediatek.mt2511.services.UserSession;
import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.Func2;

/**
 * Created by MTK40526 on 4/25/2016.
 */
public class LoginActivity extends AppCompatActivity {
  EditText mTxtAccount;
  EditText mTxtPassword;
  TextInputLayout mInputAccount;
  TextInputLayout mInputPassword;
  Button mBtnSignIn;

  private SharedPreferences sp;
  private Subscription mLoginSubscription;

  @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_login);
    initView();
    sp = getSharedPreferences("LoginInfo", Context.MODE_PRIVATE);
    restoreInput();
    Observable<TextViewTextChangeEvent> observableAccount = RxTextView.textChangeEvents(mTxtAccount)
        .skip(1)
        .doOnNext(new Action1<TextViewTextChangeEvent>() {
          @Override public void call(TextViewTextChangeEvent textViewTextChangeEvent) {
            if (TextUtils.isEmpty(textViewTextChangeEvent.text())) {
              mInputAccount.setError(getString(R.string.invalid_account));
            } else {
              mInputAccount.setErrorEnabled(false);
            }
          }
        });
    Observable<TextViewTextChangeEvent> observablePassword =
        RxTextView.textChangeEvents(mTxtPassword)
            .skip(1)
            .doOnNext(new Action1<TextViewTextChangeEvent>() {
              @Override public void call(TextViewTextChangeEvent textViewTextChangeEvent) {
                if (TextUtils.isEmpty(textViewTextChangeEvent.text())) {
                  mInputPassword.setError(getString(R.string.invalid_account));
                } else {
                  mInputPassword.setErrorEnabled(false);
                }
              }
            });

    Observable.combineLatest(observableAccount, observablePassword,
        new Func2<TextViewTextChangeEvent, TextViewTextChangeEvent, Pair<String, String>>() {
          @Override
          public Pair<String, String> call(TextViewTextChangeEvent textViewTextChangeEvent,
              TextViewTextChangeEvent textViewTextChangeEvent2) {
            return new Pair<String, String>(textViewTextChangeEvent.text().toString(),
                textViewTextChangeEvent2.text().toString());
          }
        }).subscribe(new Subscriber<Pair<String, String>>() {
      @Override public void onCompleted() {

      }

      @Override public void onError(Throwable e) {

      }

      @Override public void onNext(Pair<String, String> pair) {
        Log.v(pair.first, pair.second);
        mBtnSignIn.setEnabled(!TextUtils.isEmpty(pair.first) && !TextUtils.isEmpty(pair.second));
      }
    });

    if (isFormValid(false)) {
      doSignIn();
    }
  }

  private void initView() {
    mTxtAccount = (EditText) findViewById(R.id.txt_account);
    mTxtPassword = (EditText) findViewById(R.id.txt_password);
    mInputAccount = (TextInputLayout) findViewById(R.id.input_layout_account);
    mInputPassword = (TextInputLayout) findViewById(R.id.input_layout_password);
    mBtnSignIn = (Button) findViewById(R.id.btn_sign_in);
    findViewById(R.id.btn_sign_in).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        doSignIn();
      }
    });
  }

  private boolean isFormValid(boolean showAlert) {
    boolean flag = true;
    String account = mTxtAccount.getText().toString();
    String password = mTxtPassword.getText().toString();
    if (TextUtils.isEmpty(account)) {
      mInputAccount.setError(getString(R.string.invalid_account));
      flag = false;
    } else {
      mInputAccount.setErrorEnabled(false);
    }
    if (TextUtils.isEmpty(password)) {
      mInputPassword.setError(getString(R.string.invalid_password));
      flag = false;
    } else {
      mInputPassword.setErrorEnabled(false);
    }
    mInputAccount.setErrorEnabled(showAlert);
    mInputPassword.setErrorEnabled(showAlert);
    return flag;
  }

  void doSignIn() {
    if (isFormValid(true)) {
      View view = this.getCurrentFocus();
      if (view != null) {
        InputMethodManager imm =
            (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
      }

      LoginRequest loginRequest = new LoginRequest();
      loginRequest.password = mTxtPassword.getText().toString();
      loginRequest.username = mTxtAccount.getText().toString();
      final ProgressDialog progressDialog = ProgressDialog.show(this, getString(R.string.sign_in),
          getString(R.string.waiting_a_moment), true);
      mLoginSubscription = UserSession.getInstance()
          .login(loginRequest)
          .observeOn(AndroidSchedulers.mainThread())
          .subscribe(new Subscriber<LoginResponse>() {
            @Override public void onCompleted() {
              mLoginSubscription = null;
            }

            @Override public void onError(Throwable e) {
              progressDialog.dismiss();
              Toast.makeText(LoginActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
            }

            @Override public void onNext(LoginResponse loginResponse) {
              progressDialog.dismiss();
              finish();
              Intent intent = new Intent(LoginActivity.this, DevicesActivity.class);
              startActivity(intent);
              saveInput();
            }
          });
    }
  }

  @Override protected void onDestroy() {
    super.onDestroy();
    if (mLoginSubscription != null) {
      mLoginSubscription.unsubscribe();
    }
  }

  private void saveInput() {

    sp.edit()
        .putString("account", mTxtAccount.getText().toString())
        .putString("password", mTxtPassword.getText().toString())
        .commit();
  }

  private void restoreInput() {
    mTxtAccount.setText(sp.getString("account", ""));
    mTxtPassword.setText(sp.getString("password", ""));
  }
}
