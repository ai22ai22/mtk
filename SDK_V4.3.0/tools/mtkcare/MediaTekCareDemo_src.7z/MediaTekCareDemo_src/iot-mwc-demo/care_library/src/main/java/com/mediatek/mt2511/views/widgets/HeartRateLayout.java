package com.mediatek.mt2511.views.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.mediatek.iot.Device;
import com.mediatek.iot.data.bt.HeartRateData;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.bluetooth.BLEDeviceFactory;
import com.mediatek.mt2511.bluetooth.data.BLEHeartRateData;
import com.mediatek.utils.RxBus;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;

public class HeartRateLayout extends LinearLayout {
  TextView mTxtHeartRate1;
  TextView mTxtHeartRate2;
  ViewGroup mLayoutHeartRate2;
  TextView mTxtLabelHR1;
  TextView mTxtLabelHR2;

  private Device mBLEDevice = BLEDeviceFactory.getBLEDevice();

  private CompositeSubscription mSubscriptions = new CompositeSubscription();

  public HeartRateLayout(Context context) {
    super(context);
    initView();
  }

  public HeartRateLayout(Context context, AttributeSet attrs) {
    super(context, attrs);
    initView();
  }

  public HeartRateLayout(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    initView();
  }

  private void initView() {
    inflate(getContext(), R.layout.view_heart_rate_layout, this);
    mTxtHeartRate1 = (TextView) findViewById(R.id.heart_rate_1);
    mTxtHeartRate2 = (TextView) findViewById(R.id.heart_rate_2);
    mLayoutHeartRate2 = (ViewGroup) findViewById(R.id.layout_heart_rate_2);
    mTxtLabelHR1 = (TextView) findViewById(R.id.txt_label_hr2);
    mTxtLabelHR2 = (TextView) findViewById(R.id.txt_label_hr2);
  }

  @Override protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    subscribeData();
  }

  private void subscribeData() {
    mSubscriptions.add(mBLEDevice.getStateObservable()
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<Integer>() {
          @Override public void call(Integer state) {
            mLayoutHeartRate2.setVisibility(
                state == Device.STATE_CONNECTED ? View.VISIBLE : View.GONE);
            mTxtLabelHR1.setText(state == Device.STATE_CONNECTED ? "Heart Rate - 1" : "Heart Rate");
          }
        }));

    mSubscriptions.add(RxBus.getInstance()
        .toObservable(BLEHeartRateData.class)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<BLEHeartRateData>() {
          @Override public void call(BLEHeartRateData heartRateData) {
            mTxtHeartRate2.setText(String.valueOf(heartRateData.getValue()));
          }
        }));

    mSubscriptions.add(RxBus.getInstance()
        .toObservable(HeartRateData.class)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<HeartRateData>() {
          @Override public void call(HeartRateData heartRateData) {
            int hr = heartRateData.get(HeartRateData.FIELD_BPM);
            String bmp_view_value = String.valueOf(hr);
            mTxtHeartRate1.setText(bmp_view_value);
          }
        }));
  }

  @Override protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    mSubscriptions.clear();
  }
}
