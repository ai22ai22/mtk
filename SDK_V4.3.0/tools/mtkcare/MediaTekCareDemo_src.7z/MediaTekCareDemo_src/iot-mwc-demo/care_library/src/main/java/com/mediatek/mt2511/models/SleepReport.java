package com.mediatek.mt2511.models;

import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.entity.ReportsEntity;
import com.mediatek.mt2511.utils.DateUtils;
import com.mediatek.mt2511.utils.UIUtils;
import java.util.Locale;
import lombok.Getter;

@Getter public class SleepReport {

  private int sleepReportId;
  private int efficiency;
  private String asleepDate;
  private String asleepTime;
  private String duration;

  public final class Status {
    private Status() {}
    public static final int FINE = 0;
    public static final int GOOD = 1;
    public static final int BAD = 2;
    public static final int AWFUL = 3;
  }

  public SleepReport(ReportsEntity entity) {
    this.sleepReportId = entity.getSleepReportId();
    this.efficiency = UIUtils.roundDown(entity.getEfficiency());
    this.asleepDate = DateUtils.formatApiDate(entity.getAsleepAt());
    this.asleepTime = DateUtils.formatApiTime(entity.getAsleepAt());
    this.duration = formatDuration(entity.getDuration());
  }

  public String getStatusText() {
    switch (getStatusOf(this.efficiency)) {
      case Status.FINE: return "Fair";
      case Status.GOOD: return "Good";
      case Status.BAD: return "Poor";
      case Status.AWFUL: return "Bad";
      default: return "";
    }
  }

  public int getStatusColor() {
    switch (getStatusOf(this.efficiency)) {
      case Status.FINE: return R.color.gs_green;
      case Status.GOOD: return R.color.gs_blue;
      case Status.BAD: return R.color.gs_yellow;
      case Status.AWFUL: return R.color.gs_red;
      default: return R.color.gs_light_gray;
    }
  }

  private int getStatusOf(int efficiency) {
    return efficiency >= 90 ? Status.GOOD
        : efficiency >= 70 ? Status.FINE
        : efficiency >= 50 ? Status.BAD
        : Status.AWFUL;
  }

  /**
   * Since {@link DateUtils#formatDate(String, String, String)}
   * would display hours in 24-hour format, duration that over 24 hours
   * would not be formatted correctly.
   * @param duration value from {@link ReportsEntity}.
   * @return formatted duration
   */
  private String formatDuration(String duration) {
    try {
      String inputFormat = "HH:mm:ss";
      String outputFormat = "%1$s:%2$s";  // H時 mm分

      String[] durations = duration.split(":");
      String hour = Integer.toString(Integer.parseInt(durations[0]));
      String min = durations[1];

      return String.format(Locale.getDefault(), outputFormat, hour, min);
    } catch (Exception e) {
      return "";
    }
  }
}
