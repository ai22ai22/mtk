package com.mediatek.mt2511.presentation;

import com.mediatek.mt2511.fragments.UserListFragment;
import com.mediatek.mt2511.models.PersonalModel;
import com.mediatek.mt2511.models.PersonalProfileEntity;
import io.realm.RealmResults;

public class UserListFragmentPresenter implements Presenter<UserListFragment>{
  private UserListFragment view;
  private PersonalModel personalModel = PersonalModel.getDefault();
  @Override public void setView(UserListFragment view) {
    this.view = view;
  }
  public RealmResults<PersonalProfileEntity> getAllPersonalModel(){
    return personalModel.getAllPersonalModel();
  }
}
