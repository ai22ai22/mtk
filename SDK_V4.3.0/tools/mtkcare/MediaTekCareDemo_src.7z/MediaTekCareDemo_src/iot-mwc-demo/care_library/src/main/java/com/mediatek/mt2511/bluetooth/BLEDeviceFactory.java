package com.mediatek.mt2511.bluetooth;

import com.mediatek.iot.Device;
import com.mediatek.iot.Scanner;
import com.mediatek.iot.ble.BLEDevice;
import com.mediatek.iot.ble.BLEDeviceScanner;
import com.mediatek.iot.data.BaseData;
import com.mediatek.iot.data.DataParser;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.bluetooth.data.BLEHeartRateData;
import java.io.IOException;

public class BLEDeviceFactory {
  private static Scanner sBLEScanner;
  private static Device sBLEDevice;

  public static Scanner getBLEScanner() {
    if (sBLEScanner == null) {
      sBLEScanner = new BLEDeviceScanner(MContext.getInstance().getApplication(), 30000,30000);
    }
    return sBLEScanner;
  }

  public static Device getBLEDevice() {
    if (sBLEDevice == null) {
      BLEDevice.Builder builder = new BLEDevice.Builder();
      builder.setAutoReconnect(false, Integer.MAX_VALUE)
          .setServiceUUID("0000180d-0000-1000-8000-00805f9b34fb")
          .setCharacteristicUUID("00002a37-0000-1000-8000-00805f9b34fb");
      sBLEDevice = builder.create(MContext.getInstance().getApplication(), new DataParser() {
        @Override protected BaseData parseData(byte[] data) throws IOException {
          return new BLEHeartRateData(data);
        }

        @Override public void reset() {

        }
      });
    }
    return sBLEDevice;
  }
}
