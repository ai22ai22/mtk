package com.mediatek.mt2511.views.chart;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.SleepContent;
import com.mediatek.mt2511.models.SleepContent.ChartData;
import com.mediatek.mt2511.models.SleepContent.Stage;
import com.mediatek.mt2511.utils.MContextCompat;
import java.util.List;

public class SleepStagesChart extends LinearLayout {
  private ChartData chartData;
  private SleepStagesChartConstant sleepStagesChartConstant = new SleepStagesChartConstant();
  private Canvas canvas;
  private Paint paint;

  private int textWidth = 0;
  private int textHeight = 0;
  private float width = 0;
  private int height = 0;
  private float position_x = 10;
  private boolean draw_flag = false;

  public SleepStagesChart(Context context) {
    super(context);
    initViews();
  }

  public SleepStagesChart(Context context, AttributeSet attrs) {
    super(context, attrs);
    initViews();
  }

  public SleepStagesChart(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    initViews();
  }

  private void initViews() {
    inflate(getContext(), R.layout.detail_bar_chart, this);
    this.paint = new Paint();
    setWillNotDraw(false);
  }

  @Override public void onDraw(Canvas canvas){
    super.onDraw(canvas);
    this.canvas = canvas;
    sleepStagesChartConstant.convertUnit(getContext());

    drawLabel(generateFooStage(Stage.DEEP));
    drawLabel(generateFooStage(Stage.LIGHT));
    drawLabel(generateFooStage(Stage.REM));
    drawLabel(generateFooStage(Stage.AWAKE));

    if (!draw_flag) { invalidate(); }
    else { drawDetailBarChart(); }

    resetPosition();
  }

  public void setChartData(ChartData chart) {
    this.chartData = chart;
    draw_flag = true;
  }

  private Stage generateFooStage(int stage) {
    return new Stage(stage, new SleepContent.Time(0, 0), "0");
  }

  private void drawLabel(Stage stage) {
    float text_y = 0;
    String stageStr = stage.getStageText();
    this.width = this.getWidth();
    this.height = this.getHeight();
    float circle_center_y = this.height - sleepStagesChartConstant.getPx_chart_margin_bottom() / 2;
    this.paint.setStyle(Paint.Style.FILL);
    this.paint.setStrokeWidth(5);
    this.paint.setAntiAlias(true);
    this.paint.setColor(MContextCompat.getColor(getContext(), stage.getStageColor()));
    this.position_x = this.position_x + sleepStagesChartConstant.getPx_label_interval()
        + sleepStagesChartConstant.getPx_doc_radius() * 2 + this.textWidth;
    this.canvas.drawCircle(this.position_x, circle_center_y,
        sleepStagesChartConstant.getPx_doc_radius(), this.paint);

    this.paint.setColor(Color.BLACK);
    this.paint.setTextSize(sleepStagesChartConstant.getPx_label_text_size());
    this.paint.setStrokeWidth(1);
    Rect textBounds = new Rect();
    this.position_x = this.position_x + sleepStagesChartConstant.getPx_label_sub_interval()
        + sleepStagesChartConstant.getPx_doc_radius();
    this.paint.getTextBounds(stageStr, 0, stageStr.length(), textBounds);
    this.textWidth = textBounds.right - textBounds.left;
    this.textHeight = textBounds.bottom - textBounds.top;
    text_y = this.height - sleepStagesChartConstant.getPx_chart_margin_bottom() / 2
        + this.textHeight / 2;
    this.canvas.drawText(stageStr, this.position_x, text_y, this.paint);
  }

  private void resetPosition() {
    this.position_x = 10;
    this.textWidth = 0;
  }

  private void drawDetailBarChart() {
    List<Integer> stages = chartData.getStages();
    int currentStage;
    int nextStage;

    float chart_bottom = this.height - sleepStagesChartConstant.getPx_chart_margin_bottom();
    float chart_top = chart_bottom - sleepStagesChartConstant.getPx_chart_height();
    float chart_x_tail = 0;
    float chart_x_head = 0;
    float bar_width = this.width / stages.size();

    Paint paint_barChart = new Paint();
    paint_barChart.setStyle(Paint.Style.FILL);
    paint_barChart.setStrokeWidth(1);
    paint_barChart.setAntiAlias(true);

    for (int i = 0; i < stages.size() - 1; i++) {
      currentStage = stages.get(i);
      nextStage = stages.get(i + 1);
      chart_x_tail += bar_width;

      if (currentStage != nextStage) {
        paint_barChart.setColor(MContextCompat.getColor(getContext(),
            generateFooStage(currentStage).getStageColor()));
        this.canvas.drawRect(chart_x_head, chart_top, chart_x_tail, chart_bottom, paint_barChart);
        chart_x_head = chart_x_tail;
      }
    }

    paint_barChart.setColor(MContextCompat.getColor(getContext(),
        generateFooStage(stages.get(stages.size() - 1)).getStageColor()));
    this.canvas.drawRect(chart_x_head, chart_top, this.width, chart_bottom, paint_barChart);
  }
}
