package com.mediatek.mt2511.models;

/**
 * Created by MTK40526 on 11/1/2016.
 */

public class Record {
    public String userId;
    public String age;
    public String gendor;
    public String height;
    public String weight;
    public String armLength;
    public String disease;
}
