package com.mediatek.mt2511.models.entity;

import com.google.gson.Gson;
import java.util.List;
import lombok.Getter;

@Getter public class ReportsEntity extends ApiResponsesEntity<ReportsEntity> {

  private int sleepReportId;
  private String asleepAt;
  private String awakeAt;
  private String duration;
  private String efficiency;
  private String comment;

  public List<ReportsEntity> getResultsFromJson(String json) {
    return new Gson().fromJson(json, ReportsEntity.class).getResults();
  }

  public ReportsEntity fromJson(String json) {
    return new Gson().fromJson(json, ReportsEntity.class);
  }

  public String toJson() {
    return new Gson().toJson(this);
  }
}
