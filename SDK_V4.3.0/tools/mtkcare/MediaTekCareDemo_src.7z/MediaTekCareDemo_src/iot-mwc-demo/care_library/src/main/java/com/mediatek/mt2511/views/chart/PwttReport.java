package com.mediatek.mt2511.views.chart;

import java.util.ArrayList;
import java.util.List;

public class PwttReport {
  private int max;
  private List<String> xdata;
  private List<Integer> ydata;

  public PwttReport(PwttEntity pwttEntity) {
    xdata = new ArrayList<>();
    ydata = new ArrayList<>();

    if (pwttEntity != null) {
      xdata.addAll(pwttEntity.getData().getXdata());
      ydata.addAll(pwttEntity.getData().getYdata());
    }
  }

  public int getMax() {
    return max;
  }

  public List<String> getXdata() {
    return xdata;
  }

  public List<Integer> getYdata() {
    return ydata;
  }
}
