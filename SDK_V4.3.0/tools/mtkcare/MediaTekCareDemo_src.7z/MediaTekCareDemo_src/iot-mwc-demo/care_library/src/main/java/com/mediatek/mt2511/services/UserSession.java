package com.mediatek.mt2511.services;

import com.mediatek.mt2511.custom.BTDeviceFactory;
import com.mediatek.mt2511.events.RecordChangeEvent;
import com.mediatek.mt2511.models.pojo.LoginRequest;
import com.mediatek.mt2511.models.pojo.LoginResponse;
import com.mediatek.mt2511.network.MyProjectApi;
import com.mediatek.iot.Device;
import com.mediatek.utils.RxBus;
import java.util.HashMap;
import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;

/**
 * Created by MTK40526 on 4/25/2016.
 */
public class UserSession {
  public static final String FIELD_RECORD = "RecordId";
  public static final String FIELD_USERID = "UserId";
  public static final String FIELD_AGE = "Age";
  public static final String FIELD_GENDER = "gender";
  public static final String FIELD_ACCOUNT = "Account";

  public static final int STATE_OFFLINE = 0;
  public static final int STATE_SIGNED_IN = 1;
  private static UserSession instance;
  private int state = STATE_OFFLINE;
  private HashMap<String, Object> sessionData = new HashMap<>();
  private RecordInfo recordInfo;
  private CompositeSubscription mSubscriptions = new CompositeSubscription();
  private RecordInfo defaultProfile;

  private UserSession() {
  }

  public static UserSession getInstance() {
    if (instance == null) {
      instance = new UserSession();
    }
    return instance;
  }

  public synchronized RecordInfo getRecordInfo() {
    return recordInfo;
  }

  public synchronized void saveRecordInfo(RecordInfo recordInfo) {
    this.recordInfo = recordInfo;
    if(recordInfo != null){
      mSubscriptions.add(BTDeviceFactory.getBTDevice().getStateObservable()
          .observeOn(AndroidSchedulers.mainThread())
          .subscribe(new Action1<Integer>() {
        @Override public void call(Integer state) {
          if(state != Device.STATE_CONNECTED){
            clearRecordInfo();
          }
        }
      }));
    }
    RxBus.getInstance().post(new RecordChangeEvent(recordInfo.userId));
  }
  public synchronized void saveDefaultProfile(RecordInfo recordInfo){
    this.defaultProfile = recordInfo;
  }

  public synchronized RecordInfo getDefaultProfile(){
    return defaultProfile;
  }
  public synchronized void clearRecordInfo(){
    mSubscriptions.clear();
    this.recordInfo = null;
    defaultProfile = null;
    RxBus.getInstance().post(new RecordChangeEvent(""));
  }

  public synchronized int getState() {
    return state;
  }

  public Observable<LoginResponse> login(LoginRequest request) {
    return MyProjectApi.getIoTService().login(request).doOnNext(new Action1<LoginResponse>() {
      @Override public void call(LoginResponse loginResponse) {
        setState(STATE_SIGNED_IN);
      }
    });
  }

  public void reset() {
    sessionData.clear();
    setState(STATE_OFFLINE);
  }

  public synchronized void setState(int state) {
    this.state = state;
  }

  public static class RecordInfo {
    public String recordId;
    public String userId;
    public String gender;
    public int age;
    public int weight;
    public int height;
    public int armLen;
  }
}
