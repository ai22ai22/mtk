package com.mediatek.mt2511;

import android.app.Application;
import android.content.Context;
import com.facebook.stetho.Stetho;
import com.mediatek.mt2511.utils.FontsOverride;

public class MBaseApp extends Application {

  @Override public void onCreate() {
    super.onCreate();
    FontsOverride.setDefaultFont(this);
    Stetho.initializeWithDefaults(this);
  }

  @Override protected void attachBaseContext(Context base) {
    super.attachBaseContext(base);
    //     MultiDex.install(this);
  }
}
