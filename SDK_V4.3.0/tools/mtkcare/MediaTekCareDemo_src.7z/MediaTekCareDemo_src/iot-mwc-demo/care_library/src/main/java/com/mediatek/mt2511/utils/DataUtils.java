package com.mediatek.mt2511.utils;

import com.mediatek.mt2511.models.LastInputEntity;
import com.mediatek.mt2511.models.PersonalProfileEntity;
import com.mediatek.mt2511.services.UserSession;

public class DataUtils {

  public static PersonalProfileEntity trans2Profile(LastInputEntity lastInputEntity) {
    PersonalProfileEntity personalProfileEntity = new PersonalProfileEntity();
    personalProfileEntity.setUserId(lastInputEntity.getUserId());
    personalProfileEntity.setAge(DateUtils.calcAge(lastInputEntity.getBirthYear()));
    personalProfileEntity.setGender(lastInputEntity.getGender());
    personalProfileEntity.setWeight(lastInputEntity.getWeight());
    personalProfileEntity.setHeight(lastInputEntity.getHeight());
    personalProfileEntity.setArmLength(lastInputEntity.getArmLength());
    return personalProfileEntity;
  }

  public static PersonalProfileEntity trans2Profile(UserSession.RecordInfo recordInfo) {
    PersonalProfileEntity personalProfileEntity = new PersonalProfileEntity();
    personalProfileEntity.setUserId(recordInfo.userId);
    personalProfileEntity.setAge(recordInfo.age);
    personalProfileEntity.setGender(recordInfo.gender.equals("M") ? 1 : 2);
    personalProfileEntity.setWeight(recordInfo.weight);
    personalProfileEntity.setHeight(recordInfo.height);
    personalProfileEntity.setArmLength(recordInfo.armLen);
    personalProfileEntity.setMode(PersonalProfileEntity.MODE_GENERAL);
    return personalProfileEntity;
  }
}
