package com.mediatek.mt2511.utils;

import android.content.Context;
import android.graphics.Typeface;
import java.lang.reflect.Field;
import java.util.Map;

public final class FontsOverride {

    public static final String FONT_ASSET = "fonts/Mika Melvas - RionaSans-Regular.otf";

    public static void setDefaultFont(Context context) {
        context = context.getApplicationContext();
        final Typeface regular = Typeface.createFromAsset(context.getAssets(),
                FONT_ASSET);
       // replaceFont(staticTypefaceFieldName, regular);

        final Field staticField2;
        try {
            final Field staticField1 = Typeface.class
                    .getDeclaredField("SANS_SERIF");
            staticField1.setAccessible(true);
            staticField1.set(null, regular);
            staticField2 = Typeface.class
                    .getDeclaredField("sSystemFontMap");
            staticField2.setAccessible(true);
            Map<String, Typeface> fontMap =  (Map<String, Typeface>)staticField2.get(null);
            fontMap.put("sans-serif", Typeface.SANS_SERIF);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

    }

    protected static void replaceFont(String staticTypefaceFieldName,
                                      final Typeface newTypeface) {
        try {
            final Field staticField = Typeface.class
                    .getDeclaredField(staticTypefaceFieldName);
            staticField.setAccessible(true);
            staticField.set(null, newTypeface);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
}