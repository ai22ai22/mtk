package com.mediatek.mt2511.models.entity;

import java.util.List;

public class ApiResponsesEntity<T> extends ApiMessageEntity {
  private List<T> results;

  public List<T> getResults() {
    return results;
  }
}
