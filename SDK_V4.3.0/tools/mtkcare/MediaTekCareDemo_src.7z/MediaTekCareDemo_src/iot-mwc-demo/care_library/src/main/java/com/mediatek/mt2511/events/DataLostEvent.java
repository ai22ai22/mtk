package com.mediatek.mt2511.events;

public class DataLostEvent {

  private final String message;

  public DataLostEvent(String message) {
    this.message = message;
  }

  public String getMessage() {
    return message;
  }
}
