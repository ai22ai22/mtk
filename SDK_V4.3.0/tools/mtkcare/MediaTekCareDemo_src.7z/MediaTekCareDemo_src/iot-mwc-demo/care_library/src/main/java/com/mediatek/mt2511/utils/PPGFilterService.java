package com.mediatek.mt2511.utils;

import com.mediatek.mt2511.interfaces.FilterService;

/**
 * Created by MTK40526 on 3/23/2016.
 */
public class PPGFilterService implements FilterService{
    private static final int I4PPGLPFORDER = 20; // Max 20
    private static final float[] P4PPGLPFCOEFF = {
          0.0030f, 0.0100f, 0.0210f, 0.0330f, 0.0470f, 0.0610f, 0.0730f, 0.0840f, 0.0910f, 0.0950f,
          0.0950f, 0.0910f, 0.0840f, 0.0730f, 0.0610f, 0.0470f, 0.0330f, 0.0210f, 0.0100f, 0.0030f
    };
    private float  f4PpgBuf[] = new float[20];
    private boolean initialized = false;
    private int i4PpgBufIndex = 0;
    private float f4PpgDc;
    public PPGFilterService() {
        for(int i=0; i< I4PPGLPFORDER; i++) {
            f4PpgBuf[i] = 0f;
        }
    }

    @Override
    public float filter(float data) {
        if (!initialized){
            f4PpgDc = data;
            initialized = true;
        }
        f4PpgDc += (data - f4PpgDc) / 32;
        f4PpgBuf[i4PpgBufIndex % I4PPGLPFORDER] = (data - f4PpgDc);
        float varLPF = 0;
        for (int idx = 0; idx < I4PPGLPFORDER; idx++) {
            varLPF += P4PPGLPFCOEFF[idx] * f4PpgBuf[(i4PpgBufIndex + idx) % I4PPGLPFORDER];
        }
        i4PpgBufIndex = (i4PpgBufIndex + 1) % I4PPGLPFORDER;
        return varLPF;
    }
}
