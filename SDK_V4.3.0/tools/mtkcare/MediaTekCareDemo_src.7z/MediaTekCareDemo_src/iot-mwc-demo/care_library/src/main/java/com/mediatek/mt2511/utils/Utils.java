package com.mediatek.mt2511.utils;

public class Utils {

  //static {
  //  System.loadLibrary("eb-jni");
  //}

  public static int estimateAge(int sdnn_in, int real_age) {
    return estimate_age(sdnn_in, real_age, 120);
  }

  //public static native int estimate_age(int sdnn_in, int real_age, int recording_time_sec);

  public static int estimate_age(int sdnn_in, int real_age, int recording_time_sec) {
    float est_age;
    float factor;
    float sdnn_tmp = 0.0f;

    if (sdnn_in > 1000) // only the sdnn from watch will be larger than 1000
    {
      sdnn_tmp = (float) sdnn_in / 1000.0f;
    }

    if (recording_time_sec
        <= 120) // if the recording time is less than 120 sec, the sdnn value will be modified
    {
      factor = -0.0018f * (float) recording_time_sec + 1.35f;
      sdnn_tmp = (float) (sdnn_tmp * factor);
    }

    est_age = (sdnn_tmp - 80.4f) / -1.04f;  // calculate estimated age
    if (real_age > 10 && real_age < 90) // refine est_age if we have real_age as input
    {
      est_age = (est_age < real_age - 9) ? real_age - 9 : est_age;
      est_age = (est_age > real_age + 9) ? real_age + 9 : est_age;
    }
    return (int) est_age;
  }

  public static String calcStatus(int realAge, int sdnn_in, int hr) {
    float sdnn = getFixedPoint(sdnn_in);
    float normal_sdnn = -1.04f * realAge + 80.4f;
    float normal_hr = 80;
    String status = "Normal";
    if (sdnn >= normal_sdnn) {
      if (hr >= normal_hr) {
        status = HrvStatus.EXCITED;
      } else {
        status = HrvStatus.GOOD;
      }
    } else {
      if (hr >= normal_hr) {
        status = HrvStatus.STRESSED;
      } else {
        status = HrvStatus.DEPRESSED;
      }
    }
    return status;
  }

  public static String getStatusForApi(int realAge, int sdnn, int hr) {
    return HrvStatus.toApiValue(calcStatus(realAge, sdnn, hr));
  }

  /**
   * only the lf, hf, lfHf, sdnn from Band will be larger than 1000
   */
  public static float getFixedPoint(int value) {
    if (value > 1000) {
      return (float) value / 1000.0f;
    } else {
      return (float) value;
    }
  }
}
