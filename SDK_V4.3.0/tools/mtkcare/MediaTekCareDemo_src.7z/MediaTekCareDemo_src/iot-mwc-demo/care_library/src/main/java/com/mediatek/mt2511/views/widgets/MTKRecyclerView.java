package com.mediatek.mt2511.views.widgets;

import android.content.Context;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.util.AttributeSet;
import com.marshalchen.ultimaterecyclerview.UltimateRecyclerView;

public class MTKRecyclerView extends UltimateRecyclerView {

  public MTKRecyclerView(Context context) {
    super(context);
  }

  public MTKRecyclerView(Context context, AttributeSet attrs) {
    super(context, attrs);
  }

  public MTKRecyclerView(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
  }

  @Override protected void initViews() {
    super.initViews();
    setLayoutManager(new LinearLayoutManager(getContext()));
    setItemAnimator(new DefaultItemAnimator());
  }
}
