package com.mediatek.mt2511.views.adapters;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout.LayoutParams;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.activities.ReportDetailActivity;
import com.mediatek.mt2511.models.SleepReport;
import com.mediatek.mt2511.utils.UIUtils;
import com.mediatek.mt2511.views.chart.SleepEfficienciesChart;
import com.mediatek.mt2511.views.widgets.ReportsItemDesc;
import com.mediatek.mt2511.views.widgets.SleepEfficiencyRing;
import java.util.List;

public class ReportsAdapter extends GsListAdapter<SleepReport, ReportsAdapter.ViewHolder> {

  SleepReport report;

  public ReportsAdapter(Activity activity, List<SleepReport> reports) {
    super(activity, reports);
  }

  /**
   * Specific header create function
   */
  @Override public ViewHolder getViewHolder(View view) {
    final int DP_CHART_HEIGHT = 210;
    view.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,
        UIUtils.dpToPx(DP_CHART_HEIGHT, mActivity)));
    return new ViewHolder(view, VIEW_TYPES.HEADER);
  }

  @Override public ViewHolder onCreateViewHolder(ViewGroup viewGroup) {
    View v = mInflater.inflate(R.layout.report_cardview, viewGroup, false);
    return new ViewHolder(v, VIEW_TYPES.NORMAL);
  }

  @Override public void onBindViewHolder(ViewHolder viewHolder, int i) {
    i = getAlignedPosition(i);
    if (i == -1) {
      viewHolder.report_chart.setReports(mDataList);
    } else if (i < mDataList.size()) {
      report = mDataList.get(i);
      viewHolder.status_desc.setSleepReport(report);
      viewHolder.report_ring.setSleepReport(report);
      viewHolder.itemView.setOnClickListener(
          new View.OnClickListener() {
            public void onClick(View v) {
              Intent intent = new Intent(mActivity, ReportDetailActivity.class);
              intent.putExtra("asleepDate", report.getAsleepDate());
              intent.putExtra("sleepReportId", report.getSleepReportId());
              mActivity.startActivity(intent);
            }
          });
    }
  }

  /**
   * The view lists of report recyclerView is believe to have VIEW_TYPES.HEADER as the first index
   * only, so it is necessary to align the index.
   *
   * @param position The position of the item within the adapter's data set.
   * @return aligned position.
   */
  private int getAlignedPosition(int position) {
    return (customHeaderView != null) ? --position : position;
  }

  /**
   * The view lists of report recyclerView is believe to have VIEW_TYPES.HEADER as the first index
   * only, so it is necessary to align the item count.
   *
   * @return aligned item count.
   */
  @Override public int getItemCount() {
    return mDataList == null ? 0 :
        mDataList.size() == 0 ? 0 :
            customHeaderView != null ? mDataList.size() + 1 : mDataList.size();
  }

  public static class ViewHolder extends RecyclerView.ViewHolder {
    public ReportsItemDesc status_desc;
    public SleepEfficiencyRing report_ring;
    public SleepEfficienciesChart report_chart;

    public ViewHolder(View v, int viewType) {
      super(v);
      if (viewType == VIEW_TYPES.HEADER) {
        report_chart = (SleepEfficienciesChart) v.findViewById(R.id.chart_sleep_efficiencies);
      } else {
        status_desc = (ReportsItemDesc) v.findViewById(R.id.report_desc);
        report_ring = (SleepEfficiencyRing) v.findViewById(R.id.report_ring);
      }
    }
  }
}
