package com.mediatek.mt2511.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.SleepReport;
import com.mediatek.mt2511.models.entity.ReportsEntity;
import com.mediatek.mt2511.views.adapters.ReportsAdapter;
import com.mediatek.mt2511.views.widgets.MTKRecyclerView;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class ReportsFragment extends CustomFragment {

  MTKRecyclerView rv_reports;
  private List<SleepReport> reports = new ArrayList<>();

  public ReportsFragment() {
    setTitle(MContext.getInstance().getApplication().getString(R.string.sleep_report));
  }

  protected View inflate(int layoutResId, LayoutInflater inflater, ViewGroup container) {
    View v = inflater.inflate(layoutResId, container, false);

    initView(v);
    setHasOptionsMenu(true);
    return v;
  }

  private void initView(View view) {
    rv_reports = (MTKRecyclerView) view.findViewById(R.id.rv_reports);
  }

  @Override public View onCreateView(LayoutInflater inflater, ViewGroup container,
      Bundle savedInstanceState) {

    View v = inflate(R.layout.fragment_reports, inflater, container);
    ReportsAdapter reportsAdapter = new ReportsAdapter(getActivity(), reports);
    rv_reports.setAdapter(reportsAdapter);
    rv_reports.setParallaxHeader(R.layout.widget_sleep_efficiencies_chart);
    rv_reports.setEmptyView(R.layout.widget_reports_empty_view);

    if (reports.size() == 0) {
      getApiData();
    }
    return v;
  }

  //  @Override public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
  //    inflater.inflate(R.menu.reports, menu);
  //    super.onCreateOptionsMenu(menu, inflater);
  //  }
  //
  //  @Override public boolean onOptionsItemSelected(MenuItem item) {
  //    switch (item.getItemId()) {
  //      case R.id.ic_action_watch_sync:
  //        /**
  //         * TODO: syncWatchService
  //         */
  //        return true;
  //      default:
  //        return super.onOptionsItemSelected(item);
  //    }
  //  }

  private void getApiData() {

    String hardcode = loadJSONFromAsset();

    List<ReportsEntity> apiResults = new ReportsEntity().getResultsFromJson(hardcode);

    for (ReportsEntity reportsEntity : apiResults) {
      reports.add(new SleepReport(reportsEntity));
    }
    rv_reports.getAdapter().notifyDataSetChanged();

    if (reports.size() == 0) {
      rv_reports.showEmptyView();
    }
  }

  public String loadJSONFromAsset() {
    String json = null;
    try {
      //InputStream is = getAssets().open("raw/sleep_staging.json");

      InputStream is = getResources().openRawResource(R.raw.sleep_reports);
      int size = is.available();
      byte[] buffer = new byte[size];
      is.read(buffer);
      is.close();
      json = new String(buffer, "UTF-8");
    } catch (IOException ex) {
      ex.printStackTrace();
      return null;
    }
    return json;
  }
}

