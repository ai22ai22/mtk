package com.mediatek.mt2511.fragments;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.exceptions.AbortException;
import com.mediatek.mt2511.interfaces.ShowProfile;
import com.mediatek.mt2511.interfaces.Titled;
import com.mediatek.mt2511.interfaces.closeable;
import com.mediatek.mt2511.models.BTCommandModel;
import com.mediatek.mt2511.models.Golden;
import com.mediatek.mt2511.models.LastInputEntity;
import com.mediatek.mt2511.models.PersonalModel;
import com.mediatek.mt2511.presentation.CalibrationFragmentPresenter;
import com.mediatek.mt2511.presentation.CreatePersonalModelPresenter;
import com.mediatek.mt2511.presentation.InputGoldenPresenter;
import com.mediatek.mt2511.utils.RxUtils;
import com.mediatek.mt2511.views.CreatePersonalDialog;
import com.mediatek.mt2511.views.InputGoldenDialog;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

public class CalibrationFragment extends Fragment implements Titled, closeable, ShowProfile {
  private CalibrationFragmentPresenter presenter;
  private TextView mTxtProfile;
  private TextView mTxtHint;
  private ProgressDialog mProgressDialog;

  public CalibrationFragment() {
    super();
    setHasOptionsMenu(true);
    presenter =
        new CalibrationFragmentPresenter(BTCommandModel.getDefault(), PersonalModel.getDefault());
    presenter.setView(this);
  }

  @Override public String getTitle() {
    return MContext.getInstance().getApplication().getString(R.string.calibration);
  }

  @Override public boolean isActive() {
    return false;
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_bp_measure_calibration, container, false);
    initView(view);
    presenter.startCalibrationFlow();
    return view;
  }

  private void initView(View view) {
    mTxtProfile = (TextView) view.findViewById(R.id.txt_profile_user_id);
    mTxtHint = (TextView) view.findViewById(R.id.txt_hint);
  }

  public void setCurrentProfileComplete(String userId) {
    mTxtProfile.setText(userId);
    mTxtProfile.setVisibility(View.VISIBLE);
  }

  @Override public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
    inflater.inflate(R.menu.bp_measure_calibration_menu, menu);
  }

  @Override public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == R.id.action_user_list) {
      preClose().observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<String>() {
        @Override public void onCompleted() {
          exit();
        }

        @Override public void onError(Throwable e) {
          Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
        }

        @Override public void onNext(String s) {

        }
      });

      return true;
    }
    return false;
  }

  public Observable<LastInputEntity> getPersonalModel() {
    return new CreatePersonalDialog(getActivity(),
        new CreatePersonalModelPresenter(PersonalModel.getDefault(),
            BTCommandModel.getDefault())).show();
  }

  public Observable<String> showSuccess() {
    return Observable.create(new Observable.OnSubscribe<String>() {
      @Override public void call(final Subscriber<? super String> subscriber) {

        Timber.d("===showSuccess:");

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.successful)
            .setMessage(R.string.calibartion_successful_mesage)
            .setCancelable(false)
            .setPositiveButton(R.string.btn_done, new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialogInterface, int i) {
                subscriber.onCompleted();
                dialogInterface.dismiss();
              }
            });
        builder.create().show();
      }
    });
  }

  public void exit() {
    Fragment fragment = getParentFragment();
    if (fragment instanceof BPMeasurePersonalFragment) {
      ((BPMeasurePersonalFragment) fragment).showUserList();
    }
    presenter.exit();
  }

  @Override public void onDestroy() {
    super.onDestroy();
    presenter.exit();
  }

  public Observable<Golden> getInputGolden(int step) {
    return new InputGoldenDialog(getActivity(), new InputGoldenPresenter(), step).show();
  }

  public void showProgressLoading() {
    mProgressDialog = ProgressDialog.show(getActivity(), getString(R.string.loading),
        getString(R.string.waiting_a_moment), false);
  }

  public void dismissProgressLoading(Throwable e) {
    if (e != null) {
      Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
    }
    if (mProgressDialog != null) {
      mProgressDialog.dismiss();
      mProgressDialog = null;
    }
  }

  @Override public Observable<String> preClose() {
    return Observable.create(new Observable.OnSubscribe<String>() {
      @Override public void call(final Subscriber<? super String> subscriber) {
        RxUtils.alertDialog(getActivity(), getString(R.string.confirm),
            getString(R.string.are_you_sure_exit), getString(R.string.btn_ok))
            .subscribe(new Subscriber<Boolean>() {
              @Override public void onCompleted() {
                subscriber.onCompleted();
              }

              @Override public void onError(Throwable e) {

              }

              @Override public void onNext(Boolean wantExit) {
                if (wantExit) {
                  subscriber.onCompleted();
                } else {
                  subscriber.onError(new AbortException("User cancelled"));
                }
              }
            });
      }
    });
  }

  @Override public void close() {
    presenter.exit();
  }

  public void showStepTitle(int step) {
    Fragment fragment = getParentFragment();
    if (fragment instanceof BPMeasurePersonalFragment) {
      ((BPMeasurePersonalFragment) fragment).setTitle(
          step > 0 ? step + ". Calibration" : "Calibration");
    }
    mTxtHint.setText("");
    if(step == 3){
      mTxtHint.setText(R.string.calibration_hint);
    }
  }
}
