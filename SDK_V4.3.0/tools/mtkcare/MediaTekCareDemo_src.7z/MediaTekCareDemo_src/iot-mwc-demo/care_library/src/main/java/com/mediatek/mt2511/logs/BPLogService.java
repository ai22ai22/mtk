package com.mediatek.mt2511.logs;

import com.mediatek.mt2511.services.UserSession;

public class BPLogService extends LogToFileService {
  private static BPLogService bpLogService;

  private BPLogService(FileNameGenerator fileNameGenerator) {
    super(fileNameGenerator);
  }

  public static BPLogService getInstance() {
    if (bpLogService == null) {
      bpLogService = new BPLogService(new FileNameGenerator() {
        @Override public String generate() {
          String fileName = LogUtils.getCatchLogPath() + "/" + LogUtils.formatFileName(
              LogUtils.format(System.currentTimeMillis()) + "_" + UserSession.getInstance()
                  .getRecordInfo().userId + "_bp.txt");
          return fileName;
        }
      });
    }
    return bpLogService;
  }
}
