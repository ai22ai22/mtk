package com.mediatek.mt2511;


import com.mediatek.mt2511.fragments.HRVFragment;
import com.mediatek.mt2511.fragments.MeasureFragment;
import com.mediatek.mt2511.fragments.ReportsFragment;

/**
 * Created by MTK40526 on 4/25/2016.
 */
public class AppConstants {
  public static final int REQUEST_ENABLE_BLUETOOTH = 1;
  public static final int REQUEST_BLE = 1;
  public static final int REQUEST_ADD_RECORD = 2;
  public static final int START_ACTIVITY_FOR_RESULT_ADD_RECORD = 10;

  public static final String BP_DATA_SBP = "SBP";
  public static final String BP_DATA_DBP = "DBP";
  public static final String BP_DATA_HR = "HR";
  public static final String BP_DATA_PWTT_LIST = "PWTT_Array";

  public static final int SENSOR_SPP_DATA_MAGIC = 54321;

  public static final String FRAGMENT_MEASURE = MeasureFragment.class.getName();
  public static final String FRAGMENT_HRV = HRVFragment.class.getName();
  public static final String FRAGMENT_REPORTS = ReportsFragment.class.getName();
  public static final String INTENT_DATA_FRAGMENT = "FRAGMENTS";
}
