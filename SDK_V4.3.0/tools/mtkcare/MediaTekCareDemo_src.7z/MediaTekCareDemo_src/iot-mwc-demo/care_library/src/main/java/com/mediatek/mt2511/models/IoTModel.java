package com.mediatek.mt2511.models;

/**
 * Created by MTK40526 on 1/28/2016.
 */
public class IoTModel {
    static private IoTModel instance;

    static public IoTModel getInstance() {
        if (instance == null) {
            instance = new IoTModel();
        }
        return instance;
    }
    private IoTModel() { }

}
