package com.mediatek.mt2511.apx;

public class APResult {
	private int latency = 0;
	private int discardTestStartTime = 0;
	private int discardGoldStartTime = 0;
	private int duration = 0;
	private int[] errorArray;
	private double min_mean_error = 0.0f;
	private double std_error = 0.0f;
	private double availability5 = 0.0f;
	private double availability10 = 0.0f;
	
	public int getLatency() {
		return latency;
	}

	public void setLatency(int latency) {
		this.latency = latency;
	}

	public int getDiscardTestStartTime() {
		return discardTestStartTime;
	}

	public void setDiscardTestStartTime(int discardTestStartTime) {
		this.discardTestStartTime = discardTestStartTime;
	}

	public int getDiscardGoldStartTime() {
		return discardGoldStartTime;
	}

	public void setDiscardGoldStartTime(int discardGoldStartTime) {
		this.discardGoldStartTime = discardGoldStartTime;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int[] getErrorArray() {
		return errorArray;
	}

	public void setErrorArray(int[] errorArray) {
		this.errorArray = errorArray;
	}

	public double getMin_mean_error() {
		return min_mean_error;
	}

	public void setMin_mean_error(double min_mean_error) {
		this.min_mean_error = min_mean_error;
	}

	public double getStd_error() {
		return std_error;
	}

	public void setStd_error(double std_error) {
		this.std_error = std_error;
	}

	public double getAvailability5() {
		return availability5;
	}

	public void setAvailability5(double availability5) {
		this.availability5 = availability5;
	}

	public double getAvailability10() {
		return availability10;
	}

	public void setAvailability10(double availability10) {
		this.availability10 = availability10;
	}

	public APResult(double min_mean_error, double std_error, int discardTestStartTime, int discardGoldStartTime,
			int duration, int[] errorArray,int latency, double availability10, double availability5) {
	  super();
	  this.latency = latency;
	  this.discardTestStartTime = discardTestStartTime;
	  this.discardGoldStartTime = discardGoldStartTime;
	  this.duration = duration;
	  this.errorArray = errorArray;
	  this.min_mean_error = min_mean_error;
	  this.std_error = std_error;
	  this.availability5 = availability5;
	  this.availability10 = availability10;
  }
	
}
