package com.mediatek.mt2511.logs;

import android.util.Log;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class LogToFileService {
  private final static String TAG = "LogToFileService";
  private final FileNameGenerator fileNameGenerator;
  private BufferedWriter mWriter;
  private boolean inRecording = false;
  private File currentFile;

  public LogToFileService(FileNameGenerator fileNameGenerator) {
    this.fileNameGenerator = fileNameGenerator;
  }

  public File getCurrentFile() {
    return currentFile;
  }

  public synchronized void start() {
    if (inRecording) {
      stop();
    }
    currentFile = new File(fileNameGenerator.generate());
    if (!currentFile.getParentFile().exists()) {
      currentFile.getParentFile().mkdirs();
    }
    try {
      mWriter = new BufferedWriter(new FileWriter(currentFile, true), 30);
      inRecording = true;
    } catch (IOException e) {
      mWriter = null;
    }
  }

  public synchronized void reciveLog(String log) throws IOException {
    if (mWriter == null) {
      Log.w(TAG, "log service not ready");
      throw  new IOException("log service not ready");
    }
      mWriter.write(log);
      mWriter.newLine();
      mWriter.flush();
  }

  public synchronized void stop() {
    try {
      if (inRecording) {
        inRecording = false;
        currentFile = null;
        mWriter.flush();
        mWriter.close();
      }
    } catch (IOException e) {
      Log.w(TAG, e.getMessage(), e);
    }
  }
}
