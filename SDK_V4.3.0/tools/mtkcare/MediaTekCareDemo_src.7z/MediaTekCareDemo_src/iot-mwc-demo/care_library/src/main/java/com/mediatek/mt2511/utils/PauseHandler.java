package com.mediatek.mt2511.utils;

import java.util.Vector;
import rx.Observable;

public class PauseHandler {
  final Vector<Observable> observableQueueBuffer = new Vector<Observable>();
  private final OnHandler onHandler;
  private boolean paused;

  public PauseHandler(OnHandler onHandler) {
    this.onHandler = onHandler;
  }

  final public void pause() {
    paused = true;
  }

  public void resume() {
    paused = false;
    while (observableQueueBuffer.size() > 0) {
      final Observable observable = observableQueueBuffer.elementAt(0);
      observableQueueBuffer.removeElementAt(0);
      onHandler.onHandle(observable);
    }
  }

  public void processObservable(Observable observable) {
    if (paused) {
      observableQueueBuffer.add(observable);
    } else {
      onHandler.onHandle(observable);
    }
  }

  public interface OnHandler {
    void onHandle(Observable observable);
  }
}
