package com.mediatek.mt2511.models;

import io.realm.RealmObject;

public class RealmSPPack extends RealmObject {
  private Integer sbp;
  private Integer ddp;

  public Integer getSbp() {
    return sbp;
  }

  public void setSbp(Integer sbp) {
    this.sbp = sbp;
  }

  public Integer getDdp() {
    return ddp;
  }

  public void setDdp(Integer ddp) {
    this.ddp = ddp;
  }
}
