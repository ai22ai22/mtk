package com.mediatek.mt2511.models.pojo;

public class UpdateStatus {

  public Integer progress;

  public Integer totalSteps;

  public String description;
}
