package com.mediatek.mt2511.network;

import com.mediatek.mt2511.models.pojo.CareLoginRequest;
import com.mediatek.mt2511.models.pojo.CareLoginResponse;
import com.mediatek.mt2511.models.pojo.UploadCareRequest;
import com.mediatek.mt2511.models.pojo.UploadCareResponse;
import retrofit.http.Body;
import retrofit.http.Headers;
import retrofit.http.POST;
import rx.Observable;

/**
 * Created by MTK40526 on 7/29/2016.
 */
public interface CareService {
  @POST("/login")
  @Headers({"authorization: 3e4rdcfv", "Content-Type: application/json"})
  Observable<CareLoginResponse> login(@Body CareLoginRequest request);

  @POST("/records")
  @Headers({"Cache-Control: no-cache", "Content-Type: application/json"})
  Observable<UploadCareResponse> record(@Body UploadCareRequest request);

}
