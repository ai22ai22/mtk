package com.mediatek.mt2511.bluetooth.data;

public class ATCommand {
  private final String userId;
  private final int height;
  private final int gender;
  private final int age;
  private final int handLen;
  private final int weight;

  public ATCommand(String userId, int height, int weight, int gender, int age, int handLen) {
    this.userId = userId;
    this.height = height;
    this.gender = gender;
    this.age = age;
    this.handLen = handLen;
    this.weight = weight;
  }

  public int getWeight() {
    return weight;
  }

  public int getAge() {
    return age;
  }

  public int getGender() {
    return gender;
  }

  public int getHandLen() {
    return handLen;
  }

  public int getHeight() {
    return height;
  }

  public String getUserId() {
    return userId;
  }
}
