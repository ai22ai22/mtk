package com.mediatek.mt2511.network;

import retrofit.http.GET;
import retrofit.http.Query;
import rx.Observable;

/**
 * Created by MTK40526 on 5/13/2016.
 */
public interface SOAService {
  @GET("/sendTestEmail")
  Observable<String> sendDebugMail(@Query("body") String body, @Query("sender") String sender, @Query("receiver") String receiver,@Query("subject") String subject);
}
