package com.mediatek.mt2511.views;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.internal.view.ContextThemeWrapper;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import com.jakewharton.rxbinding.widget.TextViewTextChangeEvent;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.exceptions.AbortException;
import com.mediatek.mt2511.models.LastInputEntity;
import com.mediatek.mt2511.presentation.CreatePersonalModelPresenter;
import com.mediatek.mt2511.utils.DataUtils;
import com.mediatek.mt2511.utils.DatatypeConverter;
import com.mediatek.mt2511.utils.UIUtils;
import com.mediatek.mt2511.views.validation.CompositeValidation;
import com.mediatek.mt2511.views.validation.NumberValidate;
import com.mediatek.mt2511.views.validation.RequiredValidate;
import com.mediatek.mt2511.views.validation.ValidateEvent;
import com.mediatek.mt2511.views.validation.ViewValidation;
import com.mediatek.utils.RxBus;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;
import timber.log.Timber;

public class CreatePersonalDialog {
  private final CreatePersonalModelPresenter presenter;
  private final Activity activity;
  private AlertDialog mDialog;
  private EditText mEdtUserId;
  private EditText mEdtBirthYear;
  private EditText mEdtHeight;
  private EditText mEdtWeight;
  private RadioButton mRBMale;
  private RadioButton mRBFemale;
  private Button mButton1;
  private Button mButton2;
  private CompositeValidation mValidations = new CompositeValidation();
  private CompositeSubscription mSubscriptions = new CompositeSubscription();

  public CreatePersonalDialog(Activity activity, CreatePersonalModelPresenter presenter) {
    this.activity = activity;
    this.presenter = presenter;
    presenter.setView(this);
  }

  private void initView(final Activity activity,
      final Subscriber<? super LastInputEntity> subscriber) {
    AlertDialog.Builder builder = new AlertDialog.Builder(activity);
    View dialogView = View.inflate(new ContextThemeWrapper(activity, R.style.MAlertDialog),
        R.layout.layout_create_personal_model, null);
    builder.setCancelable(false)
        .setTitle("1. " + activity.getString(R.string.create_a_personal_model))
        .setView(dialogView)
        .setPositiveButton(R.string.btn_ok, null)
        .setNegativeButton(R.string.btn_cancel, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialogInterface, int i) {
            dialogInterface.dismiss();
            subscriber.onError(new AbortException(activity.getString(R.string.user_cancel)));
          }
        });

    mEdtUserId = (EditText) dialogView.findViewById(R.id.txt_user_id);
    mEdtBirthYear = (EditText) dialogView.findViewById(R.id.txt_birth_year);
    mEdtHeight = (EditText) dialogView.findViewById(R.id.txt_height);
    mEdtWeight = (EditText) dialogView.findViewById(R.id.txt_weight);
    mRBMale = (RadioButton) dialogView.findViewById(R.id.rb_male);
    mRBFemale = (RadioButton) dialogView.findViewById(R.id.rb_female);

    LastInputEntity lastInput = presenter.getLastInput();
    UIUtils.setFormEdit(mEdtUserId, DatatypeConverter.safeVarToStr(lastInput.getUserId()));
    UIUtils.setFormEdit(mEdtBirthYear, DatatypeConverter.safeVarToStr(lastInput.getBirthYear()));
    UIUtils.setFormEdit(mEdtWeight, DatatypeConverter.safeVarToStr((lastInput.getWeight())));
    UIUtils.setFormEdit(mEdtHeight, DatatypeConverter.safeVarToStr(lastInput.getHeight()));
    boolean isMail = lastInput.getGender() != null && lastInput.getGender() == 1;
    mRBMale.setChecked(isMail);
    mRBFemale.setChecked(!isMail);
    mDialog = builder.create();
  }

  public Observable<LastInputEntity> show() {
    return Observable.create(new Observable.OnSubscribe<LastInputEntity>() {
      @Override public void call(Subscriber<? super LastInputEntity> subscriber) {
        initView(activity, subscriber);
        mDialog.show();
        mButton1 = (Button) mDialog.findViewById(android.R.id.button1);
        mButton2 = (Button) mDialog.findViewById(android.R.id.button2);
        bindEvent(subscriber);
      }
    });
  }

  private void bindEvent(final Subscriber<? super LastInputEntity> subscriber) {

    buildValidation();
    mButton1.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View view) {
        final LastInputEntity lastInputEntity = getFromInput();
        final ProgressDialog progressDialog =
            ProgressDialog.show(activity, activity.getString(R.string.loading),
                activity.getString(R.string.waiting_a_moment), false);
        presenter.saveInput(lastInputEntity);
        presenter.writeProfile(DataUtils.trans2Profile(lastInputEntity))
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(new Subscriber<String>() {
              @Override public void onCompleted() {
                subscriber.onNext(lastInputEntity);
                subscriber.onCompleted();
                progressDialog.dismiss();
                mDialog.dismiss();
                mSubscriptions.clear();
              }

              @Override public void onError(Throwable e) {
                Toast.makeText(activity, e.getMessage(), Toast.LENGTH_LONG).show();
                Timber.w(e, e.getMessage());
                subscriber.onError(e);
                progressDialog.dismiss();
              }

              @Override public void onNext(String s) {

              }
            });
      }
    });
  }


  private void buildValidation() {
    mValidations.clear();
    RequiredValidate requiredValidate = new RequiredValidate();
    mValidations.addValidation(new ViewValidation(mEdtUserId).addValid(requiredValidate));
    mValidations.addValidation(new ViewValidation(mEdtBirthYear).addValid(requiredValidate)
        .addValid(new NumberValidate(1900, UIUtils.getYear())));
    mValidations.addValidation(new ViewValidation(mEdtHeight).addValid(requiredValidate)
        .addValid(new NumberValidate(90, 260)));
    mValidations.addValidation(new ViewValidation(mEdtWeight).addValid(requiredValidate)
        .addValid(new NumberValidate(20, 250)));
    mSubscriptions.add(RxBus.getInstance()
        .toObservable(ValidateEvent.class)
        .subscribe(new Action1<ValidateEvent>() {
          @Override public void call(ValidateEvent validateEvent) {
            if (validateEvent.isValid() && mValidations.isValid()){
              mButton1.setEnabled(true);
            }else {
              mButton1.setEnabled(false);
            }
          }
        }));
    mButton1.setEnabled(mValidations.isValid());
  }


  private LastInputEntity getFromInput() {
    String userId = mEdtUserId.getText().toString();
    String birthYear = mEdtBirthYear.getText().toString();
    String height = mEdtHeight.getText().toString();
    String weight = mEdtWeight.getText().toString();
    String gender = mRBMale.isChecked() ? "1" : "2";

    LastInputEntity lastInputEntity = new LastInputEntity();
    lastInputEntity.setUserId(userId);
    if (!TextUtils.isEmpty(birthYear)) {
      lastInputEntity.setBirthYear(Integer.parseInt(birthYear));
    }
    if (!TextUtils.isEmpty(height)) {
      lastInputEntity.setHeight(Integer.parseInt(height));
    }
    if (!TextUtils.isEmpty(weight)) {
      lastInputEntity.setWeight(Integer.parseInt(weight));
    }
    lastInputEntity.setArmLength(0);
    if (!TextUtils.isEmpty(gender)) {
      lastInputEntity.setGender(Integer.parseInt(gender));
    }
    return lastInputEntity;
  }
}
