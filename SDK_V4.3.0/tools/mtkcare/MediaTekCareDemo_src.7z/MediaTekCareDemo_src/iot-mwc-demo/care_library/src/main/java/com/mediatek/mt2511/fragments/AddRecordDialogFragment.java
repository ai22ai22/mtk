package com.mediatek.mt2511.fragments;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.internal.view.ContextThemeWrapper;
import android.support.v7.internal.widget.DialogTitle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;

import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.interfaces.Form;
import com.mediatek.mt2511.logs.BPLogService;
import com.mediatek.mt2511.models.Question;
import com.mediatek.mt2511.models.Record;

import java.io.IOException;
import java.util.ArrayList;

import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.FuncN;
import rx.subjects.PublishSubject;
import rx.subscriptions.CompositeSubscription;
import timber.log.Timber;

/**
 * Created by MTK40526 on 5/5/2016.
 */
public class AddRecordDialogFragment extends DialogFragment
    implements ViewPager.OnPageChangeListener {
  ViewPager mViewPager;
  Button mButton1;
  Button mButton2;
  Button mButton3;
  DialogTitle mDialogTitle;
  private PublishSubject<Boolean> mDialogSubject = PublishSubject.create();
  private Subscription mValidSubscription;
  private CompositeSubscription mSubscriptions = new CompositeSubscription();
  private int mLastPagerIndex = 0;
  private FormFragment[] fragments = null;

  @Override public void onDestroy() {
    super.onDestroy();
    if (mValidSubscription != null) {
      mValidSubscription.unsubscribe();
    }
    mSubscriptions.clear();
  }

  @Override public void onStart() {
    super.onStart();
    onPageSelected(mViewPager.getCurrentItem());
  }

  /*
  @NonNull @Override public Dialog onCreateDialog(Bundle savedInstanceState) {
    LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
    View contentView  = layoutInflater.inflate(R.layout.fragment_dialog_add_record , null);
    initView(contentView);
    AlertDialog alertDialog = new AlertDialog.Builder(getActivity())
        .setView(contentView)
        .setPositiveButton(R.string.ok, null)
        .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        })
        .create();
    alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
      @Override public void onShow(DialogInterface dialog) {
    //    mViewPager.setAdapter(new MyPagerAdapter(getChildFragmentManager()));
      }
    });
    return alertDialog;
  }
  */

  @NonNull @Override public Dialog onCreateDialog(Bundle savedInstanceState) {
    Dialog dialog = super.onCreateDialog(savedInstanceState);

    // request a window without the title
    dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
    dialog.setCancelable(false);
    return dialog;
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    final Context contextThemeWrapper =
        new ContextThemeWrapper(getActivity(), R.style.MAlertDialog);
    LayoutInflater localInflater = inflater.cloneInContext(contextThemeWrapper);
    View contentView = localInflater.inflate(R.layout.fragment_dialog_add_record, container, false);
    initFragments();
    initView(contentView);
    setCancelable(false);
    return contentView;
  }

  private void initFragments() {
    fragments = MContext.getInstance().createAddRecordFragments();
  }

  private void initView(View contentView) {
    mViewPager = (ViewPager) contentView.findViewById(R.id.viewPager);
    mButton1 = (Button) contentView.findViewById(android.R.id.button1);
    Button mButton2 = (Button) contentView.findViewById(android.R.id.button2);
    Button mButton3 = (Button) contentView.findViewById(android.R.id.button3);
    mDialogTitle = (DialogTitle) contentView.findViewById(R.id.alertTitle);

    mButton3.setVisibility(View.GONE);
    mButton1.setText(R.string.btn_next);
    mButton2.setText(R.string.btn_cancel);
    mButton2.setEnabled(!getArguments().getBoolean("force"));
    mViewPager.addOnPageChangeListener(this);
    mViewPager.setAdapter(new MyPagerAdapter(getChildFragmentManager(), fragments));

    mButton1.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        if (mViewPager.getCurrentItem() < mViewPager.getAdapter().getCount() - 1) {
          mViewPager.setCurrentItem(mViewPager.getCurrentItem() + 1);
        } else {
          final ProgressDialog progressDialog =
              ProgressDialog.show(getActivity(), getString(R.string.loading),
                  getString(R.string.waiting_a_moment));
          ArrayList<Observable<Object>> observableArrayList = new ArrayList<Observable<Object>>();
          for (FormFragment fragment : fragments) {
            observableArrayList.add(fragment.submit());
          }
          mSubscriptions.add(Observable.combineLatest(observableArrayList, new FuncN<Object[]>() {
            @Override public Object[] call(Object... args) {
              return args;
            }
          }).observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<Object[]>() {
            @Override public void onCompleted() {
              if(getTargetFragment() != null) {
                getTargetFragment().onActivityResult(getTargetRequestCode(), Activity.RESULT_OK,
                    getActivity().getIntent());
              }
              dismiss();
              progressDialog.dismiss();
              mDialogSubject.onNext(true);
              mDialogSubject.onCompleted();
            }

            @Override public void onError(Throwable e) {
              Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
              e.printStackTrace();
              progressDialog.dismiss();
            }

            @Override public void onNext(Object[] objects) {
              startBpLog(objects);
            }
          }));
        }
      }
    });
    mButton2.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        if(getTargetFragment() != null) {
          getTargetFragment().onActivityResult(getTargetRequestCode(), Activity.RESULT_CANCELED,
              getActivity().getIntent());
        }
        dismiss();
        mDialogSubject.onNext(false);
        mDialogSubject.onCompleted();
      }
    });
  }

  private void startBpLog(Object[] objects) {
    Record record = null;
    Question question = null;
    for (Object obj : objects) {
      if (obj instanceof Record) {
        record = (Record) obj;
      } else if (obj instanceof Question) {
        question = (Question) obj;
      }
    }
    BPLogService.getInstance().start();
    try {
      String logText = String.format("%s,%s,%s,%s,%s,%s", record.age, record.height, record.weight,
          record.armLength, record.gendor.equals("M") ? "1" : "2",
          record.disease.replaceAll(",", "+").replaceAll("_", " "));
      if(question != null){
        logText += "," + question.desc;
      }
      BPLogService.getInstance()
          .reciveLog(logText);
    } catch (IOException e) {
      e.printStackTrace();
      Timber.e(e, e.getMessage());
      Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
    }
  }

  @Override
  public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

  }

  @Override public void onPageSelected(int position) {
    if (!mButton1.isEnabled() && position > mLastPagerIndex) {
      mViewPager.setCurrentItem(mLastPagerIndex);
      return;
    }
    mLastPagerIndex = position;
    MyPagerAdapter adapter = (MyPagerAdapter) mViewPager.getAdapter();
    CustomFragment fragment = (CustomFragment) adapter.getItem(position);
    mDialogTitle.setText(fragment.getTitle());
    mButton1.setText(
        adapter.getCount() - 1 == position ? getText(R.string.btn_ok) : getText(R.string.btn_next));
    if (fragment instanceof Form) {
      if (mValidSubscription != null) {
        mValidSubscription.unsubscribe();
      }
      mValidSubscription = ((Form) fragment).validation().subscribe(new Action1<Boolean>() {
        @Override public void call(Boolean isValid) {
          mButton1.setEnabled(isValid);
        }
      });
    }
  }

  public Observable<Boolean> dialogObservable() {
    return mDialogSubject.asObservable();
  }

  @Override public void onPageScrollStateChanged(int state) {

  }



  private static class MyPagerAdapter extends FragmentPagerAdapter {
    private Fragment[] mFragments;

    public MyPagerAdapter(FragmentManager fm, Fragment[] fragments) {
      super(fm);
      mFragments = fragments;
    }

    @Override public Fragment getItem(int position) {
      return mFragments[position];
    }

    @Override public int getCount() {
      return mFragments.length;
    }
  }
}
