package com.mediatek.mt2511.utils;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import com.mediatek.mt2511.R;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;

public class RxUtils {
  public static Observable<Boolean> alertDialog(final Context context, final String title,
      final String message, final String okBtnText) {
    return Observable.create(new Observable.OnSubscribe<Boolean>() {
      @Override public void call(final Subscriber<? super Boolean> subscriber) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title)
            .setMessage(message)
            .setPositiveButton(okBtnText, new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialog, int which) {
                subscriber.onNext(true);
                dialog.dismiss();
              }
            })
            .setNegativeButton(context.getString(R.string.btn_cancel),
                new DialogInterface.OnClickListener() {
                  @Override public void onClick(DialogInterface dialog, int which) {
                    subscriber.onNext(false);
                    dialog.dismiss();
                  }
                })
            .setOnDismissListener(new DialogInterface.OnDismissListener() {
              @Override public void onDismiss(DialogInterface dialog) {
                subscriber.onCompleted();
              }
            })
            .setCancelable(false);
        builder.create().show();
      }
    }).subscribeOn(AndroidSchedulers.mainThread());
  }
}
