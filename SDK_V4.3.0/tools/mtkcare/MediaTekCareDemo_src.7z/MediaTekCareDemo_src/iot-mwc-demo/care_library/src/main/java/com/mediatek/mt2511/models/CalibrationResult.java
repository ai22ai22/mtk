package com.mediatek.mt2511.models;

import io.realm.RealmList;
import io.realm.RealmObject;

public class CalibrationResult extends RealmObject {
  private RealmParas paras = new RealmParas();
  private RealmList<RealmSPPack> spPacks = new RealmList<>();

  public RealmParas getParas() {
    return paras;
  }

  public void setParas(RealmParas paras) {
    this.paras = paras;
  }

  public RealmList<RealmSPPack> getSpPacks() {
    return spPacks;
  }

  public void setSpPacks(RealmList<RealmSPPack> spPacks) {
    this.spPacks = spPacks;
  }
}
