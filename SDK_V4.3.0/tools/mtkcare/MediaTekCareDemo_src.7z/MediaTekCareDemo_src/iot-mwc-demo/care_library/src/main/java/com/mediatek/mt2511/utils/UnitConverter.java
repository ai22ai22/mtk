package com.mediatek.mt2511.utils;

import android.content.Context;
import android.util.TypedValue;

public class UnitConverter {
  Context context;

  public UnitConverter(Context context) {
    this.context = context;
  }

  public float spToPx(int sp) {
    return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,
        sp, this.context.getResources().getDisplayMetrics());
  }

  public float dpToPx(int dp){
    return dp * this.context.getResources().getDisplayMetrics().density;
  }
}
