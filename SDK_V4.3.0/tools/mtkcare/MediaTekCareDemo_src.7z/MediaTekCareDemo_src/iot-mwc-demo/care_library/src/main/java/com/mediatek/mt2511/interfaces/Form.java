package com.mediatek.mt2511.interfaces;

import rx.Observable;

/**
 * Created by MTK40526 on 6/29/2016.
 */
public interface Form  {
  Observable<Boolean> validation();
  Observable submit();
}
