package com.mediatek.mt2511.views.chart;

import android.content.Context;
import com.mediatek.mt2511.utils.UnitConverter;
import lombok.Getter;
import lombok.Setter;

public class SleepEfficienciesChartConstant {
  private final int DP_CHART_WIDTH = 320;
  private final int DP_CHART_HEIGHT = 132;
  private final int DP_MARGIN_LEFT = 20;
  private final int DP_MARGIN_RIGHT = 20;
  private final int DP_MARGIN_TOP = 42;
  private final int DP_MARGIN_BOTTOM = 34;
  private final int DP_BAR_CORNER_RADIUS = 3;
  private final int DP_BAR_WIDTH = 20;
  private final int DP_BAR_INTERVAL = 20;
  private final int DP_PERCENTAGE_MARGIN_TOP = 8;
  private final int DP_AXIS_AND_TEXT_INTERVAL = 4;
  private final int DP_DATE_MARGIN_TOP = 8;
  private final int DP_LINE_STROKE_WIDTH = 1;
  private final int DP_TITLE_MARGIN_BOTTOM = 8;
  private final int SP_TEXT_SIZE = 12;
  private final int SP_TEXT_SIZE_PERCENTAGE = 18;

  @Getter @Setter private float px_chart_width;
  @Getter @Setter private float px_chart_height;
  @Getter private float px_margin_left;
  @Getter private float px_margin_right;
  @Getter private float px_margin_top;
  @Getter private float px_margin_bottom;
  @Getter private float px_bar_corner_radius;
  @Getter private float px_bar_width;
  @Getter private float px_bar_interval;
  @Getter private float px_percentage_margin_top;
  @Getter private float px_date_margin_top;
  @Getter private float px_axis_and_text_interval;
  @Getter private float px_line_stroke_width;
  @Getter private float px_text_size;
  @Getter private float px_text_size_percentage;
  @Getter private float px_title_margin_bottom;

  public void convertUnit(Context context) {
    UnitConverter converter = new UnitConverter(context);
    px_chart_width = converter.dpToPx(DP_CHART_WIDTH);
    px_chart_height = converter.dpToPx(DP_CHART_HEIGHT);

    px_margin_left = converter.dpToPx(DP_MARGIN_LEFT);
    px_margin_right = converter.dpToPx(DP_MARGIN_RIGHT);
    px_margin_top = converter.dpToPx(DP_MARGIN_TOP);
    px_margin_bottom = converter.dpToPx(DP_MARGIN_BOTTOM);

    px_percentage_margin_top = converter.dpToPx(DP_PERCENTAGE_MARGIN_TOP);
    px_date_margin_top = converter.dpToPx(DP_DATE_MARGIN_TOP);

    px_bar_corner_radius = converter.dpToPx(DP_BAR_CORNER_RADIUS);
    px_bar_width = converter.dpToPx(DP_BAR_WIDTH);
    px_bar_interval = converter.dpToPx(DP_BAR_INTERVAL);

    px_axis_and_text_interval = converter.dpToPx(DP_AXIS_AND_TEXT_INTERVAL);
    px_line_stroke_width = converter.dpToPx(DP_LINE_STROKE_WIDTH);

    px_title_margin_bottom = converter.dpToPx(DP_TITLE_MARGIN_BOTTOM);
    px_text_size = converter.spToPx(SP_TEXT_SIZE);
    px_text_size_percentage = converter.spToPx(SP_TEXT_SIZE_PERCENTAGE);
  }
}
