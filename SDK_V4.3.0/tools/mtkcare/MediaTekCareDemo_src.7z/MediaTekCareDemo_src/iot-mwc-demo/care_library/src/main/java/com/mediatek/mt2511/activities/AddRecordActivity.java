package com.mediatek.mt2511.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import com.mediatek.iot.Device;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.custom.BTDeviceFactory;
import com.mediatek.mt2511.fragments.AddRecordDialogFragment;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.subscriptions.CompositeSubscription;

/**
 * Created by MTK40526 on 4/25/2016.
 */
public class AddRecordActivity extends AppCompatActivity {
  private CompositeSubscription mSubscriptions = new CompositeSubscription();

  @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_add_record);
    AddRecordDialogFragment addRecordDialogFragment = new AddRecordDialogFragment();
    addRecordDialogFragment.show(getSupportFragmentManager(), "dialog");
    addRecordDialogFragment.setCancelable(false);
    addRecordDialogFragment.dialogObservable().subscribe(new Action1<Boolean>() {
      @Override public void call(Boolean completed) {
        if (completed) {
          setResult(RESULT_OK);
          finish();
        } else {
          setResult(RESULT_CANCELED);
          finish();
        }
      }
    });

    mSubscriptions.add(
        BTDeviceFactory.getBTDevice().getStateObservable().filter(new Func1<Integer, Boolean>() {
          @Override public Boolean call(Integer state) {
            return state == Device.STATE_DISCONNECTED;
          }
        }).first().observeOn(AndroidSchedulers.mainThread()).subscribe(new Action1<Integer>() {
          @Override public void call(Integer state) {
            finish();
          }
        }));
  }

  @Override public void onBackPressed() {
    // do nothing
  }

  @Override protected void onDestroy() {
    super.onDestroy();
    mSubscriptions.clear();
  }
}