package com.mediatek.mt2511.models.pojo;

public class HRVRequest {

  public float LF;
  public float HF;
  public float LFHF;
  public float SDNN;
}
