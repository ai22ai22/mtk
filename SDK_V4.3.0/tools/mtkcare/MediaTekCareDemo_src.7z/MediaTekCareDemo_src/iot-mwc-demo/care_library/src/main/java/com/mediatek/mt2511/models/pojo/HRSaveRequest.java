package com.mediatek.mt2511.models.pojo;

import java.util.ArrayList;
import java.util.List;

public class HRSaveRequest {

  public List<Integer> result = new ArrayList<Integer>();
}
