package com.mediatek.mt2511.fragments;

import com.mediatek.mt2511.interfaces.Form;
import rx.Observable;
import rx.Subscriber;
import rx.subjects.PublishSubject;

/**
 * Created by MTK40526 on 6/29/2016.
 */
public abstract class FormFragment extends CustomFragment implements Form {
  private boolean mIsValid = false;
  private PublishSubject<Boolean> mValidationSubject = PublishSubject.create();

  protected void setValidation(boolean isValid) {
    this.mIsValid = isValid;
    mValidationSubject.onNext(isValid);
  }

  @Override public Observable<Boolean> validation() {
    return Observable.create(new Observable.OnSubscribe<Boolean>() {
      @Override public void call(final Subscriber<? super Boolean> subscriber) {
        subscriber.onNext(mIsValid);
        mValidationSubject.asObservable().subscribe(new Subscriber<Boolean>() {
          @Override public void onCompleted() {
            subscriber.onCompleted();
          }

          @Override public void onError(Throwable e) {
            subscriber.onError(e);
          }

          @Override public void onNext(Boolean aBoolean) {
            subscriber.onNext(aBoolean);
          }
        });
      }
    });
  }

}
