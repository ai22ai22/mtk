package com.mediatek.mt2511.apx;

public class Util {
	public static void printArray(int[] input) {
		for(int i = 0; i < input.length; i++) {
			System.out.print(input[i] + ", ");
		}
		System.out.println("");
	}
}
