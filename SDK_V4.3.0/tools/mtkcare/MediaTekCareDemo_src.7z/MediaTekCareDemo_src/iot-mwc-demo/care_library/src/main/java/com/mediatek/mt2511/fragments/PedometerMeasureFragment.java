package com.mediatek.mt2511.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.jakewharton.rxbinding.view.RxView;
import com.mediatek.mt2511.custom.BTDeviceFactory;
import com.mediatek.iot.Device;
import com.mediatek.iot.data.bt.AccData;
import com.mediatek.iot.data.bt.PedometerData;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.services.RecordService;
import com.mediatek.mt2511.views.widgets.ClockTextView;
import com.mediatek.utils.RxBus;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;

/**
 * Created by MTK40526 on 5/20/2016.
 */
public class PedometerMeasureFragment extends CustomFragment {
  TextView mTxtStepCount;
  TextView mTxtX;
  TextView mTxtY;
  TextView mTxtZ;
  private Device mBTDevice = BTDeviceFactory.getBTDevice();
  private CompositeSubscription mSubscriptions = new CompositeSubscription();

  public PedometerMeasureFragment() {
    super();
    setTitle(MContext.getInstance().getApplication().getString(R.string.pedometer));
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_pedometer, container, false);
    initView(view);
    mSubscriptions.clear();
    mSubscriptions.add(RxBus.getInstance()
        .toObservable(AccData.class)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<AccData>() {
          @Override public void call(AccData accData) {
            AccData.AccItem accItem = accData.getAccItem(2);
            mTxtX.setText(String.valueOf(accItem.getX()));
            mTxtY.setText(String.valueOf(accItem.getY()));
            mTxtZ.setText(String.valueOf(accItem.getZ()));
          }
        }));
    mSubscriptions.add(RxBus.getInstance()
        .toObservable(PedometerData.class)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<PedometerData>() {
          @Override public void call(PedometerData pedometerData) {
            mTxtStepCount.setText(
                String.valueOf(pedometerData.get(PedometerData.INDEX_STEP_COUNT)));
          }
        }));

    return view;
  }

  private void initView(View view) {
    mTxtStepCount = (TextView) view.findViewById(R.id.txt_step_count);
    mTxtX = (TextView) view.findViewById(R.id.txt_x);
    mTxtY = (TextView) view.findViewById(R.id.txt_y);
    mTxtZ = (TextView) view.findViewById(R.id.txt_z);
  }

  @Override public void onDestroy() {
    super.onDestroy();
    mSubscriptions.clear();
  }



}
