package com.mediatek.mt2511.services;

public interface Service {

  void start();
  void stop();

}
