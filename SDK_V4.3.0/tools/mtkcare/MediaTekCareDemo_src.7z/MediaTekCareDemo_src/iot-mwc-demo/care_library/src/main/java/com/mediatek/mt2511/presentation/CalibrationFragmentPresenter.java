package com.mediatek.mt2511.presentation;

import android.widget.Toast;
import com.mediatek.iot.data.bt.BTBaseData;
import com.mediatek.iot.data.bt.PWTTData;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.exceptions.AbortException;
import com.mediatek.mt2511.fragments.CalibrationFragment;
import com.mediatek.mt2511.models.BTCommandModel;
import com.mediatek.mt2511.models.CalibrationResult;
import com.mediatek.mt2511.models.Golden;
import com.mediatek.mt2511.models.LastInputEntity;
import com.mediatek.mt2511.models.PersonalModel;
import com.mediatek.mt2511.models.PersonalProfileEntity;
import com.mediatek.mt2511.models.RealmInteger;
import com.mediatek.mt2511.models.RealmSPPack;
import com.mediatek.mt2511.services.RecordService;
import com.mediatek.mt2511.utils.DataUtils;
import com.mediatek.utils.RxBus;
import io.realm.RealmList;
import java.util.ArrayList;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action0;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.subscriptions.CompositeSubscription;
import timber.log.Timber;

public class CalibrationFragmentPresenter implements Presenter<CalibrationFragment> {

  private final BTCommandModel btCommandModel;
  private final PersonalModel personalModel;
  private CalibrationFragment view;
  private CompositeSubscription mSubscriptions = new CompositeSubscription();
  private PersonalProfileEntity currentPersonalProfileEntity;

  public CalibrationFragmentPresenter(BTCommandModel btCommandModel, PersonalModel personalModel) {
    this.btCommandModel = btCommandModel;
    this.personalModel = personalModel;
  }

  @Override public void setView(CalibrationFragment view) {
    this.view = view;
  }

  public void startCalibrationFlow() {
    currentPersonalProfileEntity = null;
    Observable<LastInputEntity> ob1 =
        view.getPersonalModel().doOnNext(new Action1<LastInputEntity>() {
          @Override public void call(LastInputEntity lastInputEntity) {
            Timber.d("===getPersonalModel");
            currentPersonalProfileEntity = DataUtils.trans2Profile(lastInputEntity);
            currentPersonalProfileEntity.setCalibrationResult(new CalibrationResult());
          }
        });


    Observable<Golden> ob3 = getGolden(2).doOnCompleted(new Action0() {
      @Override public void call() {
        view.showStepTitle(3);
      }
    });

    Observable<PWTTData> ob5 = reciveParas().doOnCompleted(new Action0() {
      @Override public void call() {
        Timber.d("===doOnCompleted view:" + view);
        view.showStepTitle(0);
        Toast.makeText(view.getActivity(), R.string.data_received, Toast.LENGTH_LONG).show();
      }
    }).subscribeOn(AndroidSchedulers.mainThread());

    Observable<Golden> ob6 = getGolden(4);
    Observable<String> ob7 = sendCalibration();
    Observable<String> ob8 = view.showSuccess().subscribeOn(AndroidSchedulers.mainThread());
    mSubscriptions.add(Observable.concat(ob1,  ob3, ob5, ob6, ob7, ob8)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<Object>() {
          @Override public void onCompleted() {
            doCompleted();
          }

          @Override public void onError(Throwable e) {
            if (e instanceof AbortException) {
              view.exit();
            } else {
              Toast.makeText(view.getActivity(),
                  String.format("Create Personal Model fail : %s", e.getMessage()),
                  Toast.LENGTH_LONG).show();
              Timber.w(e, e.getMessage());
              view.exit();
            }
          }

          @Override public void onNext(Object o) {

          }
        }));
  }

  private void doCompleted() {
    currentPersonalProfileEntity.setMode(PersonalProfileEntity.MODE_PERSONAL);
    personalModel.saveNewProfile(currentPersonalProfileEntity);
    view.exit();
  }

  private Observable<Golden> getGolden(final int step) {
    return view.getInputGolden(step)
        .subscribeOn(AndroidSchedulers.mainThread())
        .doOnNext(new Action1<Golden>() {
          @Override public void call(Golden golden) {
            Timber.d("===getGolden");
            RealmList<RealmSPPack> spPacks =
                currentPersonalProfileEntity.getCalibrationResult().getSpPacks();
            RealmSPPack spPack = new RealmSPPack();
            spPack.setSbp(golden.systolicSp);
            spPack.setDdp(golden.diastolicSp);
            spPacks.add(spPack);
          }
        });
  }

  private Observable<PWTTData> reciveParas() {
    return Observable.create(new Observable.OnSubscribe<PWTTData>() {
      @Override public void call(final Subscriber<? super PWTTData> subscriber) {

        Timber.d("===reciveParas");

        mSubscriptions.add(
            RxBus.getInstance().toObservable(PWTTData.class).filter(new Func1<PWTTData, Boolean>() {
              @Override public Boolean call(PWTTData pwttData) {
                boolean flag = pwttData.get(BTBaseData.INDEX_SENSOR_TYPE) == 8001
                    && pwttData.get(BTBaseData.FEATURE_TYPE) == 3;
                Timber.d("===pass filter:" + flag);

                return flag;
              }
            }).first().subscribe(subscriber));
/*        RxBus.getInstance().post(new PWTTData(new int[] {
            54321, 8001, 0, 3, 2, 4, 1, 1, 3, 12345, 12345, 12345, 12345, 12345, 12345, 12345
        }));*/
      }
    }).doOnNext(new Action1<PWTTData>() {
      @Override public void call(PWTTData pwttData) {
        int[] rawData = pwttData.getRawData();
        int status = rawData[BTBaseData.INDEX_STATUS];
        ArrayList<Integer> arrayList = new ArrayList<>();
        int j = 0;
        for (int i = 6; i < 6 + status; ++i) {
          if (rawData[i] == 12345 || rawData[i] == 54321) {
            break;
          }
          arrayList.add(rawData[i]);
          RealmInteger value = new RealmInteger();
          value.setValue(rawData[i]);
          currentPersonalProfileEntity.getCalibrationResult().getParas().getValues().add(value);
        }
      }
    });
  }

  private Observable<String> sendCalibration() {
    return Observable.create(new Observable.OnSubscribe<String>() {
      @Override public void call(Subscriber<? super String> subscriber) {
        CalibrationResult calibrationResult = currentPersonalProfileEntity.getCalibrationResult();
        Observable<String> ob = Observable.empty();
        int index = 0;
        for (RealmSPPack spPack : calibrationResult.getSpPacks()) {
          index++;
          ob = ob.concatWith(
              btCommandModel.writeAndValid("sbp" + index, String.valueOf(spPack.getSbp())));
          ob = ob.concatWith(
              btCommandModel.writeAndValid("dbp" + index, String.valueOf(spPack.getDdp())));
        }
        index = 0;
        for (RealmInteger value : calibrationResult.getParas().getValues()) {
          index++;
          ob = ob.concatWith(
              btCommandModel.writeAndValid("para" + index, String.valueOf(value.getValue())));
        }
        ob.subscribe(subscriber);
      }
    });
  }

  public void exit() {
    mSubscriptions.clear();
    RecordService.getInstance().stopSave();
  }
}
