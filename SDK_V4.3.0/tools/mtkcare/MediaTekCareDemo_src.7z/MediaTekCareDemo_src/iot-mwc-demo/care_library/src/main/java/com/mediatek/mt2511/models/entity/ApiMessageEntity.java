package com.mediatek.mt2511.models.entity;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

public class ApiMessageEntity {
  @SerializedName("detail") private String errorDetail;
  private String message;
  private Integer code;

  public String getMessage() {
    return message;
  }

  public Integer getCode() {
    return code;
  }

  public String getErrorDetail() {
    return errorDetail;
  }

  public ApiMessageEntity fromJson(String json) {
    return new Gson().fromJson(json, ApiMessageEntity.class);
  }
}
