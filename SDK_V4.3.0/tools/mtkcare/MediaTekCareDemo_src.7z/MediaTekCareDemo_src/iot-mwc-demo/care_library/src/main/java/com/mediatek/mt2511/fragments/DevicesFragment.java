package com.mediatek.mt2511.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import com.mediatek.iot.BluetoothDeviceInfo;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.custom.BTDeviceFactory;
import com.mediatek.mt2511.views.adapters.DeviceAdapter;
import com.pixplicity.multiviewpager.MultiViewPager;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import timber.log.Timber;

/**
 * Created by MTK40526 on 3/7/2016.
 */
public class DevicesFragment extends BaseFragment {
  private DeviceAdapter deviceAdapter;
  private AnimationDrawable animationDrawable;
  private MultiViewPager pager;
  private Subscription mSubscription;
  private SharedPreferences mSp;
  private String mLastMacAddress;

  public DevicesFragment() {
  }

  @Override public void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    mSp = getActivity().getSharedPreferences("scan_device", Context.MODE_PRIVATE);
    mLastMacAddress = mSp.getString("last_address", "");
  }

  @Nullable @Override public View onCreateView(LayoutInflater inflater, ViewGroup container,
      Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_devices, container, false);
    initView(view);
    ImageView iv = (ImageView) view.findViewById(R.id.bluetooth_connect);
    animationDrawable = (AnimationDrawable) iv.getDrawable();
    deviceAdapter = new DeviceAdapter(getChildFragmentManager(), getActivity());
    pager = (MultiViewPager) view.findViewById(R.id.container);
    pager.setAdapter(deviceAdapter);
    pager.setPageTransformer(false, new ViewPager.PageTransformer() {
      @Override public void transformPage(View page, float position) {

        final float normalizedposition = Math.abs(Math.abs(position) - 1);
        page.setScaleX(normalizedposition / 2 + 0.5f);
        page.setScaleY(normalizedposition / 2 + 0.5f);
        page.setAlpha(1 - Math.abs(position));
      }
    });
    return view;
  }

  private void initView(View view) {
    view.findViewById(R.id.btn_pre).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        onBtnPreClick();
      }
    });

    view.findViewById(R.id.btn_next).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        onBtnNextClick();
      }
    });

    view.findViewById(R.id.refresh_btn).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        scan();
      }
    });
  }

  @Override public void onDestroy() {
    super.onDestroy();
    BTDeviceFactory.getBTScanner().stopScan();
    if (mSubscription != null) {
      mSubscription.unsubscribe();
    }
  }

  @Override public void onStart() {
    super.onStart();
    scan();
  }

  @Override public void onResume() {
    super.onResume();
    //scan();
  }

  private void scan() {
    getView().findViewById(R.id.text_no_watch).setVisibility(View.VISIBLE);
    deviceAdapter.clear();
    pager.setAdapter(deviceAdapter);
    if (mSubscription != null) {
      mSubscription.unsubscribe();
    }
    animationDrawable.start();

    mSubscription = BTDeviceFactory.getBTScanner()
        .startScan()
        .buffer(160, TimeUnit.MILLISECONDS)
        .filter(new Func1<List<BluetoothDeviceInfo>, Boolean>() {
          @Override public Boolean call(List<BluetoothDeviceInfo> bluetoothDeviceInfos) {
            return bluetoothDeviceInfos.size() > 0;
          }
        })
        .onBackpressureBuffer()
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<List<BluetoothDeviceInfo>>() {
          @Override public void onCompleted() {
            animationDrawable.stop();
          }

          @Override public void onError(Throwable e) {
            animationDrawable.stop();
            Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
            Timber.e(e);
          }

          @Override public void onNext(List<BluetoothDeviceInfo> bluetoothDeviceInfos) {

            Collections.sort(bluetoothDeviceInfos, new Comparator<BluetoothDeviceInfo>() {
              @Override public int compare(BluetoothDeviceInfo lhs, BluetoothDeviceInfo rhs) {
                if (lhs.getMacAddress().equals(mLastMacAddress)) {
                  return -1;
                }
                if (rhs.getMacAddress().equals(mLastMacAddress)) {
                  return 1;
                }
                return 0;
              }
            });
            for (BluetoothDeviceInfo deviceInfo : bluetoothDeviceInfos) {
              deviceAdapter.addDevice(deviceInfo);
            }
            if (pager.getCurrentItem() > deviceAdapter.getCount() - 1) {
              pager.setCurrentItem(deviceAdapter.getCount() - 1);
            }
            getView().findViewById(R.id.text_no_watch).setVisibility(View.GONE);
            deviceAdapter.notifyDataSetChanged();
          }
        });
  }

  public Observable<BluetoothDeviceInfo> getDeviceInfo() {
    return Observable.create(new Observable.OnSubscribe<BluetoothDeviceInfo>() {
      public void call(final Subscriber<? super BluetoothDeviceInfo> subscriber) {
        getView().findViewById(R.id.connect_btn).setOnClickListener(new View.OnClickListener() {
          @Override public void onClick(View v) {
            if (pager.getCurrentItem() < deviceAdapter.getCount()) {
              DeviceAdapter.DeviceFragment devicesFragment =
                  deviceAdapter.getItem(pager.getCurrentItem());
              String mac_address = devicesFragment.getArguments().getString("mac_address");
              String name = devicesFragment.getArguments().getString("name");
              BluetoothDeviceInfo device = new BluetoothDeviceInfo(name, mac_address, 0);
              subscriber.onNext(device);
              mSp.edit().putString("last_address", device.getMacAddress()).commit();
            }
          }
        });
      }
    });
  }

  void onBtnPreClick() {
    int pageIndex = pager.getCurrentItem();
    if (--pageIndex > -1) {
      pager.setCurrentItem(pageIndex);
    }
  }

  void onBtnNextClick() {
    int pageIndex = pager.getCurrentItem();
    if (++pageIndex < pager.getAdapter().getCount()) {
      pager.setCurrentItem(pageIndex);
    }
  }
}
