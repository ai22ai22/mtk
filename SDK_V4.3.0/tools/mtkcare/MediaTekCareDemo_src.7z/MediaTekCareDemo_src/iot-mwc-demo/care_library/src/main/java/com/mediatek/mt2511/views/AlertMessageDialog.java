package com.mediatek.mt2511.views;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import com.mediatek.mt2511.R;

/**
 * Created by MTK40526 on 3/31/2016.
 */
public class AlertMessageDialog extends AlertDialog {
  TextView mTxtMessage;

  public AlertMessageDialog(Context context, String msg) {
    super(context);

    LayoutInflater inflater =
        (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    View view = inflater.inflate(R.layout.dialog_alert_message, null);
    initView(view);
    mTxtMessage.setText(msg);
    setView(view);
  }

  private void initView(View view) {
    mTxtMessage = (TextView) view.findViewById(R.id.txtMessage);
    view.findViewById(R.id.btnCancel).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        close();
      }
    });
  }

  void close() {
    dismiss();
  }
}
