package com.mediatek.mt2511.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import com.mediatek.mt2511.AppConstants;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.fragments.BPMeasureResultFragment;
import com.mediatek.mt2511.network.MyProjectApi;
import com.mediatek.mt2511.services.RecordService;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by MTK40108 on 7/6/2016.
 */
public class BPMeasureResultActivity extends AppCompatActivity {
  TextView mTxtSystolic_value;
  TextView mTxtDiastolic_value;
  TextView mTxtHeart_rate_value;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_bpmeasure_result);

    initView();
    Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
    setSupportActionBar(toolbar);
    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    uploadRecord();
  }

  private void initView() {
    TextView mTxtSystolic_value = (TextView) findViewById(R.id.systolic_value);
    TextView mTxtDiastolic_value = (TextView) findViewById(R.id.diastolic_value);
    TextView mTxtHeart_rate_value = (TextView) findViewById(R.id.heart_rate_value);

    Bundle bundle = getIntent().getExtras();
    int sbp = bundle.getInt(AppConstants.BP_DATA_SBP);
    int dbp = bundle.getInt(AppConstants.BP_DATA_DBP);
    int hr = bundle.getInt(AppConstants.BP_DATA_HR);
    mTxtSystolic_value.setText(String.format("%d", sbp));
    mTxtDiastolic_value.setText(String.format("%d", dbp));
    mTxtHeart_rate_value.setText(String.format("%d", hr));
    //mTxtHeart_rate_value.setText("--");
    ArrayList<Integer> pwttList =
        getpwtt(bundle.getIntegerArrayList(AppConstants.BP_DATA_PWTT_LIST));
    ArrayList<String> xData = new ArrayList<>();
    //for(int i =1; i< pwttList.size() +1; ++i){
    //  xData.add(String.format("%d", i));
    //}
    for (int i = 1; i <= pwttList.size(); i++) {
      if (i == 1 || i == pwttList.size()) {
        xData.add(String.format("%d", i));
      } else {
        xData.add("");
      }
    }

    BPMeasureResultFragment fragment =
        (BPMeasureResultFragment) getSupportFragmentManager().findFragmentById(
            R.id.fragment_bp_measure_result);
    fragment.init(xData, pwttList);
  }

  private ArrayList<Integer> getpwtt(ArrayList<Integer> rawPwtt) {
    for (int i = 0; i < rawPwtt.size(); ++i) {
      rawPwtt.set(i, rawPwtt.get(i) * 1000 / 512);
    }
    return rawPwtt;
  }

  public String loadJSONFromAsset() {
    String json = null;
    try {
      InputStream is = getResources().openRawResource(R.raw.bp_result);
      int size = is.available();
      byte[] buffer = new byte[size];
      is.read(buffer);
      is.close();
      json = new String(buffer, "UTF-8");
    } catch (IOException ex) {
      ex.printStackTrace();
      return null;
    }
    return json;
  }

  @Override public boolean onOptionsItemSelected(MenuItem item) {
    finish();
    return super.onOptionsItemSelected(item);
  }

  private void uploadRecord() {
    if (RecordService.getInstance().getCurrentFile() != null) {
      MyProjectApi.getIoTService()
          .uploadLogFile(RecordService.getInstance().getCurrentFile())
          .subscribeOn(Schedulers.io())
          .observeOn(AndroidSchedulers.mainThread())
          .subscribe(new Subscriber<String>() {
            @Override public void onCompleted() {

            }

            @Override public void onError(Throwable e) {
              Toast.makeText(getApplication(), e.getMessage(), Toast.LENGTH_LONG).show();
              e.printStackTrace();
            }

            @Override public void onNext(String msg) {
              if (!TextUtils.isEmpty(msg)) {
                Toast.makeText(getApplication(), msg, Toast.LENGTH_LONG).show();
              }
            }
          });
    }
  }
}
