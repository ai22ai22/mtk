package com.mediatek.mt2511.network;

import com.mediatek.mt2511.BuildConfig;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.squareup.okhttp.OkHttpClient;
import java.io.IOException;
import java.io.InputStream;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

public class NetworkUtils {

  public static OkHttpClient createOkHttpClient() {
    OkHttpClient httpClient = MOkHttpClient.createOkHttpClient();
    boolean self_signed_ca = MContext.getInstance().isSelfSignedCA();
    if (self_signed_ca) {
      try {
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        InputStream cert =
            MContext.getInstance().getApplication().getResources().openRawResource(R.raw.healthcer);
        Certificate ca = null;
        try {
          ca = cf.generateCertificate(cert);
        } finally {
          try {
            cert.close();
          } catch (IOException e) {
            e.printStackTrace();
          }
        }

        String keyStoreType = KeyStore.getDefaultType();
        KeyStore keyStore = KeyStore.getInstance(keyStoreType);
        keyStore.load(null, null);
        keyStore.setCertificateEntry("ca", ca);
        String tmfAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(tmfAlgorithm);
        tmf.init(keyStore);
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, tmf.getTrustManagers(), null);
        httpClient.setSslSocketFactory(sslContext.getSocketFactory());
        CookieManager cookieManager = new CookieManager();
        cookieManager.setCookiePolicy(CookiePolicy.ACCEPT_ORIGINAL_SERVER);
        httpClient.setCookieHandler(cookieManager);
      } catch (CertificateException e) {
        e.printStackTrace();
      } catch (NoSuchAlgorithmException e) {
        e.printStackTrace();
      } catch (KeyStoreException e) {
        e.printStackTrace();
      } catch (IOException e) {
        e.printStackTrace();
      } catch (KeyManagementException e) {
        e.printStackTrace();
      }
    }
    return httpClient;
  }
}
