package com.mediatek.mt2511.models.entity;

import com.google.gson.Gson;

public class ApiResponseEntity extends ApiMessageEntity {
  private Object results;

  public Object getResults() {
    return results;
  }

  public String getResultsString(String json) {
    Gson gson = new Gson();
    ApiResponseEntity obj = gson.fromJson(json, ApiResponseEntity.class);
    Object result = obj.getResults();
    return gson.toJson(result);
  }
}
