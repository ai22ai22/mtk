package com.mediatek.mt2511.snr;

import java.util.ArrayList;

public class SNRResult {
    public final int PPG_ORDER_128HZ = 30;

    public final int PPG_ORDER_512HZ = 128;

    public final int EKG_ORDER_512HZ = 128;

    private double mPPG128SNR10 = 0.0f;

    private double mPPG512SNR10 = 0.0f;

    private double mECG512SNR40 = 0.0f;

    private ArrayList<Double> mHPFSignalList;

    public void inputHPFSignal(double hpfSingal) {
        if (mHPFSignalList == null) {
            mHPFSignalList = new ArrayList<Double>();
        }
        mHPFSignalList.add(hpfSingal);
        return;
    }

    public ArrayList<Double> getHPFSignal() {
        return mHPFSignalList;
    }

    // For heart rate PPG or any condition that PPG fs is 125/128
    public boolean computePPG128SNR10() {
        System.out.println("~~~~~~~~~~computePPG128SNR10");
        return true;
    }

    public double getPPG128SNR10() {
        return mPPG128SNR10;
    }

    // For blood pressure PPG or any condition that PPG fs is 512
    public boolean computePPG512SNR10(ArrayList<Double> allLPFSingalList) {
        // only use allLPFSingalList(1+128/2, HFP Size + 128/2)
        ArrayList<Double> lpfSingalList = new ArrayList<Double>();
        for (int i = PPG_ORDER_512HZ / 2; i < (mHPFSignalList.size() + PPG_ORDER_512HZ / 2); i++) {
            lpfSingalList.add(allLPFSingalList.get(i));
        }

        // get NoiseList after LPF
        ArrayList<Double> lpfNoiseSingalList = new ArrayList<Double>();
        for (int i = 0; i < lpfSingalList.size(); i++) {
            double noise = mHPFSignalList.get(i) - lpfSingalList.get(i);
            lpfNoiseSingalList.add(noise);
        }

        // compute SNR
        ArrayList<Double> signal = lpfSingalList;
        ArrayList<Double> noise = lpfNoiseSingalList;
        double p_signal = 0.0;
        double p_noise = 0.0;
        for (int i = 0; i < signal.size(); i++) {
            p_signal += Math.pow(signal.get(i).doubleValue(), 2);
        }
        for (int i = 0; i < noise.size(); i++) {
            p_noise += Math.pow(noise.get(i).doubleValue(), 2);
        }
        mPPG512SNR10 = (float) (10.0 * Math.log10(p_signal / p_noise));
        return true;
    }

    public double getPPG512SNR10() {
        return mPPG512SNR10;
    }

    // For blood pressure EKG or any condition that EKG fs is 512
    public boolean computeECG512SNR40(ArrayList<Double> allLPFSingalList) {
        // only use allLPFSingalList(1+128/2, HFP Size + 128/2)
        ArrayList<Double> lpfSingalList = new ArrayList<Double>();
        for (int i = PPG_ORDER_512HZ / 2; i < (mHPFSignalList.size() + PPG_ORDER_512HZ / 2); i++) {
            lpfSingalList.add(allLPFSingalList.get(i));
        }

        // get NoiseList after LPF (=s_hpf - sig_filt)
        ArrayList<Double> lpfNoiseSingalList = new ArrayList<Double>();
        for (int i = 0; i < lpfSingalList.size(); i++) {
            double noise = mHPFSignalList.get(i) - lpfSingalList.get(i);
            lpfNoiseSingalList.add(noise);
        }

        // compute SNR
        ArrayList<Double> signal = lpfSingalList;
        ArrayList<Double> noise = lpfNoiseSingalList;
        double p_signal = 0.0;
        double p_noise = 0.0;
        for (int i = 0; i < signal.size(); i++) {
            p_signal += Math.pow(signal.get(i).doubleValue(), 2);
        }
        for (int i = 0; i < noise.size(); i++) {
            p_noise += Math.pow(noise.get(i).doubleValue(), 2);
        }
        mECG512SNR40 = (double) (10.0 * Math.log10(p_signal / p_noise));
        return true;
    }

    public double getEKG512SNR40() {
        return mECG512SNR40;
    }
}
