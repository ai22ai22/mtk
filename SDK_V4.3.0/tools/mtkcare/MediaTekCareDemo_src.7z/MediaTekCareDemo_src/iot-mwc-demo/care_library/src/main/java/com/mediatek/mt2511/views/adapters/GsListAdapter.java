package com.mediatek.mt2511.views.adapters;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.marshalchen.ultimaterecyclerview.UltimateViewAdapter;
import java.util.List;

public abstract class GsListAdapter<T, VH extends RecyclerView.ViewHolder>
    extends UltimateViewAdapter<VH> {

  protected Activity mActivity;
  protected LayoutInflater mInflater;
  protected List<T> mDataList;

  public GsListAdapter(Activity activity, List<T> list) {
    this.mActivity = activity;
    this.mInflater = LayoutInflater.from(activity);
    this.mDataList = list;
  }

  @Override public int getItemCount() {
    return mDataList == null ? 0 : mDataList.size();
  }

  @Override public int getAdapterItemCount() {
    return mDataList.size();
  }

  @Override abstract public VH getViewHolder(View view);

  @Override abstract public VH onCreateViewHolder(ViewGroup viewGroup);

  @Override abstract public void onBindViewHolder(VH holder, int position);

  @Override public long generateHeaderId(int i) {
    return 0;
  }

  @Override public VH onCreateHeaderViewHolder(ViewGroup viewGroup) {
    return null;
  }

  @Override public void onBindHeaderViewHolder(RecyclerView.ViewHolder viewHolder, int i) {}
}
