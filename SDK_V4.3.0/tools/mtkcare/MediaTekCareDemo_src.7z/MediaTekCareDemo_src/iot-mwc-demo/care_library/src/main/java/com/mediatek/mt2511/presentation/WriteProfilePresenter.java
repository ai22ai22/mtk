package com.mediatek.mt2511.presentation;

import com.mediatek.mt2511.interfaces.ShowProfile;
import com.mediatek.mt2511.models.ApiModel;
import com.mediatek.mt2511.models.BTCommandModel;
import com.mediatek.mt2511.models.PersonalModel;
import com.mediatek.mt2511.models.PersonalProfileEntity;
import com.mediatek.mt2511.models.pojo.RecordResult;
import com.mediatek.mt2511.models.pojo.UploadCareRequest;
import com.mediatek.mt2511.network.MyProjectApi;
import com.mediatek.mt2511.services.UserSession;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.subscriptions.CompositeSubscription;
import timber.log.Timber;

public class WriteProfilePresenter implements Presenter<ShowProfile> {
  private BTCommandModel btCommandModel = BTCommandModel.getDefault();
  private PersonalModel personalModel = PersonalModel.getDefault();
  private ShowProfile view;
  private CompositeSubscription mSubscriptions = new CompositeSubscription();
  private ApiModel apiModel = new ApiModel();

  public void setCurrentProfile(final PersonalProfileEntity personalProfileEntity) {
    Observable<String> ob1 = btCommandModel.writeProfile(personalProfileEntity);
    Observable<String> ob2 = apiModel.requestApi(personalProfileEntity);
    view.showProgressLoading();
    mSubscriptions.add(Observable.concat(ob1, ob2)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {
            view.dismissProgressLoading(null);
            view.setCurrentProfileComplete(personalProfileEntity.getUserId());
          }

          @Override public void onError(Throwable e) {
            Timber.e(e, "setCurrentProfile-onError:" + e.getMessage());
            view.setCurrentProfileComplete(e.getMessage());
            view.dismissProgressLoading(e);
          }

          @Override public void onNext(String s) {

          }
        }));
  }

  public void setCurrentProfile(String id) {
    setCurrentProfile(personalModel.loadById(id));
  }

  @Override public void setView(ShowProfile view) {
    this.view = view;
  }

  public void exit() {
    mSubscriptions.clear();
  }
}
