package com.mediatek.mt2511.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.Toast;
import com.mediatek.iot.BluetoothDeviceInfo;
import com.mediatek.iot.Device;
import com.mediatek.mt2511.AppConstants;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.custom.BTDeviceFactory;
import com.mediatek.mt2511.fragments.DevicesFragment;
import com.mediatek.mt2511.fragments.LoadingFragment;
import java.util.ArrayList;
import java.util.Arrays;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;


public class DevicesActivity extends FragmentActivity {

  private CompositeSubscription mSubscriptions = new CompositeSubscription();
  private Device mDevice = BTDeviceFactory.getBTDevice();

  @Override protected void onPause() {
    super.onPause();
  }

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_devices);
    DevicesFragment devicesFragment =
        (DevicesFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_devicesList);
    mSubscriptions.add(devicesFragment.getDeviceInfo()
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<BluetoothDeviceInfo>() {
          @Override public void call(BluetoothDeviceInfo deviceInfo) {
            connect(deviceInfo.getMacAddress());
          }
        }));

    mSubscriptions.add(mDevice.getStateObservable()
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<Integer>() {
          @Override public void onCompleted() {
            hideLoadingFragment();
          }

          @Override public void onError(Throwable e) {
            Toast.makeText(getApplication(), e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
          }

          @Override public void onNext(Integer status) {
            if (status == Device.STATE_CONNECTED) {
              String[] fragments = MContext.getInstance().getFeatureFragment();
              Intent intent = new Intent(DevicesActivity.this, DataBoardActivity.class);
              intent.putStringArrayListExtra(AppConstants.INTENT_DATA_FRAGMENT,
                  new ArrayList<>(Arrays.asList(fragments)));
              startActivity(intent);
            }
            if (status != Device.STATE_CONNECTING) {
              hideLoadingFragment();
            }
          }
        }));
  }

  private void connect(String macAddress) {
    mDevice.connect(macAddress);
    FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
    transaction.replace(R.id.layout_loading, new LoadingFragment(), LoadingFragment.TAG);
    transaction.commit();
    findViewById(R.id.layout_loading).setVisibility(View.VISIBLE);
  }

  private void hideLoadingFragment() {
    findViewById(R.id.layout_loading).setVisibility(View.GONE);
    Fragment fragment = getSupportFragmentManager().findFragmentByTag(LoadingFragment.TAG);
    if (fragment != null) {
      getSupportFragmentManager().beginTransaction().remove(fragment).commit();
    }
  }

  @Override protected void onDestroy() {
    super.onDestroy();
    mSubscriptions.clear();
    if (mDevice.getState() != Device.STATE_DISCONNECTED) {
      mDevice.disconnect();
    }
  }

  @Override public void onBackPressed() {
    if (mDevice.getState() == Device.STATE_CONNECTING) {
      mDevice.disconnect();
    } else {
      BTDeviceFactory.getBTScanner().stopScan();
      Intent upIntent = new Intent(this, FrontActivity.class);
      upIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
      upIntent.putExtra("EXIT", true);
      startActivity(upIntent);
      finish();
    }
  }
}
