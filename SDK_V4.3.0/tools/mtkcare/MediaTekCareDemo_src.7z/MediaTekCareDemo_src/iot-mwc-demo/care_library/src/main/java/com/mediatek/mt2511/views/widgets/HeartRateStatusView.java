package com.mediatek.mt2511.views.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;
import android.widget.Toast;
import com.mediatek.iot.data.bt.HeartRateData;
import com.mediatek.mt2511.R;
import com.mediatek.utils.RxBus;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;

public class HeartRateStatusView extends TextView {
  private static final int INTERVAL_TOAST = 5000;
  private CompositeSubscription mSubscriptions = new CompositeSubscription();
  private long mLastToastShowTime = 0;
  public HeartRateStatusView(Context context) {
    super(context, null);
    initView();
  }

  public HeartRateStatusView(Context context, AttributeSet attrs) {
    super(context, attrs);
    initView();
  }

  public HeartRateStatusView(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    initView();
  }

  private void initView() {

  }

  @Override protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    subscribeData();
  }

  private void subscribeData() {
    mSubscriptions.add(RxBus.getInstance()
        .toObservable(HeartRateData.class)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<HeartRateData>() {
          @Override public void call(HeartRateData heartRateData) {
            int status = heartRateData.get(HeartRateData.FIELD_STATUS);
            int confidence_level = (byte)(status & 0x000000FF);
            receive_confidence_level(confidence_level);
          }
        }));
  }
  private void receive_confidence_level(int confidence_level) {
    setText(String.format("%d", confidence_level));
    if (confidence_level == 0 || confidence_level == 1) {
      if (System.currentTimeMillis() - mLastToastShowTime > INTERVAL_TOAST) {
        Toast.makeText(getContext(), R.string.toast_confidence_level, Toast.LENGTH_LONG).show();
      }
      mLastToastShowTime = System.currentTimeMillis();
    }
  }
  @Override protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    mSubscriptions.clear();
  }
}
