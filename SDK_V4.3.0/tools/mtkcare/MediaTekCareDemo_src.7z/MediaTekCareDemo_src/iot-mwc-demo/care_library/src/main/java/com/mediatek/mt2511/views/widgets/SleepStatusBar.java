package com.mediatek.mt2511.views.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.widget.LinearLayout;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.SleepContent.Stage;
import com.mediatek.mt2511.utils.MContextCompat;
import com.mediatek.mt2511.utils.UIUtils;

public class SleepStatusBar extends LinearLayout {

  private Paint paint;
  private int percentage;
  private int colorResId;
  private String barDuration;

  public SleepStatusBar(Context context) {
    super(context);
    initViews();
  }

  public SleepStatusBar(Context context, AttributeSet attrs) {
    super(context, attrs);
    initViews();
  }

  public SleepStatusBar(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    initViews();
  }

  public void drawViewByStage(Stage stage) {
    this.colorResId = stage.getStageColor();
    this.percentage = UIUtils.roundDown(stage.getPercentage());
    this.barDuration = stage.getTime().toDurationString();
    invalidate();
  }

  private void initViews() {
    View view = inflate(getContext(), R.layout.widget_sleep_status_bar, this);
    this.paint = new Paint();
    setWillNotDraw(false);
  }

  @Override public void onDraw(Canvas canvas) {
    super.onDraw(canvas);

    int width = this.getWidth();
    int height = this.getHeight();
    float position_x;
    float text_size_px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 14,
        getContext().getResources().getDisplayMetrics());

    if (this.percentage > 0) {
      this.paint.setColor(MContextCompat.getColor(getContext(), this.colorResId));
      this.paint.setStyle(Paint.Style.FILL);
      this.paint.setAntiAlias(true);

      if (this.percentage <= 7.5) {
        position_x = 15;
      } else {
        position_x = width * 3 * (float) this.percentage / 500;
        canvas.drawRect(15, height / 2 - 15, position_x, height / 2 + 15, this.paint);
      }
      this.paint.setStrokeWidth(1);
      canvas.drawCircle(15, height / 2, 15, this.paint);
      canvas.drawCircle(position_x, height / 2, 15, this.paint);

      this.paint.setColor(MContextCompat.getColor(getContext(), R.color.gs_dark_gray));
      this.paint.setStrokeWidth(1);
      this.paint.setTextSize(text_size_px);
      this.paint.setFakeBoldText(true);
      Rect textBounds = new Rect();
      this.paint.getTextBounds(this.barDuration, 0, this.barDuration.length(), textBounds);
      int textHeight = textBounds.bottom - textBounds.top;
      canvas.drawText(this.barDuration, width * 3 * (float) this.percentage / 500 + 28,
          (height + textHeight) / 2, this.paint);
    }
  }
}
