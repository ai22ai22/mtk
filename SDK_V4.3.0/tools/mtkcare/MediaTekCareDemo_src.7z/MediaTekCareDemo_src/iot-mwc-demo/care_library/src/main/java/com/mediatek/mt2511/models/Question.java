package com.mediatek.mt2511.models;

/**
 * Created by MTK40526 on 11/1/2016.
 */

public class Question {
    public String desc;
}
