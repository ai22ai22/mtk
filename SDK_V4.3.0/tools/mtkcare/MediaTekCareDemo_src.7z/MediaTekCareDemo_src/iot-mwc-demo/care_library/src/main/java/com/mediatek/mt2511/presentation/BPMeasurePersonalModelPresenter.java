package com.mediatek.mt2511.presentation;

import com.mediatek.mt2511.fragments.BPMeasurePersonalFragment;

public class BPMeasurePersonalModelPresenter implements Presenter<BPMeasurePersonalFragment>{
  private BPMeasurePersonalFragment view;

  @Override public void setView(BPMeasurePersonalFragment view) {
    this.view = view;
  }


}
