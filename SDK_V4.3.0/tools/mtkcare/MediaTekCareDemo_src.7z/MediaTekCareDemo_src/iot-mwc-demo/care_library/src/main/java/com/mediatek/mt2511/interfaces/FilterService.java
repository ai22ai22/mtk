package com.mediatek.mt2511.interfaces;

/**
 * Created by MTK40526 on 3/23/2016.
 */
public interface FilterService {
    float filter(float data);
}
