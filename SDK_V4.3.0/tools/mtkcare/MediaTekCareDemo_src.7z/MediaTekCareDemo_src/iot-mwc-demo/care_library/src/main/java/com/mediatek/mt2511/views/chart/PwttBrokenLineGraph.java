package com.mediatek.mt2511.views.chart;

import android.content.Context;
import android.util.AttributeSet;
import com.mediatek.maschart.Charts;
import com.mediatek.maschart.brokenlinegraph.BrokenLineGraph;
import com.mediatek.maschart.brokenlinegraph.BrokenLineGraphType;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import java.util.ArrayList;
import java.util.List;

public class PwttBrokenLineGraph extends BrokenLineGraph {
  private List<String> xData = new ArrayList<>();
  private List<Integer> yData = new ArrayList<>();
  private int maxValue = -1;
  private int minValue = -1;

  public PwttBrokenLineGraph(Context context) {
    super(context);
    initViews();
  }

  public PwttBrokenLineGraph(Context context, AttributeSet attrs) {
    super(context, attrs);
    initViews();
  }

  public PwttBrokenLineGraph(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    initViews();
  }

  private void initViews() {
    inflate(getContext(), R.layout.broken_line_graph, this);
    Charts.init(MContext.getInstance().getApplication().getApplicationContext());
    setChartBgColor(R.color.line_chart_bg);
    setWillNotDraw(false);
  }

  public void initBrokenLineGraph(ArrayList<String> xData, ArrayList<Integer> yData) {
    this.xData = xData;
    this.yData = yData;
    maxValue = 500;
    minValue = 0;



    int range = maxValue - minValue;
    int[] yAxisInt = { 0, range / 2, range };
    String[] yAxisStr = {
        String.valueOf(minValue), String.valueOf(minValue + range / 2), String.valueOf(maxValue)
    };

    for (int i = 0; i < yData.size(); i++) {
      yData.set(i, yData.get(i) - minValue);
    }

    setTodayValueStr("");
    setScale(yAxisInt);
    setScaleStr(yAxisStr);
    setReports(xData, yData);
    setChartStyle(BrokenLineGraphType.BP);
    setLeftTitle("");
    setRightTitleUnit("(ms)");
    invalidate();
  }
}
