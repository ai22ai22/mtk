package com.mediatek.mt2511.activities;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.entity.ReportDetailEntity;
import com.mediatek.mt2511.views.widgets.DetailChartPanel;
import com.mediatek.mt2511.views.widgets.DetailDescPanel;
import java.io.IOException;
import java.io.InputStream;

public class ReportDetailActivity extends AppCompatActivity {

  private final int INTENT_ERROR = -1;
  protected Toolbar toolbar;
  DetailChartPanel panel_chart;
  DetailDescPanel panel_desc;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    setContentView(R.layout.activity_report_detail);

    //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
    //setSupportActionBar(toolbar);

    String asleepDate = getIntent().getStringExtra("asleepDate");
    int sleepReportId = getIntent().getIntExtra("sleepReportId", INTENT_ERROR);
    setToolbarTitle(asleepDate);

    getApiData(String.valueOf(sleepReportId));
  }

  @Override public void setContentView(int layoutResID) {
    super.setContentView(layoutResID);
    initView();
    if (toolbar != null) {
      setSupportActionBar(toolbar);
      getSupportActionBar().setTitle(null);
      getSupportActionBar().setDisplayHomeAsUpEnabled(true);
      setToolbarTitle(getTitle().toString());

      getSupportActionBar().setHomeAsUpIndicator(
          ContextCompat.getDrawable(this, R.drawable.ic_up_indicator));
    }
  }
  protected void initView() {
    toolbar = (Toolbar) findViewById(R.id.toolbar);
    panel_chart = (DetailChartPanel) findViewById(R.id.panel_detail_chart);
    panel_desc = (DetailDescPanel) findViewById(R.id.panel_detail_desc);
  }
  protected void setToolbarTitle(String title) {
    if (toolbar != null) {
      TextView tv_title = (TextView) toolbar.findViewById(R.id.toolbar_title);
      if (tv_title != null) {
        tv_title.setText(title);
      }
    }
  }
  private void getApiData(String sleepReportId) {
    String hardcode = loadJSONFromAsset();
    ReportDetailEntity entity = new ReportDetailEntity().fromJson(hardcode);
    panel_chart.setSleepContent(entity.getSleepContent());
    panel_desc.setData(entity);
  }

  public String loadJSONFromAsset() {
    String json = null;
    try {
      //InputStream is = getAssets().open("raw/sleep_staging.json");

      InputStream is = getResources().openRawResource(R.raw.sleep_report_detail);
      int size = is.available();
      byte[] buffer = new byte[size];
      is.read(buffer);
      is.close();
      json = new String(buffer, "UTF-8");
    } catch (IOException ex) {
      ex.printStackTrace();
      return null;
    }
    return json;
  }
  @Override public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case android.R.id.home:
        finish();
        break;
    }
    return false;
  }
}
