package com.mediatek.mt2511.services;

import java.util.ArrayList;

public class ServicesManager {

  private static ServicesManager instance;
  private ArrayList<Service> services = new ArrayList<>();

  public static ServicesManager getInstance(){
    if(instance == null){
      instance = new ServicesManager();
    }
    return instance;
  }

  public void stopAll(){
    for(Service service: services){
      service.stop();
    }
    services.clear();
  }

  public void add(Service service){
    services.add(service);
  }



}
