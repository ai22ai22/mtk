package com.mediatek.mt2511.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.widget.ImageButton;


public class ImageNumberButton extends ImageButton {
	private int num = 0;
	private DisplayMetrics dm;
	public ImageNumberButton(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}
	public ImageNumberButton(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}
	public ImageNumberButton(Context context, AttributeSet attrs,
							 int defStyleAttr) {
		super(context, attrs, defStyleAttr);
	}
	
	public void setNumber(int num){
		this.num = num;
		invalidate();
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		
		if(num>0){
			dm = getContext().getApplicationContext().getResources()
					.getDisplayMetrics();
			final Paint paint = new Paint();
			paint.setColor(Color.RED);
			paint.setFlags(Paint.ANTI_ALIAS_FLAG);
			paint.setStyle(Style.FILL_AND_STROKE);
			//float radius = Utils.px2dip(getWidth()/3, dm.density);
			float radius = getWidth()/6;
			canvas.drawCircle(getWidth()-radius, radius,radius , paint);
			paint.setColor(Color.WHITE);
			//paint.setTextSize(Utils.px2dip(getWidth()/3.0f, dm.density));
			float len = paint.measureText(String.valueOf(num));
			float x = getWidth()-radius + 0f - len/2;
			canvas.drawText(String.valueOf(num),x, radius+5f, paint);
		}
	}
    
}
