package com.mediatek.mt2511.network;

import com.facebook.stetho.okhttp.StethoInterceptor;
import com.mediatek.mt2511.BuildConfig;
import com.squareup.okhttp.OkHttpClient;

public class MOkHttpClient {
  private static StethoInterceptor stethoInterceptor = new StethoInterceptor();
  public static OkHttpClient createOkHttpClient(){
    OkHttpClient client = new OkHttpClient();
    client.networkInterceptors().add(stethoInterceptor);
    return client;
  }
}
