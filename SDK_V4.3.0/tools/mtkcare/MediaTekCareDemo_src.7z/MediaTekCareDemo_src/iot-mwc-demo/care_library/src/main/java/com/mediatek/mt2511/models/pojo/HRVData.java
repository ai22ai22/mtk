package com.mediatek.mt2511.models.pojo;

import com.mediatek.mt2511.utils.DatatypeConverter;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;

/**
 * Created by MTK40526 on 1/29/2016.
 */
public class HRVData {
    private double lf, hf, lfhf, sdnn;
    private Date date;

    public int getAlgoId() {
        return algoId;
    }

    public Date getDate() {
        return date;
    }

    public int getFeatureId() {
        return featureId;
    }

    public double getHf() {
        return hf;
    }

    public int getLength() {
        return length;
    }

    public double getLf() {
        return lf;
    }

    public double getLfhf() {
        return lfhf;
    }

    public double getSdnn() {
        return sdnn;
    }

    private int algoId,featureId;
    private int length;
    public HRVData(byte[] bytes) throws IOException {
        if (bytes != null && bytes.length > 0) {

            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
            algoId = byteArrayInputStream.read();
            if (algoId != 4){
                throw new IOException("invalid algoId");
            }
            length = byteArrayInputStream.read();
/*            if(length + 1 != byteArrayInputStream.available()){
                throw new IOException("invalid format");
            }*/
            byte[] buffer = new byte[4];
            byteArrayInputStream.read(buffer);
            date = new Date(DatatypeConverter.byte4ToInt(buffer) * 1000);
            featureId = byteArrayInputStream.read();
            byteArrayInputStream.read(buffer);
            lf = DatatypeConverter.byte4ToInt(buffer) / 1000.0;
            byteArrayInputStream.read(buffer);
            hf = DatatypeConverter.byte4ToInt(buffer) / 1000.0;
            byteArrayInputStream.read(buffer);
            lfhf = DatatypeConverter.byte4ToInt(buffer) / 1000.0;
            Arrays.fill(buffer, (byte) 0);
            byteArrayInputStream.read(buffer);
            sdnn = DatatypeConverter.byte4ToInt(buffer) / 1000.0;
        }
    }
}
