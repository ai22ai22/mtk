package com.mediatek.mt2511.utils;

import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;

public final class HrvStatus {
  private HrvStatus() {
  }

  public static final String EXCITED =
      MContext.getInstance().getApplication().getString(R.string.hrv_status_excited);
  public static final String GOOD =
      MContext.getInstance().getApplication().getString(R.string.hrv_status_good);
  public static final String STRESSED =
      MContext.getInstance().getApplication().getString(R.string.hrv_status_stressed);
  public static final String DEPRESSED =
      MContext.getInstance().getApplication().getString(R.string.hrv_status_depressed);

  private static final String API_EXCITED = "excited";
  private static final String API_GOOD = "good";
  private static final String API_STRESSED = "stressed";
  private static final String API_DEPRESSED = "depressed";

  public static String toApiValue(String status) {
    if (status == null) return "";
    return status.equals(EXCITED) ? API_EXCITED : status.equals(GOOD) ? API_GOOD
        : status.equals(STRESSED) ? API_STRESSED : status.equals(DEPRESSED) ? API_DEPRESSED : "";
  }

  public static String parseApiValue(String description) {
    if (description == null) return "";
    return description.equals(API_EXCITED) ? EXCITED : description.equals(API_GOOD) ? GOOD
        : description.equals(API_STRESSED) ? STRESSED
            : description.equals(API_DEPRESSED) ? DEPRESSED : "";
  }
}
