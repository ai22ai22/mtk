package com.mediatek.mt2511.presentation;

import android.widget.Toast;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.fragments.BPMeasureFragment;
import com.mediatek.mt2511.models.BTCommandModel;
import com.mediatek.mt2511.services.UserSession;
import com.mediatek.mt2511.utils.DataUtils;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

public class BPMeasurePresenter implements Presenter<BPMeasureFragment> {
  private BPMeasureFragment view;
  private BTCommandModel btCommandModel = BTCommandModel.getDefault();

  @Override public void setView(BPMeasureFragment view) {
    this.view = view;
  }

  public void restoreDefault() {

    final UserSession.RecordInfo defaultRecordInfo = UserSession.getInstance().getDefaultProfile();
    if (defaultRecordInfo == null) {
      view.showAddRecord(true);
    } else {
      view.showProgressLoading();
      Observable<String> writeProfile =
          btCommandModel.writeProfile(DataUtils.trans2Profile(defaultRecordInfo));
      writeProfile.observeOn(AndroidSchedulers.mainThread()).subscribe(new Subscriber<String>() {
        @Override public void onCompleted() {
          UserSession.getInstance().saveRecordInfo(defaultRecordInfo);
          // view.setCurrentProfileComplete(defaultRecordInfo.userId);
          view.dismissProgressLoading(null);
          Toast.makeText(MContext.getInstance().getApplication(), R.string.ready_to_bp,
              Toast.LENGTH_SHORT).show();
        }

        @Override public void onError(Throwable e) {
          //view.showError(e.getMessage());
          Timber.e(e, e.getMessage());
          view.dismissProgressLoading(e);
        }

        @Override public void onNext(String s) {

        }
      });
    }
  }
}
