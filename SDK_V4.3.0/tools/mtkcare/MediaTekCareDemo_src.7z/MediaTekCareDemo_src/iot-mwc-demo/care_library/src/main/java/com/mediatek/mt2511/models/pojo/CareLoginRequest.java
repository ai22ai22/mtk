package com.mediatek.mt2511.models.pojo;

public class CareLoginRequest {
  public String username;
  public String password;
}
