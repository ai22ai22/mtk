package com.mediatek.mt2511.fragments;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.logs.BPLogService;
import com.mediatek.mt2511.network.MyProjectApi;
import com.mediatek.mt2511.views.validation.CompositeValidation;
import com.mediatek.mt2511.views.validation.NumberValidate;
import com.mediatek.mt2511.views.validation.RequiredValidate;
import com.mediatek.mt2511.views.validation.ValidateEvent;
import com.mediatek.mt2511.views.validation.ViewValidation;
import com.mediatek.utils.RxBus;
import java.io.IOException;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;
import timber.log.Timber;

/**
 * Created by MTK40526 on 6/2/2016.
 */
public class AddNoteDialogFragment extends DialogFragment {
  public static final String SP_ADD_NOTE = "SP_ADD_NOTE";
  EditText edtSystolic;
  EditText edtDiastolic;
  EditText edtHeartRate;

  private CompositeValidation mValidations = new CompositeValidation();
  private CompositeSubscription mSubscriptions = new CompositeSubscription();
  private int[] mEdt_ids = new int[] { R.id.edt_systolic, R.id.edt_diastolic, R.id.edt_heart_rate };

  public AddNoteDialogFragment() {
    // Empty constructor is required for DialogFragment
    // Make sure not to add arguments to the constructor
    // Use `newInstance` instead as shown below
  }

  @NonNull @Override public Dialog onCreateDialog(Bundle savedInstanceState) {

    AlertDialog dialog = new AlertDialog.Builder(getActivity()).setTitle(R.string.additional_note)
        .setView(R.layout.alert_dialog_framge_add_note)
        .setPositiveButton(R.string.btn_ok, null)
        .setNegativeButton(R.string.btn_cancel, new DialogInterface.OnClickListener() {
          @Override public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
          }
        })
        .create();

    dialog.setOnShowListener(new DialogInterface.OnShowListener() {
      @Override public void onShow(DialogInterface dialog) {
        final AlertDialog thisDialog = (AlertDialog) dialog;
        final Button btnOK = (Button) thisDialog.findViewById(android.R.id.button1);
        initView(thisDialog);
        restoreInput();
        mValidations.clear();
        RequiredValidate requiredValidate = new RequiredValidate();
        mValidations.addValidation(new ViewValidation(edtSystolic).addValid(requiredValidate)
            .addValid(new NumberValidate(50, 300)));
        mValidations.addValidation(new ViewValidation(edtDiastolic).addValid(requiredValidate)
            .addValid(new NumberValidate(30, 200)));
        mValidations.addValidation(new ViewValidation(edtHeartRate).addValid(requiredValidate));

        mSubscriptions.add(RxBus.getInstance()
            .toObservable(ValidateEvent.class)
            .subscribe(new Action1<ValidateEvent>() {
              @Override public void call(ValidateEvent validateEvent) {
                if (validateEvent.isValid() && mValidations.isValid()) {
                  btnOK.setEnabled(true);
                } else {
                  btnOK.setEnabled(false);
                }
              }
            }));
        btnOK.setEnabled(mValidations.isValid());
        btnOK.setOnClickListener(new View.OnClickListener() {
          @Override public void onClick(View v) {

            try {

              BPLogService.getInstance()
                  .reciveLog(
                      String.format("%s,%s,%s", edtSystolic.getText(), edtDiastolic.getText(),
                          edtHeartRate.getText()));

              storeInput();

              final ProgressDialog progressDialog =
                  ProgressDialog.show(getActivity(), getString(R.string.loading),
                      getString(R.string.waiting_a_moment), false);
              MyProjectApi.getIoTService()
                  .uploadLogFile(BPLogService.getInstance().getCurrentFile())
                  .observeOn(AndroidSchedulers.mainThread())
                  .subscribe(new Subscriber<String>() {
                    @Override public void onCompleted() {
                      thisDialog.dismiss();
                      progressDialog.dismiss();
                    }

                    @Override public void onError(Throwable e) {
                      Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
                      Timber.e(e, e.getMessage());
                      progressDialog.dismiss();
                    }

                    @Override public void onNext(String s) {
                      if (!TextUtils.isEmpty(s)) {
                        Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
                      } else {
                        Toast.makeText(getActivity(), R.string.bp_saved_hint, Toast.LENGTH_SHORT)
                            .show();
                      }
                    }
                  });
            } catch (IOException e) {
              e.printStackTrace();
              Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
            }
          }
        });
      }
    });

    return dialog;
  }

  private void initView(AlertDialog dialog) {
    edtSystolic = (EditText) dialog.findViewById(R.id.edt_systolic);
    edtDiastolic = (EditText) dialog.findViewById(R.id.edt_diastolic);
    edtHeartRate = (EditText) dialog.findViewById(R.id.edt_heart_rate);
  }

  @Override public void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
  }

  @Override public void onStop() {
    super.onStop();
    mSubscriptions.clear();
  }

  private void storeInput() {
    SharedPreferences.Editor editor =
        getActivity().getSharedPreferences(SP_ADD_NOTE, Context.MODE_PRIVATE).edit();
    for (int id : mEdt_ids) {
      EditText editText = (EditText) getDialog().findViewById(id);
      String text = editText.getText().toString();
      String key = getResources().getResourceName(id);
      editor.putString(key, text);
    }
    editor.apply();
  }

  private void restoreInput() {
    SharedPreferences sp = getActivity().getSharedPreferences(SP_ADD_NOTE, Context.MODE_PRIVATE);
    for (int id : mEdt_ids) {
      EditText editText = (EditText) getDialog().findViewById(id);
      String key = getResources().getResourceName(id);
      String value = sp.getString(key, "");
      editText.setText(value);
    }
  }

  @Override public void onStart() {
    super.onStart();
  }
}
