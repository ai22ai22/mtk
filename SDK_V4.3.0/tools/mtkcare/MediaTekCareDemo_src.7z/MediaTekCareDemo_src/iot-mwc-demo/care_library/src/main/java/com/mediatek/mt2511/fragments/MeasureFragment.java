package com.mediatek.mt2511.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.jakewharton.rxbinding.view.RxView;
import com.mediatek.iot.Device;
import com.mediatek.iot.data.bt.HeartRateData;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.apx.AP;
import com.mediatek.mt2511.apx.APResult;
import com.mediatek.mt2511.bluetooth.BLEDeviceFactory;
import com.mediatek.mt2511.bluetooth.data.BLEHeartRateData;
import com.mediatek.mt2511.custom.BTDeviceFactory;
import com.mediatek.mt2511.models.pojo.HRSaveRequest;
import com.mediatek.mt2511.network.MyProjectApi;
import com.mediatek.mt2511.services.ErrorMessageMonitor;
import com.mediatek.mt2511.services.RecordService;
import com.mediatek.mt2511.utils.DatatypeConverter;
import com.mediatek.mt2511.views.AlertMessageDialog;
import com.mediatek.mt2511.views.HeartBeatView;
import com.mediatek.mt2511.views.widgets.ClockTextView;
import com.mediatek.utils.RxBus;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;
import rx.subscriptions.CompositeSubscription;

/**
 * Created by MTK40526 on 3/25/2016.
 */
public class MeasureFragment extends CustomFragment {

  private static final String TAG = "MeasureFragment";
  private static final String STATE_RECORD = "STATE_RECORD";
  private static final String STATE_RECORD_START_TIMESTAMP = "STATE_RECORD_START_TIMESTAMP";
  /*    private Logger mLog = Logger.getLogger("MeasureFragment");*/

  private Device mBLEDevice = BLEDeviceFactory.getBLEDevice();
  private long mStartRecordTimeStamp = 0;
  private CompositeSubscription _subscriptions = new CompositeSubscription();
  private CompositeSubscription _writeLogSubscriptions = new CompositeSubscription();
  private Subscription _bleWriteLogSubscription = null;
  private CompositeSubscription mApSubscriptions = new CompositeSubscription();
  private ArrayList<Integer> mBLE_HR_TimeStamp;
  private ArrayList<Integer> mBLE_HR_Data;
  private ArrayList<Integer> mBT_HR_TimeStamp;
  private ArrayList<Integer> mBT_HR_Data;
  private int mAp_Start_TimeStamp;
  private HRSaveRequest addHRRequest = new HRSaveRequest();

  public MeasureFragment() {
    super();
    setTitle(MContext.getInstance().getApplication().getString(R.string.hr_measure));
  }

  @Override public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
    inflater.inflate(R.menu.hr_measure_menu, menu);
  }

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setHasOptionsMenu(true);
  }

  @Override public void onDestroy() {
    super.onDestroy();
    _subscriptions.clear();
  }

  @Override public void onDestroyView() {
    super.onDestroyView();
    _subscriptions.clear();
    mApSubscriptions.clear();
    stopRecord();

    if (addHRRequest.result.size() > 0) {
      requestSaveHR();
    }

    BLEDeviceFactory.getBLEDevice().disconnect();
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View rootView = inflater.inflate(R.layout.fragment_measure, container, false);
    initView(rootView);
    return rootView;
  }


  private void initView(View rootView) {
    _subscriptions.add(
        BTDeviceFactory.getBTDevice().getStateObservable().subscribe(new Action1<Integer>() {
          @Override public void call(Integer state) {
            if (state != Device.STATE_CONNECTED) {
              mApSubscriptions.clear();
            } else {

            }
          }
        }));

    _subscriptions.add(mBLEDevice.getStateObservable()
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<Integer>() {

          @Override public void call(Integer state) {
            getActivity().invalidateOptionsMenu();
          }
        }));
    _subscriptions.add(RxBus.getInstance()
        .toObservable(HeartRateData.class)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<HeartRateData>() {
          @Override public void call(HeartRateData heartRateData) {
            int hr = heartRateData.get(HeartRateData.FIELD_BPM);
            String bmp_view_value = String.valueOf(hr);
            addHRRequest.result.add(hr);
            if (addHRRequest.result.size() >= 5) {
              requestSaveHR();
            }
          }
        }));

    _subscriptions.add(RecordService.getInstance()
        .getRecordingObservable()
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<Boolean>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
            Log.e(TAG, e.getMessage(), e);
          }

          @Override public void onNext(Boolean inRecording) {
            if (!inRecording) {
              stopRecord();
            } else {
              startRecord();
            }
          }
        }));
  }

  private void requestSaveHR() {
    MyProjectApi.getIoTService()
        .saveHR(addHRRequest)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            e.printStackTrace();
            Log.e(TAG, e.getMessage(), e);
            Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
          }

          @Override public void onNext(String s) {

          }
        });
    addHRRequest = new HRSaveRequest();
  }

  @Override public void onStart() {
    super.onStart();
  }


  private void saveApResult() {
    if (mBLE_HR_Data != null && mBLE_HR_Data.size() > 0) {
      AP ap = new AP();
      APResult apResult =
          ap.compute_performance(DatatypeConverter.convertIntegers(mBLE_HR_TimeStamp),
              DatatypeConverter.convertIntegers(mBLE_HR_Data),
              DatatypeConverter.convertIntegers(mBT_HR_TimeStamp),
              DatatypeConverter.convertIntegers(mBT_HR_Data));

      new AlertMessageDialog(getActivity(),
          String.format("AP5:%.2f%% / AP10:%.2f%%", apResult.getAvailability5() * 100,
              apResult.getAvailability10() * 100)).show();

      String fileRoot = MContext.getInstance().getLogPath();
      final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
      String fileName = "result_" + dateFormat.format(mAp_Start_TimeStamp * 1000L);
      fileName = fileName.replace(".", "_").replace(":", "-") + ".csv";
      fileName = fileRoot + "/" + fileName;
      File file = new File(fileName);
      FileWriter fileWriter = null;
      try {
        fileWriter = new FileWriter(file, true);
        fileWriter.write(
            String.format("%f, %f, %f, %f", apResult.getMin_mean_error(), apResult.getStd_error(),
                apResult.getAvailability10(), apResult.getAvailability5()));
      } catch (IOException e) {
        e.printStackTrace();
      } finally {
        if (fileWriter != null) {
          try {
            fileWriter.close();
          } catch (IOException e) {
            e.printStackTrace();
          }
        }
      }
    }
    if (mBLE_HR_Data != null) {
      mBLE_HR_Data.clear();
    }
    if (mBLE_HR_TimeStamp != null) {
      mBLE_HR_TimeStamp.clear();
    }
    if (mBT_HR_Data != null) {
      mBT_HR_Data.clear();
    }
    if (mBT_HR_TimeStamp != null) {
      mBT_HR_TimeStamp.clear();
    }
  }

  private void stopRecord() {
    _writeLogSubscriptions.clear();
    mApSubscriptions.clear();
    saveApResult();
  }

  private void startRecord() {
    mAp_Start_TimeStamp = (int) (System.currentTimeMillis() / 1000L);
    mBLE_HR_Data = new ArrayList<>();
    mBLE_HR_TimeStamp = new ArrayList<>();
    mBT_HR_Data = new ArrayList<>();
    mBT_HR_TimeStamp = new ArrayList<>();
    mApSubscriptions.add(RxBus.getInstance()
        .toObservable(HeartRateData.class)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<HeartRateData>() {
          @Override public void call(HeartRateData heartRateData) {
            mBT_HR_Data.add(heartRateData.get(HeartRateData.FIELD_BPM));
            mBT_HR_TimeStamp.add((int) (System.currentTimeMillis() / 1000L));
          }
        }));
    if (mBLEDevice.getState() == Device.STATE_CONNECTED) {
      mApSubscriptions.add(_bleWriteLogSubscription = RxBus.getInstance()
          .toObservable(BLEHeartRateData.class)
          .subscribe(new Action1<BLEHeartRateData>() {
            @Override public void call(BLEHeartRateData heartRateData) {
              int hr = heartRateData.getValue();
              mBLE_HR_TimeStamp.add((int) (System.currentTimeMillis() / 1000L));
              mBLE_HR_Data.add(hr);
            }
          }));
    }

    mStartRecordTimeStamp = System.currentTimeMillis();
    //mLog.debug("startRecord");
    //btDeviceManager.startRecord();

    if (mBLEDevice.getState() == Device.STATE_CONNECTED) {
      _bleWriteLogSubscription = RxBus.getInstance()
          .toObservable(BLEHeartRateData.class)
          .observeOn(Schedulers.io())
          .subscribe(new Action1<BLEHeartRateData>() {
            @Override public void call(BLEHeartRateData heartRateData) {
              try {
                RecordService.getInstance()
                    .write("121,"
                        + heartRateData.getValue()
                        + ","
                        + (System.currentTimeMillis() / 1000L) +"\r\n");
              } catch (IOException e) {
                e.printStackTrace();
              }
            }
          });

      _writeLogSubscriptions.add(_bleWriteLogSubscription);
    }
  }
}
