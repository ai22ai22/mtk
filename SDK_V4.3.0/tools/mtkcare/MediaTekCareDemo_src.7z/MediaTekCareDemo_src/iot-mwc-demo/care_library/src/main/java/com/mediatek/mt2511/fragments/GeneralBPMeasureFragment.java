package com.mediatek.mt2511.fragments;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import com.mediatek.mt2511.AppConstants;
import com.mediatek.mt2511.R;

public class GeneralBPMeasureFragment extends BPMeasureFragment {
  @Override public void onStart() {
    super.onStart();
    setHasOptionsMenu(true);

  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = super.onCreateView(inflater, container, savedInstanceState);
    presenter.restoreDefault();
    return view;
  }

  @Override public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
    inflater.inflate(R.menu.bp_measure_menu, menu);
  }

  @Override public void onActivityResult(int requestCode, int resultCode, Intent data) {
    switch (requestCode){
      case AppConstants.REQUEST_ADD_RECORD:{
        if(resultCode == Activity.RESULT_OK){
          addRecordSuccess();
        }
        break;
      }
    }

  }

  private void addRecordSuccess() {
    Toast.makeText(getActivity(), R.string.ready_to_bp, Toast.LENGTH_LONG).show();
  }
}
