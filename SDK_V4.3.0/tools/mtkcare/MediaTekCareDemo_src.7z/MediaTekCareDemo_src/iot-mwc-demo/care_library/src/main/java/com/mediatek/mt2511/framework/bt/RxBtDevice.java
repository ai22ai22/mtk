package com.mediatek.mt2511.framework.bt;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import rx.Observable;
import rx.Scheduler;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.schedulers.Schedulers;
import rx.subjects.PublishSubject;
import timber.log.Timber;

public class RxBtDevice {
  private static final int TIMEOUT = 10;
  private static final int STATE_NONE = 0;       // we're doing nothing
  private static final int STATE_CONNECTING = 1; // now initiating an outgoing connection
  private static final int STATE_CONNECTED = 2;  // now connected to a remote device
  private static RxBtDevice instance;
  private final BluetoothDevice mBluetoothDevice;
  private final UUID mUUID;
  private final Scheduler mWorkScheduler;
  private int mState = STATE_NONE;
  private BluetoothSocket mSocket;
  private PublishSubject<byte[]> mReceiveDataSubject = PublishSubject.create();
  private PublishSubject mConnectSubject = PublishSubject.create();
  private OutputStream mOutputStream;
  private Subscription mConnectedSubscription;

  private RxBtDevice(BluetoothDevice bluetoothDevice, UUID uuid) {
    this.mBluetoothDevice = bluetoothDevice;
    this.mUUID = uuid;
    mWorkScheduler = Schedulers.newThread();
  }

  public static RxBtDevice getInstance(BluetoothDevice bluetoothDevice, UUID uuid) {
    if (instance == null) {
      instance = new RxBtDevice(bluetoothDevice, uuid);
    } else {
      if (!instance.mUUID.equals(uuid) || !bluetoothDevice.getAddress()
          .equals(instance.mBluetoothDevice.getAddress())) {
        instance.disconnect();
        instance = new RxBtDevice(bluetoothDevice, uuid);
      }
    }
    return instance;
  }


  public Observable<byte[]> writeCommand(final byte[] commands) {
    return connect().flatMap(new Func1() {
      @Override public Object call(Object o) {
        return Observable.create(new Observable.OnSubscribe<byte[]>() {
          private Subscription responseSubscription;

          @Override public void call(final Subscriber<? super byte[]> subscriber) {
            try {
              mOutputStream.write(commands);
              final Subscription timeoutSubscription = Observable.just(true)
                  .delay(TIMEOUT, TimeUnit.SECONDS)
                  .observeOn(Schedulers.immediate())
                  .subscribe(new Action1<Boolean>() {
                    @Override public void call(Boolean aBoolean) {
                      responseSubscription.unsubscribe();
                      subscriber.onError(new Exception("Time out"));
                    }
                  });
              responseSubscription = mReceiveDataSubject.asObservable()
                  .observeOn(Schedulers.immediate())
                  .subscribe(new Subscriber<byte[]>() {
                    @Override public void onCompleted() {

                    }

                    @Override public void onError(Throwable e) {
                      subscriber.onError(e);
                    }

                    @Override public void onNext(byte[] bytes) {
                      subscriber.onNext(bytes);
                      subscriber.onCompleted();
                      timeoutSubscription.unsubscribe();
                      responseSubscription.unsubscribe();
                    }
                  });
            } catch (IOException e) {
              e.printStackTrace();
              subscriber.onError(e);
            }
          }
        });
      }
    }).subscribeOn(mWorkScheduler);
  }

  private Observable connect() {
    return Observable.create(new Observable.OnSubscribe<BluetoothSocket>() {
      @Override public void call(Subscriber<? super BluetoothSocket> subscriber) {
        switch (mState) {
          case STATE_CONNECTED: {
            subscriber.onNext(null);
            subscriber.onCompleted();
            break;
          }
          case STATE_CONNECTING: {
            mConnectSubject.subscribe(subscriber);
            break;
          }
          case STATE_NONE: {
            requestConnect();
            mConnectSubject.subscribe(subscriber);
            break;
          }
        }
      }
    });
  }

  private void requestConnect() {
    Timber.d("requestConnect");
    setStatus(STATE_CONNECTING);
    mConnectSubject = PublishSubject.create();
    mReceiveDataSubject = PublishSubject.create();
    Observable.create(new Observable.OnSubscribe<BluetoothSocket>() {
      @Override public void call(Subscriber<? super BluetoothSocket> subscriber) {
        try {
          mSocket = mBluetoothDevice.createRfcommSocketToServiceRecord(mUUID);
          Timber.d("connect -%s", mBluetoothDevice.getAddress());
          mSocket.connect();
          mOutputStream = mSocket.getOutputStream();
          setStatus(STATE_CONNECTED);
          connected(mSocket.getInputStream());
          mConnectSubject.onNext(null);
          mConnectSubject.onCompleted();
        } catch (IOException e) {
          e.printStackTrace();
          mConnectSubject.onError(e);
          setStatus(STATE_NONE);
        }
      }
    }).subscribeOn(mWorkScheduler).subscribe();
  }

  private void connected(final InputStream inputStream) {
    mConnectedSubscription = Observable.create(new Observable.OnSubscribe<Object>() {
      @Override public void call(Subscriber<? super Object> subscriber) {
        while (true) {
          byte[] buffer = new byte[64];
          try {
            int bytes = inputStream.read(buffer);
            byte[] temp = new byte[bytes];
            System.arraycopy(buffer, 0, temp, 0, bytes);
            mReceiveDataSubject.onNext(temp);
          } catch (IOException e) {
            Timber.d("connection lost");
            mReceiveDataSubject.onError(e);
            e.printStackTrace();
            subscriber.onError(e);
            break;
          }
        }
        subscriber.add(new Subscription() {
          @Override public void unsubscribe() {
            try {
              if (mSocket != null) {
                mSocket.close();
              }
            } catch (IOException e) {
              e.printStackTrace();
            }
          }

          @Override public boolean isUnsubscribed() {
            return false;
          }
        });
      }
    })
        .subscribeOn(Schedulers.newThread())
        .observeOn(mWorkScheduler)
        .subscribe(new Subscriber<Object>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            connectFail();
          }

          @Override public void onNext(Object o) {

          }
        });
  }

  private void connectFail() {
    disconnect();
  }

  private synchronized void setStatus(int state) {
    mState = state;
  }

  public void disconnect() {
    Timber.d("disconnect");
    if (mConnectedSubscription != null) {
      mConnectedSubscription.unsubscribe();
      mConnectedSubscription = null;
    }
    setStatus(STATE_NONE);
    try {
      if (mSocket != null) {
        mSocket.close();
        mSocket = null;
      }
    } catch (IOException e) {
      e.printStackTrace();
      mSocket = null;
    }
  }
}
