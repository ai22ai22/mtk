package com.mediatek.mt2511.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import com.mediatek.iot.data.bt.HRVData;
import com.mediatek.iot.data.bt.HeartRateData;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.activities.HRVResultActivity;
import com.mediatek.mt2511.models.pojo.HRSaveRequest;
import com.mediatek.mt2511.models.pojo.HRVRequest;
import com.mediatek.mt2511.network.MyProjectApi;
import com.mediatek.mt2511.views.HRVResultInputDialog;
import com.mediatek.mt2511.views.HeartBeatView;
import com.mediatek.utils.RxBus;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;

/**
 * Created by MTK40526 on 3/28/2016.
 */
public class HRVFragment extends CustomFragment {
  HeartBeatView mHeartBeatView;
  private CompositeSubscription _subscriptions = new CompositeSubscription();
  private HRSaveRequest addHRRequest = new HRSaveRequest();
  private int mLastHR;

  public HRVFragment() {
    super();
    setTitle(MContext.getInstance().getApplication().getString(R.string.hrv_measure));
    setHasOptionsMenu(true);
  }

  @Override public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
    inflater.inflate(R.menu.hrv_measure_menu, menu);
  }

  @Nullable @Override

  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_hrv, container, false);

    initView(view);

    return view;
  }

  private void initView(View view) {
    mHeartBeatView = (HeartBeatView) view.findViewById(R.id.heartView);

    _subscriptions.add(RxBus.getInstance()
        .toObservable(HeartRateData.class)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<HeartRateData>() {
          @Override public void call(HeartRateData heartRateData) {
            int hr = heartRateData.get(HeartRateData.FIELD_BPM);
            mLastHR = hr;
            addHRRequest.result.add(hr);
            if (addHRRequest.result.size() >= 5) {
              requestSaveHR();
            }
          }
        }));
    _subscriptions.add(RxBus.getInstance()
        .toObservable(HRVData.class)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<HRVData>() {
          @Override public void call(HRVData hrvData) {
            final int lastHR = mLastHR;
            final float sdnn = hrvData.get(HRVData.INDEX_SDNN) / 1000f;
            final float lf = hrvData.get(HRVData.INDEX_LF) / 1000f;
            final float hf = hrvData.get(HRVData.INDEX_HF) / 1000f;
            final float lfhf = hrvData.get(HRVData.INDEX_LF_HF) / 1000f;
            if (sdnn < 0) {
              Toast.makeText(getActivity(), R.string.warn_invalid_hrv_result, Toast.LENGTH_LONG).show();
              return;
            }
            HRVRequest hrvRequest = new HRVRequest();
            hrvRequest.HF = hf;
            hrvRequest.LF = lf;
            hrvRequest.SDNN = sdnn;
            hrvRequest.LFHF = lfhf;
            MyProjectApi.getIoTService()
                .saveHRV(hrvRequest)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<String>() {
                  @Override public void onCompleted() {

                  }

                  @Override public void onError(Throwable e) {
                    e.printStackTrace();
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
                  }

                  @Override public void onNext(String s) {

                  }
                });

            new HRVResultInputDialog(getActivity()).show2()
                .subscribe(new Action1<Pair<String, Integer>>() {
                  @Override public void call(Pair<String, Integer> stringIntegerPair) {
                    Intent intent = new Intent(getActivity(), HRVResultActivity.class);
                    intent.putExtra("age", stringIntegerPair.second);
                    intent.putExtra("hr", lastHR);
                    intent.putExtra("lf", lf);
                    intent.putExtra("hf", hf);
                    intent.putExtra("lfhf", lfhf);
                    intent.putExtra("sdnn", sdnn);
                    getActivity().startActivity(intent);
                  }
                });
          }
        }));
  }

  private void stopRecord() {

  }

  @Override public void onStart() {
    super.onStart();
  }

  @Override public void onPause() {
    super.onPause();
  }

  @Override public void onResume() {
    super.onResume();
  }

  @Override public void onDestroy() {
    super.onDestroy();
    _subscriptions.clear();
  }

  @Override public void onDestroyView() {
    super.onDestroyView();
    _subscriptions.clear();
    if (addHRRequest.result.size() > 0) {
      requestSaveHR();
    }
  }

  private void requestSaveHR() {
    MyProjectApi.getIoTService()
        .saveHR(addHRRequest)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            e.printStackTrace();
            Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
          }

          @Override public void onNext(String s) {

          }
        });
    addHRRequest = new HRSaveRequest();
  }
}
