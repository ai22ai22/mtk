package com.mediatek.mt2511.views.validation;

public class RegexValidate extends Validate {
  private final String regex;

  public RegexValidate(String errorMessage, String regex) {
    super(errorMessage);
    this.regex= regex;
  }

  @Override protected boolean isValid(String value) {
    return value.matches(regex);
  }
}
