package com.mediatek.mt2511.network;

import com.mediatek.mt2511.models.pojo.AddFileRequest;
import com.mediatek.mt2511.models.pojo.AddFileReturn;
import com.mediatek.mt2511.models.pojo.HRSaveRequest;
import com.mediatek.mt2511.models.pojo.HRVRequest;
import com.mediatek.mt2511.models.pojo.LoginRequest;
import com.mediatek.mt2511.models.pojo.LoginResponse;
import com.mediatek.mt2511.models.pojo.RecordResult;

import com.mediatek.mt2511.models.pojo.UploadCareRequest;
import retrofit.http.Body;
import retrofit.http.Headers;
import retrofit.http.POST;
import retrofit.http.PUT;
import retrofit.http.Path;
import rx.Observable;

/**
 * Created by MTK40526 on 1/28/2016.
 */
public interface IoTService {
    @POST("/login")
    @Headers({"Cache-Control: no-cache", "Content-Type: application/json"})
    Observable<LoginResponse> login(@Body LoginRequest loginRequest);


    @POST("/records")
    @Headers({"Content-Type: application/json"})
    Observable<RecordResult> createRecord(@Body UploadCareRequest recordRequest);



    @POST("/records/{recordId}/hrv")
    @Headers({"Cache-Control: no-cache", "Content-Type: application/json", "Authorization: hrvhrvgogogo"})
    Observable<String> saveHRV(@Path("recordId") String recordId,@Body HRVRequest hrvRequest);

    @POST("/records/{recordId}/hr")
    @Headers({"Cache-Control: no-cache", "Content-Type: application/json", "Authorization: hrvhrvgogogo"})
    Observable<String> saveHR(@Path("recordId") String recordId,@Body HRSaveRequest hrSaveRequest);


    @PUT("/records/{recordId}")
    @Headers({"Cache-Control: no-cache", "Content-Type: application/json"})
    Observable<AddFileReturn> addFile(@Path("recordId") String recordId,@Body UploadCareRequest recordRequest);
}
