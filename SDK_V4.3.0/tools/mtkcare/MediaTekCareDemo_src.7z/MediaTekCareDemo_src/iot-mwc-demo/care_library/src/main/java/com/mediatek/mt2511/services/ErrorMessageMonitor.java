package com.mediatek.mt2511.services;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;
import com.mediatek.mt2511.MContext;
import com.mediatek.utils.RxBus;
import com.mediatek.iot.data.bt.BTBaseData;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subjects.PublishSubject;
import rx.subscriptions.CompositeSubscription;

public class ErrorMessageMonitor {
  private static final String SP_NAME = "EngineeringMode";
  private static final String SP_FIELD_MODE = "isEngineeringMode";
  private static ErrorMessageMonitor sInstance = null;
  private final SharedPreferences mSp;
  private boolean mEnabled;
  private CompositeSubscription mSubscriptions = new CompositeSubscription();
  private long mLastShowMessageTime;
  private PublishSubject<Boolean> mStatusSubject = PublishSubject.create();

  private ErrorMessageMonitor() {
    mSp =
        MContext.getInstance().getApplication().getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);
    mEnabled = mSp.getBoolean(SP_FIELD_MODE, false);
    setEngMode(mEnabled);
  }

  public static ErrorMessageMonitor getsInstance() {
    if (sInstance == null) {
      sInstance = new ErrorMessageMonitor();
    }
    return sInstance;
  }

  public void toggleEngMode() {
    setEngMode(!mEnabled);
  }

  private void setEngMode(boolean enabled) {
    mEnabled = enabled;
    mSp.edit().putBoolean(SP_FIELD_MODE, enabled).apply();
    mStatusSubject.onNext(enabled);
    if (enabled) {
      mSubscriptions.add(RecordService.getInstance()
          .getRecordingObservable()
          .observeOn(AndroidSchedulers.mainThread())
          .subscribe(new Action1<Boolean>() {
            @Override public void call(Boolean state) {
              mLastShowMessageTime = 0;
            }
          }));
      mSubscriptions.add(RxBus.getInstance()
          .toObservable(BTBaseData.class)
          .observeOn(AndroidSchedulers.mainThread())
          .subscribe(new Action1<BTBaseData>() {
            @Override public void call(BTBaseData btBaseData) {
              int sensorType = btBaseData.get(BTBaseData.INDEX_SENSOR_TYPE);
              switch (sensorType) {
                case BTBaseData.SENSOR_TYPE_HR: {
                  int status = btBaseData.get(4);
                  if (((status & 0xC0000000) >> 30) == -2) {
                    if (((status & 0x20000000) >> 29) == 1) {
                      showMessage(">24ms ppg timestamp difference for 5 times ");
                    }
                    if (((status & 0x10000000) >> 28) == 1) {
                      showMessage(">16ms g-sensor timestamp difference for 5 times ");
                    }
                    if (((status & 0x08000000) >> 27) == 1) {
                      showMessage("Decreased ppg timestamp");
                    }
                    if (((status & 0x04000000) >> 26) == 1) {
                      showMessage("Decreased g-sensor timestamp");
                    }
                    if (((status & 0x02000000) >> 25) == 1) {
                      showMessage("PPG data size is 1.5x than g-sensor ");
                    }
                    if (((status & 0x01000000) >> 24) == 1) {
                      showMessage("G-sensor data size is 1.5x than PPG ");
                    }
                  }
                  break;
                }
                default: {
                  if (sensorType == 0) {
                    int seq = btBaseData.get(BTBaseData.INDEX_SEQUENCE);
                    if (seq == 978) {
                      showMessage("Driver EKG data lost");
                    } else if (seq == 979) {
                      showMessage("Driver PPG1 data lost");
                    } else if (seq == 980) {
                      showMessage("Driver PPG2 data lost");
                    } else if (seq == 981) showMessage("Driver BISI data lost");
                  }
                }
              }
            }
          }));
    } else {
      mSubscriptions.clear();
    }
  }

  private void showMessage(String s) {
    if (System.currentTimeMillis() - mLastShowMessageTime > 60000) {
      RecordService.getInstance().stopSave();
      Toast.makeText(MContext.getInstance().getApplication(), s, Toast.LENGTH_LONG).show();
      mLastShowMessageTime = System.currentTimeMillis();
    }
  }

  public Observable<Boolean> getEngModeObservable() {
    return Observable.create(new Observable.OnSubscribe<Boolean>() {
      @Override public void call(Subscriber<? super Boolean> subscriber) {
        subscriber.onNext(mEnabled);
        mStatusSubject.asObservable().subscribe(subscriber);
      }
    });
  }
}
