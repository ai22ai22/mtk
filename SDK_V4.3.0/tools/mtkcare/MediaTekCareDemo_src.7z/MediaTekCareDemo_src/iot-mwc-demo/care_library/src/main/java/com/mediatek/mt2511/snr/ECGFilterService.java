package com.mediatek.mt2511.snr;

import java.util.ArrayList;

/**
 * Created by MTK40526 on 3/23/2016.
 */
public class ECGFilterService {
  int i4EcgLpfOrder = 128;

  int LpfCoefLength = 128 + 1;

  double f4EcgLpf40HzOrder128Coeff[] = {
      0.001283f, -0.000368f, -0.002026f, -0.003275f, -0.003780f, -0.003371f, -0.002095f, -0.000220f,
      0.001822f, 0.003530f, 0.004458f, 0.004328f, 0.003108f, 0.001038f, -0.001417f, -0.003668f,
      -0.005140f, -0.005419f, -0.004359f, -0.002142f, 0.000751f, 0.003642f, 0.005808f, 0.006661f,
      0.005901f, 0.003612f, 0.000262f, -0.003386f, -0.006439f, -0.008093f, -0.007833f, -0.005585f,
      -0.001761f, 0.002800f, 0.007014f, 0.009800f, 0.010342f, 0.008315f, 0.004008f, -0.001704f,
      -0.007515f, -0.011976f, -0.013834f, -0.012358f, -0.007563f, -0.000289f, 0.007923f, 0.015119f,
      0.019357f, 0.019167f, 0.013956f, 0.004260f, -0.008225f, -0.020863f, -0.030513f, -0.034113f,
      -0.029309f, -0.014982f, 0.008411f, 0.038781f, 0.072652f, 0.105681f, 0.133355f, 0.151748f,
      0.158193f, 0.151748f, 0.133355f, 0.105681f, 0.072652f, 0.038781f, 0.008411f, -0.014982f,
      -0.029309f, -0.034113f, -0.030513f, -0.020863f, -0.008225f, 0.004260f, 0.013956f, 0.019167f,
      0.019357f, 0.015119f, 0.007923f, -0.000289f, -0.007563f, -0.012358f, -0.013834f, -0.011976f,
      -0.007515f, -0.001704f, 0.004008f, 0.008315f, 0.010342f, 0.009800f, 0.007014f, 0.002800f,
      -0.001761f, -0.005585f, -0.007833f, -0.008093f, -0.006439f, -0.003386f, 0.000262f, 0.003612f,
      0.005901f, 0.006661f, 0.005808f, 0.003642f, 0.000751f, -0.002142f, -0.004359f, -0.005419f,
      -0.005140f, -0.003668f, -0.001417f, 0.001038f, 0.003108f, 0.004328f, 0.004458f, 0.003530f,
      0.001822f, -0.000220f, -0.002095f, -0.003371f, -0.003780f, -0.003275f, -0.002026f, -0.000368f,
      0.001283f
  };

  private boolean initialized = false;

  private double f4EcgDc;

  private int i4EcgBufIndex = 0; // should be global variable

  private double[] f4EcgBuf = new double[LpfCoefLength]; // size = LpfCoefLength

  public ECGFilterService() {
    for (int i = 0; i < LpfCoefLength; i++) {
      f4EcgBuf[i] = 0;
    }
  }

   public double filter(double data) {
    if (!initialized) {
      f4EcgDc = data;
      initialized = true;
    }
    double s_hpf = (data - f4EcgDc);
    f4EcgDc += (s_hpf / 32);
    return s_hpf;
  }

  // do Convolution
  public ArrayList<Double> conv(ArrayList<Double> s_hpf) {
    ArrayList<Double> sig_filt = new ArrayList<Double>();
    ArrayList<Double> inputB = new ArrayList<Double>();
    int m = s_hpf.size();
    LpfCoefLength = f4EcgLpf40HzOrder128Coeff.length;
    for (int i = 0; i < LpfCoefLength; i++) {
      inputB.add(f4EcgLpf40HzOrder128Coeff[i]);
    }
    for (int i = LpfCoefLength; i < m + LpfCoefLength - 1; i++) {
      inputB.add(0.0);
    }

    for (int i = 0; i < m + LpfCoefLength - 1; i++) {
      double result = 0.0;
      int tem = i >= m ? m - 1 : i;
      for (int j = 0; j <= tem; j++) {
        result += (s_hpf.get(j) * inputB.get(i - j));
      }
      sig_filt.add(result);
    }
    return sig_filt;
  }
}
