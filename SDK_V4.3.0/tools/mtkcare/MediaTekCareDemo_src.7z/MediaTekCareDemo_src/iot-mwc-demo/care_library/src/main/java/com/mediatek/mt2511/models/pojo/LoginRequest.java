package com.mediatek.mt2511.models.pojo;

/**
 * Created by MTK40526 on 4/25/2016.
 */

public class LoginRequest {

  public String username;
  public String password;
}