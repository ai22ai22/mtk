package com.mediatek.mt2511.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;
import com.mediatek.iot.Device;
import com.mediatek.mt2511.AppConstants;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.custom.BTDeviceFactory;
import com.mediatek.mt2511.fragments.AddRecordDialogFragment;
import com.mediatek.mt2511.fragments.CustomFragment;
import com.mediatek.mt2511.models.BTCommandModel;
import com.mediatek.mt2511.services.RecordService;
import com.mediatek.mt2511.services.UserSession;
import com.mediatek.mt2511.utils.PauseHandler;
import com.mediatek.mt2511.views.NavigationListView;
import java.util.ArrayList;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;
import timber.log.Timber;

public class DataBoardActivity extends AppCompatActivity {
  private static final String TAG = "DataBoardActivity";
  DrawerLayout mDrawerLayout;
  NavigationListView mListLeftDrawer;
  View mLeftDrawer;
  private Device mBTDevice = BTDeviceFactory.getBTDevice();
  private Menu mMenu;
  private ActionBarDrawerToggle mDrawerToggle;
  private CompositeSubscription _subscriptions = new CompositeSubscription();
  private CompositeSubscription mTitleSubscriptions = new CompositeSubscription();
  private ArrayList<CustomFragment> fragments = new ArrayList<>();
  private boolean menuHidden = false;
  private PauseHandler mPauseHandler = new PauseHandler(new PauseHandler.OnHandler() {
    @Override public void onHandle(Observable observable) {
      observable.subscribe(new Subscriber() {
        @Override public void onCompleted() {

        }

        @Override public void onError(Throwable e) {
          Timber.e(e, e.getMessage());
          Toast.makeText(DataBoardActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }

        @Override public void onNext(Object o) {

        }
      });
    }
  });

  @Override protected void onStop() {
    super.onStop();
  }

  @Override protected void onDestroy() {
    super.onDestroy();
    _subscriptions.clear();
    mTitleSubscriptions.clear();
    BTDeviceFactory.getBTDevice().disconnect();
    mBTDevice.disconnect();
    BTCommandModel.getDefault().clear();
  }

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    UserSession.getInstance().clearRecordInfo();
    setContentView(R.layout.activity_data_board);
    initFragments();
    initView();
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); //keep screen on

    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    getSupportActionBar().setHomeButtonEnabled(true);
    iniDrawerLayout();

    _subscriptions.add(BTDeviceFactory.getBTDevice()
        .getStateObservable()
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<Integer>() {
          @Override public void call(Integer state) {
            if (state != Device.STATE_CONNECTED) {
              doFinish();
            }
          }
        }));
    //   Intent intent = new Intent(this, AddRecordActivity.class);
    //    startActivityForResult(intent, AppConstants.REQUEST_ADD_RECORD);
    if (MContext.getInstance().isForceAddRecord()
        && UserSession.getInstance().getRecordInfo() == null) {
      startActivityForResult(new Intent(this, AddRecordActivity.class),
          AppConstants.START_ACTIVITY_FOR_RESULT_ADD_RECORD);
    } else {
      mListLeftDrawer.initFragmentMenu(fragments);
    }
  }

  @Override protected void onPostResume() {
    super.onPostResume();
  }

  private void initFragments() {
    Intent intent = getIntent();
    ArrayList<String> sFragments =
        intent.getExtras().getStringArrayList(AppConstants.INTENT_DATA_FRAGMENT);
    for (String fragmentName : sFragments) {
      try {
        Class<CustomFragment> cls = (Class<CustomFragment>) Class.forName(fragmentName);
        CustomFragment fragment = cls.newInstance();
        fragments.add(fragment);
      } catch (ClassNotFoundException e) {
        e.printStackTrace();
        Timber.e(e, e.getMessage());
      } catch (InstantiationException e) {
        e.printStackTrace();
        Timber.e(e, e.getMessage());
      } catch (IllegalAccessException e) {
        e.printStackTrace();
        Timber.e(e, e.getMessage());
      }
    }
  }

  private void initView() {
    mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
    mListLeftDrawer = (NavigationListView) findViewById(R.id.left_drawer_list);
    mLeftDrawer = findViewById(R.id.left_drawer);
    findViewById(R.id.btn_sign_out).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        doSignOut();
      }
    });
  }

  private void iniDrawerLayout() {
    // set a custom shadow that overlays the main content when the drawer opens
    mDrawerLayout.setDrawerShadow(R.drawable.drawer_shadow, GravityCompat.START);

    mDrawerToggle =
        new ActionBarDrawerToggle(this, mDrawerLayout, R.string.app_name, R.string.app_name) {

          public void onDrawerClosed(View drawerView) {
            super.onDrawerClosed(drawerView);
            hideMenu(false);
          }

          public void onDrawerOpened(View drawerView) {
            super.onDrawerOpened(drawerView);
            hideMenu(true);
          }

          @Override public void onDrawerSlide(View drawerView, float slideOffset) {
            super.onDrawerSlide(drawerView, slideOffset);
            hideMenu(true);
          }
        };
    if (showNavigationDraw()) {
      mDrawerLayout.setDrawerListener(mDrawerToggle);
      mDrawerToggle.syncState();
    }

    _subscriptions.add(
        mListLeftDrawer.getFragmentObservable().subscribe(new Action1<CustomFragment>() {
          @Override public void call(CustomFragment fragment) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.content_frame, fragment).commit();
            mTitleSubscriptions.clear();
            mTitleSubscriptions.add(fragment.getTitleObservable().subscribe(new Action1<String>() {
              @Override public void call(String title) {
                String[] ss = title.split("/");
                getSupportActionBar().setTitle(ss[ss.length - 1]);
              }
            }));
            mDrawerLayout.closeDrawer(mLeftDrawer);
          }
        }));
  }

  private void hideMenu(boolean hidden) {
    if (hidden != this.menuHidden) {
      invalidateOptionsMenu();
    }
    this.menuHidden = hidden;
  }

  @Override public void onBackPressed() {
    if (showNavigationDraw() && mDrawerLayout.isDrawerOpen(mLeftDrawer)) {
      mDrawerLayout.closeDrawer(mLeftDrawer);
    } else {
      doFinish();
    }
  }

  private boolean showNavigationDraw() {
    return fragments.size() > 1;
  }

  private void doFinish() {
    _subscriptions.clear();
    _subscriptions.add(mListLeftDrawer.closeCurrent()
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<String>() {
          @Override public void onCompleted() {
            finish();
          }

          @Override public void onError(Throwable e) {
            Log.e(TAG, e.getMessage(), e);
            Toast.makeText(getApplication(), e.getMessage(), Toast.LENGTH_LONG).show();
          }

          @Override public void onNext(String isValid) {

          }
        }));
  }

  @Override protected void onPause() {
    super.onPause();
    mPauseHandler.pause();
  }

  @Override protected void onResume() {
    super.onResume();
    mPauseHandler.resume();
  }

  @Override public boolean onCreateOptionsMenu(Menu menu) {
    mMenu = menu;
    getMenuInflater().inflate(R.menu.databoard_menu, menu);
    return true;
  }

  @Override public boolean onPrepareOptionsMenu(Menu menu) {
    for (int i = 0; i < menu.size(); ++i) {
      menu.getItem(i).setVisible(!menuHidden);
    }
    return true;
  }

  @Override public boolean onOptionsItemSelected(MenuItem item) {
    int i = item.getItemId();
    if (i == android.R.id.home) {
      if (showNavigationDraw()) {
        if (mDrawerLayout.isDrawerOpen(mLeftDrawer)) {
          mDrawerLayout.closeDrawer(mLeftDrawer);
        } else {
          mDrawerLayout.openDrawer(mLeftDrawer);
        }
      } else {
        onBackPressed();
      }
      return true;
    }
    if (i == R.id.action_add_record) {
      requestAddRecord(null, false);
      return true;
    }
    return false;
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    switch (requestCode) {
      case AppConstants.START_ACTIVITY_FOR_RESULT_ADD_RECORD: {
        if (resultCode == RESULT_CANCELED) {
          finish();
        } else {
          mPauseHandler.processObservable(Observable.create(new Observable.OnSubscribe() {
            @Override public void call(Object o) {
              mListLeftDrawer.initFragmentMenu(fragments);
            }
          }));
        }
      }
    }
  }

  void doSignOut() {
    UserSession.getInstance().reset();
    SharedPreferences sp = getSharedPreferences("LoginInfo", Context.MODE_PRIVATE);
    sp.edit().putString("account", "").putString("password", "").commit();
    MContext.getInstance().backToFrontActivity(this);
  }

  public void requestAddRecord(Fragment fragment, boolean force) {
    if (RecordService.getInstance().isInRecording()) {
      Toast.makeText(this, R.string.warn_in_recording, Toast.LENGTH_LONG).show();
      return;
    }
    AddRecordDialogFragment addRecordDialogFragment = new AddRecordDialogFragment();
    Bundle bundle = new Bundle();
    bundle.putBoolean("force", force);
    addRecordDialogFragment.setArguments(bundle);
    if (fragment != null) {
      addRecordDialogFragment.setTargetFragment(fragment, AppConstants.REQUEST_ADD_RECORD);
    }
    addRecordDialogFragment.show(getSupportFragmentManager(), "Add Record");
  }
}
