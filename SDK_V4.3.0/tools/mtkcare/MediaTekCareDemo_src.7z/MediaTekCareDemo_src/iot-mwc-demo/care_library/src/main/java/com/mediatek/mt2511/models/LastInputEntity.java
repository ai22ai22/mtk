package com.mediatek.mt2511.models;

import android.text.TextUtils;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class LastInputEntity extends RealmObject {
  @PrimaryKey private String id = "id";
  private String userId;
  private Integer birthYear;
  private Integer weight;
  private Integer height;
  private Integer gender = 1;
  private Integer armLength;


  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public Integer getWeight() {
    return weight;
  }

  public void setWeight(Integer weight) {
    this.weight = weight;
  }

  public Integer getHeight() {
    return height;
  }

  public void setHeight(Integer height) {
    this.height = height;
  }

  public Integer getGender() {
    return gender;
  }

  public void setGender(Integer gender) {
    this.gender = gender;
  }

  public Integer getArmLength() {
    return armLength;
  }

  public void setArmLength(Integer armLength) {
    this.armLength = armLength;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }




  public boolean dataIsValid() {
    return !TextUtils.isEmpty(getUserId()) && (getBirthYear() != null && getBirthYear() >= 0) && (
        getWeight() != null
            && getWeight() > 0) && (getHeight() != null && getHeight() > 0) && (getGender() != null
        && getGender() > 0) && (getArmLength() != null && getArmLength() >= 0);
  }

  public Integer getBirthYear() {
    return birthYear;
  }

  public void setBirthYear(Integer birthYear) {
    this.birthYear = birthYear;
  }
}
