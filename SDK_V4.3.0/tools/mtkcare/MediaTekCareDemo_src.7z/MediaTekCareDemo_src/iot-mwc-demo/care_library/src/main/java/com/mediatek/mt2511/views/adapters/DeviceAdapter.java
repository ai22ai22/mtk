package com.mediatek.mt2511.views.adapters;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.mediatek.mt2511.R;

import com.mediatek.iot.BluetoothDeviceInfo;
import java.util.ArrayList;

/**
 * Created by MTK40526 on 1/8/2016.
 */
public class DeviceAdapter extends FragmentStatePagerAdapter {
    private Context mContext;
    private ArrayList<BluetoothDeviceInfo> mDeviceInfoList = new ArrayList<BluetoothDeviceInfo>();


    public DeviceAdapter(FragmentManager fm, Context context) {
        super(fm);
        mContext = context;
    }

    @Override
    public DeviceFragment getItem(int position) {
        DeviceFragment deviceFragment = new DeviceFragment();
        Bundle bundle = new Bundle();
        bundle.putString("mac_address", mDeviceInfoList.get(position).getMacAddress());
        bundle.putString("name", mDeviceInfoList.get(position).getName());
        deviceFragment.setArguments(bundle);
        return deviceFragment;
    }

    @Override
    public int getCount() {
        return mDeviceInfoList.size();
    }

    public void addDevice(BluetoothDeviceInfo device){
        addDevice(mDeviceInfoList.size(), device);
    }


    public void addDevice(int index,BluetoothDeviceInfo device){
        if(!contains(device)){
            mDeviceInfoList.add(index,device);
        }
    }

    public void clear(){
        mDeviceInfoList.clear();
        notifyDataSetChanged();
    }
    private boolean contains(BluetoothDeviceInfo device){
        for(BluetoothDeviceInfo d : mDeviceInfoList){
            if (d.getMacAddress().equals(device.getMacAddress())){
                return true;
            }
        }
        return  false;
    }


    public static class DeviceFragment extends Fragment{


        public DeviceFragment() {

        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            final RelativeLayout layout = (RelativeLayout) inflater.inflate(
                    R.layout.fragment_device_item, container, false);

            final ImageView device = (ImageView) layout.findViewById(R.id.img_watch);
            final TextView deviceText = (TextView) layout.findViewById(R.id.text_watch);

/*            if ((mIndex + 1) % 3 == 0) {
                device.setImageResource(R.drawable.watch_blue);
            } else if ((mIndex + 1) % 3 == 1) {
                device.setImageResource(R.drawable.watch_green);
            } else if ((mIndex + 1) % 3 == 2) {
                device.setImageResource(R.drawable.watch_prink);
            }*/
            device.setImageResource(R.drawable.img_watch_f);
            String mac_address = getArguments().getString("mac_address","");
            String name = getArguments().getString("name","n/a");

            deviceText.setText(name +"\r\n" + mac_address);

            return layout;
        }

    }


}
