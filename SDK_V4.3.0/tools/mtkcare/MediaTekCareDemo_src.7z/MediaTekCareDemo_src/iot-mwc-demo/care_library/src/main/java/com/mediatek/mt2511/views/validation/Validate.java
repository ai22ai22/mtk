package com.mediatek.mt2511.views.validation;

public class Validate {
  public String getErrorMessage() {
    return errorMessage;
  }

  private final String errorMessage;

  public Validate(String errorMessage) {
    this.errorMessage = errorMessage;
  }

  protected boolean isValid(String value) {
    return true;
  }


}