package com.mediatek.mt2511.views.chart;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.utils.MContextCompat;
import lombok.Setter;

public class SleepEfficiencyBar extends View {
  @Setter private Canvas canvas;
  private SleepEfficienciesChartConstant chart_constant = new SleepEfficienciesChartConstant();
  private int bar_color_alpha;
  private int inner_text_color;
  private int inner_text_color_alpha;
  private int date_text_color_alpha;

  public SleepEfficiencyBar(Context context) {
    super(context);
  }

  public void onDraw(Canvas canvas) {
    super.onDraw(canvas);
  }

  public void isHighlighted(boolean isHighlighted) {
    if (isHighlighted) {
      this.bar_color_alpha = 255;
//      this.inner_text_color = ContextCompat.getColor(getContext(), R.color.gs_x_dark_blue);
      this.inner_text_color = MContextCompat.getColor(getContext(), R.color.white);
      this.inner_text_color_alpha = 255;
      this.date_text_color_alpha = 255;
    } else {
      this.bar_color_alpha = 255/2;
      this.inner_text_color = Color.WHITE;
      this.inner_text_color_alpha = 255/2;
      this.date_text_color_alpha = 255/2;
    }
  }

  public void drawSingleBar(float position_x, int percentage, String date) {
    chart_constant.convertUnit(getContext());
    chart_constant.setPx_chart_height(canvas.getHeight()
        - chart_constant.getPx_margin_top()
        - chart_constant.getPx_margin_bottom());
    chart_constant.setPx_chart_width(canvas.getWidth()
        - chart_constant.getPx_margin_left()
        - chart_constant.getPx_margin_right());
    float line_start_y = canvas.getHeight() - chart_constant.getPx_margin_bottom();

    float barHeight = chart_constant.getPx_chart_height() * percentage / 100;
    float bar_top = line_start_y - barHeight;
//    int bar_color = ContextCompat.getColor(getContext(), R.color.gs_purple);
    int bar_color = MContextCompat.getColor(getContext(), R.color.gray_dark);

    Paint paint_bar = new Paint();
    paint_bar.setColor(bar_color);
    paint_bar.setAlpha(bar_color_alpha);

    RectF bar_rect = new RectF(position_x,
        bar_top + chart_constant.getPx_bar_corner_radius(),
        position_x + chart_constant.getPx_bar_width(),
        line_start_y);
    canvas.drawRect(bar_rect, paint_bar);

    RectF bar_top_rect = new RectF(position_x + chart_constant.getPx_bar_corner_radius(),
        bar_top,
        position_x + chart_constant.getPx_bar_width() - chart_constant.getPx_bar_corner_radius(),
        bar_top + chart_constant.getPx_bar_corner_radius());
    canvas.drawRect(bar_top_rect, paint_bar);

    RectF bar_top_left_arc = new RectF(position_x,
        bar_top,
        position_x + chart_constant.getPx_bar_corner_radius() * 2,
        bar_top + chart_constant.getPx_bar_corner_radius() * 2);
    canvas.drawArc(bar_top_left_arc, -180, 90, true, paint_bar);

    RectF bar_top_right_arc = new RectF(
        position_x + chart_constant.getPx_bar_width()
            - chart_constant.getPx_bar_corner_radius() * 2,
        bar_top,
        position_x + chart_constant.getPx_bar_width(),
        bar_top + chart_constant.getPx_bar_corner_radius() * 2);
    canvas.drawArc(bar_top_right_arc, -90, 90, true, paint_bar);

    drawInnerPercentage(position_x, bar_top, String.valueOf(percentage));
    drawBottomDate(position_x, line_start_y, date);
  }

  private void drawInnerPercentage(float position_x, float position_y, String percentage) {
    Paint paint_text = new Paint();
    paint_text.setColor(inner_text_color);
    paint_text.setAlpha(inner_text_color_alpha);
    paint_text.setTextSize(chart_constant.getPx_text_size());

    drawText(percentage, paint_text, position_x, position_y);
  }

  private void drawBottomDate(float position_x, float position_y, String date) {
    Paint paint_text = new Paint();
    paint_text.setColor(Color.WHITE);
    paint_text.setAlpha(date_text_color_alpha);
    paint_text.setTextSize(chart_constant.getPx_text_size());

    drawText(date, paint_text, position_x, position_y);
  }

  private void drawText(String text, Paint paint, float posX, float posY) {
    Rect textBounds = new Rect();
    paint.setAntiAlias(true);
    paint.getTextBounds(text, 0, text.length(), textBounds);
    float textHeight = textBounds.height();
    float textWidth  = textBounds.right - textBounds.left;
    float textX = posX
        + chart_constant.getPx_bar_width() / 2
        - textWidth / 2;
    float textY = posY
        + chart_constant.getPx_date_margin_top()
        + textHeight * 3 / 2;
    canvas.drawText(text, textX, textY, paint);
  }
}
