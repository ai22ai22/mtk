package com.mediatek.mt2511.presentation;

import com.mediatek.mt2511.views.InputGoldenDialog;

public class InputGoldenPresenter implements Presenter<InputGoldenDialog> {
  @Override public void setView(InputGoldenDialog view) {

  }
}
