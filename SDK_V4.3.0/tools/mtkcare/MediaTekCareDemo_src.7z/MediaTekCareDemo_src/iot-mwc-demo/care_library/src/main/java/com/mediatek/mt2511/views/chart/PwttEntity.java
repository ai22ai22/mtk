package com.mediatek.mt2511.views.chart;

import com.google.gson.Gson;
import com.mediatek.mt2511.models.entity.ApiResponseEntity;
import java.util.List;

public class PwttEntity extends ApiResponseEntity {

  private Data data;

  public Data getData() {
    return data;
  }

  public PwttEntity fromJson(String json) {
    Gson gson = new Gson();
    ApiResponseEntity response = gson.fromJson(json, ApiResponseEntity.class);
    String resultsJson = gson.toJson(response.getResults());
    return gson.fromJson(resultsJson, PwttEntity.class);
  }

  public String toJson() {
    return new Gson().toJson(this);
  }

  public static class Data {
    List<String> xdata;
    List<Integer> ydata;

    public List<String> getXdata() {
      return xdata;
    }

    public List<Integer> getYdata() {
      return ydata;
    }
  }
}
