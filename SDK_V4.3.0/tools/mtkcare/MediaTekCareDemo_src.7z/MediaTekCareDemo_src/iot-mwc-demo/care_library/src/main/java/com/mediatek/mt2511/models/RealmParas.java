package com.mediatek.mt2511.models;

import io.realm.RealmList;
import io.realm.RealmObject;

public class RealmParas extends RealmObject {
  private RealmList<RealmInteger> values = new RealmList<>();

  public RealmList<RealmInteger> getValues() {
    return values;
  }

  public void setValues(RealmList<RealmInteger> values) {
    this.values = values;
  }
}
