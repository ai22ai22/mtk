package com.mediatek.mt2511.views.widgets;

import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v4.content.res.ResourcesCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.SleepReport;
import com.mediatek.mt2511.utils.MContextCompat;

public class ReportsItemDesc extends LinearLayout {

  TextView tv_status;
  TextView tv_asleep_date;
  TextView tv_asleep_time;
  TextView tv_duration;
  private SleepReport report;

  public ReportsItemDesc(Context context, AttributeSet attributeSet) {
    super(context, attributeSet);
    LayoutInflater.from(context).inflate(R.layout.report_status_desc, this, true);
    initView();
  }

  private void initView() {
    tv_status = (TextView) findViewById(R.id.tv_status);
    tv_asleep_date = (TextView) findViewById(R.id.tv_asleep_date);
    tv_asleep_time = (TextView) findViewById(R.id.tv_asleep_time);
    tv_duration = (TextView) findViewById(R.id.tv_duration);
  }

  public void setSleepReport(SleepReport report) {
    this.report = report;
    updateUi();
  }

  private void updateUi() {
    tv_status.setText(report.getStatusText());
    tv_asleep_date.setText(report.getAsleepDate());
    tv_asleep_time.setText(report.getAsleepTime());
    tv_duration.setText(report.getDuration());
    Drawable bg_status = ResourcesCompat.getDrawable(getResources(), R.drawable.status_label, null);
    bg_status.setColorFilter(MContextCompat.getColor(getContext(), report.getStatusColor()),
        PorterDuff.Mode.SRC_ATOP);
    tv_status.setBackground(bg_status);
  }
}
