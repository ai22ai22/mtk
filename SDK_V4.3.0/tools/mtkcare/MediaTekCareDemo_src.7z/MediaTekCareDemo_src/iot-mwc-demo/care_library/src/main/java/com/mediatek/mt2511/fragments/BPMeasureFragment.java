package com.mediatek.mt2511.fragments;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.mediatek.iot.Device;
import com.mediatek.iot.data.bt.BTBaseData;
import com.mediatek.iot.data.bt.BloodPressureData;
import com.mediatek.iot.data.bt.EKGData;
import com.mediatek.iot.data.bt.PPG1Data;
import com.mediatek.iot.data.bt.PPG1_512Data;
import com.mediatek.iot.data.bt.PWTTData;
import com.mediatek.iot.utils.DataConverter;
import com.mediatek.mt2511.AppConstants;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.activities.BPMeasureResultActivity;
import com.mediatek.mt2511.activities.DataBoardActivity;
import com.mediatek.mt2511.custom.BTDeviceFactory;
import com.mediatek.mt2511.interfaces.ShowProfile;
import com.mediatek.mt2511.presentation.BPMeasurePresenter;
import com.mediatek.mt2511.services.RecordService;
import com.mediatek.mt2511.snr.ECGFilterService;
import com.mediatek.mt2511.snr.PPGFilterService;
import com.mediatek.mt2511.snr.SNRResult;
import com.mediatek.utils.RxBus;
import java.util.ArrayList;
import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.schedulers.Schedulers;
import rx.subscriptions.CompositeSubscription;
import timber.log.Timber;

/**
 * Created by MTK40526 on 6/2/2016.
 */
public class BPMeasureFragment extends CustomFragment implements ShowProfile{
  protected BPMeasurePresenter presenter;
  private CompositeSubscription _subscriptions = new CompositeSubscription();
  private CompositeSubscription mSNRSubscriptions = new CompositeSubscription();
  private Device mBTDevice = BTDeviceFactory.getBTDevice();
  private CompositeSubscription _writeLogSubscriptions = new CompositeSubscription();
  private Subscription mSubscription;
  private DataPool<Integer> dataPool = null;
  private SNRResult mPPGSNR;
  private SNRResult mECGSNR;
  private PPGFilterService mPPGFilterService;
  private ECGFilterService mECGFilterService;
  private ProgressDialog mProgressDialog;
  private TextView mTxtProfile;

  public BPMeasureFragment() {
    super();
    setTitle(MContext.getInstance().getApplication().getString(R.string.bp_measure));
    presenter = new BPMeasurePresenter();
    presenter.setView(this);
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_bp_measure, container, false);

    initView(view);
    return view;
  }

  private void initView(View view) {
    mTxtProfile = (TextView) view.findViewById(R.id.txt_profile_user_id);
    _subscriptions.add(RxBus.getInstance()
        .toObservable(PWTTData.class)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<PWTTData>() {
          @Override public void call(PWTTData pwttData) {
            if (dataPool == null) {
              int size = pwttData.get(BTBaseData.INDEX_STATUS);
              dataPool = new DataPool<Integer>(size);
            }
            int[] rawData = pwttData.getRawData();
            for (int i = 6; i < 16 && i < rawData.length; ++i) {
              int value = rawData[i];
              if (value == 12345) {
                break;
              }
              dataPool.addData(value);
            }
          }
        }));

    _subscriptions.add(RxBus.getInstance()
        .toObservable(BloodPressureData.class)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<BloodPressureData>() {
          @Override public void call(BloodPressureData bloodPressureData) {
            showBPMeasureResult(bloodPressureData.getRawData());
          }
        }));

    _subscriptions.add(RecordService.getInstance()
        .getRecordingObservable()
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<Boolean>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
            Log.e("BloodPressure", e.getMessage(), e);
          }

          @Override public void onNext(Boolean inRecording) {
            if (!inRecording) {
              stopRecord();
            } else {
              startRecord();
            }
          }
        }));

    _subscriptions.add(RecordService.getInstance()
        .getRecordingObservable()
        .skip(1)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<Boolean>() {
          @Override public void call(Boolean recording) {
            if (recording) {
              startCalcSNR();
            } else {
              showSNR();
            }
          }
        }));
  }

  private void startCalcSNR() {
    mSNRSubscriptions.clear();
    mPPGSNR = new SNRResult();
    mECGSNR = new SNRResult();
    mPPGFilterService = new PPGFilterService();
    mECGFilterService = new ECGFilterService();
    mSNRSubscriptions.add(
        RxBus.getInstance().toObservable(BTBaseData.class).filter(new Func1<BTBaseData, Boolean>() {
          @Override public Boolean call(BTBaseData btBaseData) {
            if (btBaseData instanceof PPG1_512Data || btBaseData instanceof PPG1Data) {
              return true;
            } else {
              return false;
            }
          }
        }).subscribe(new Action1<BTBaseData>() {
          private int mIndex = 0;

          @Override public void call(BTBaseData btBaseData) {
            for (int i = 3; i <= 14; ++i) {
              // only use data_ppg_512(512*5, end)
              if ((mIndex++) < (512 * 5)) {
                continue;
              }
              int data_ppg_512 = btBaseData.get(i);
              double data_ppg_512_mv = DataConverter.ppg1ConvertToMv(data_ppg_512);
              // HPF
              double s_hpf = mPPGFilterService.filter(data_ppg_512_mv);
              mPPGSNR.inputHPFSignal(s_hpf);
            }
          }
        }));
    mSNRSubscriptions.add(
        RxBus.getInstance().toObservable(EKGData.class).subscribe(new Action1<EKGData>() {

          private int mIndex = 0;

          private void receiveECG(int value) {
          }

          @Override public void call(EKGData ecgData) {
            for (int i = 3; i <= 14; ++i) {
              // only use data_ppg_512(512*5, end)
              if ((mIndex++) < (512 * 5)) {
                continue;
              }
              int data_ecg_512 = ecgData.get(i);
              double data_ecg_512_mv = DataConverter.ecgConvertToMv(data_ecg_512);
              // HPF
              double s_hpf = mECGFilterService.filter(data_ecg_512_mv);
              mECGSNR.inputHPFSignal(s_hpf);
            }
          }
        }));
  }

  private void showSNR() {
    mSNRSubscriptions.clear();
    final ProgressDialog progressDialog =
        ProgressDialog.show(getActivity(), getString(R.string.snr_result),
            getString(R.string.waiting_a_moment), false);
    _subscriptions.add(Observable.create(new Observable.OnSubscribe<Object>() {
      @Override public void call(Subscriber<? super Object> subscriber) {
        ArrayList<Double> hpfSignalList = mPPGSNR.getHPFSignal();
        ArrayList<Double> allLPFSingalList = mPPGFilterService.conv(hpfSignalList);
        mPPGSNR.computePPG512SNR10(allLPFSingalList);

        hpfSignalList = mECGSNR.getHPFSignal();
        allLPFSingalList = mECGFilterService.conv(hpfSignalList);
        mECGSNR.computeECG512SNR40(allLPFSingalList);
        subscriber.onCompleted();
      }
    })
        .subscribeOn(Schedulers.computation())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<Object>() {
          @Override public void onCompleted() {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setTitle(R.string.snr_result)
                .setMessage(
                    String.format("PPG 512 SNR10: %f\nECG 512 SNR40: %f", mPPGSNR.getPPG512SNR10(),
                        mECGSNR.getEKG512SNR40()))
                .setPositiveButton(R.string.btn_ok, null);
            builder.create().show();
            progressDialog.dismiss();
          }

          @Override public void onError(Throwable e) {
            progressDialog.dismiss();
          }

          @Override public void onNext(Object o) {

          }
        }));
  }

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setHasOptionsMenu(true);
  }

  private void showBPMeasureResult(int[] ints) {
    if (ints.length >= 6) {
      int sbp = ints[3];
      int dbp = ints[4];
      int hr = ints[5];

      if (dataPool == null) {
        dataPool = new DataPool<>(0);
      }
      Timber.i("pwtt declare size:%d, actual:%d", dataPool.size, dataPool.dataList.size());
      Intent intent = new Intent(getActivity(), BPMeasureResultActivity.class);
      intent.putIntegerArrayListExtra(AppConstants.BP_DATA_PWTT_LIST, dataPool.dataList);
      dataPool = null;

      intent.putExtra(AppConstants.BP_DATA_SBP, sbp);
      intent.putExtra(AppConstants.BP_DATA_DBP, dbp);
      intent.putExtra(AppConstants.BP_DATA_HR, hr);
      getActivity().startActivity(intent);
    }
  }



  @Override public boolean onOptionsItemSelected(MenuItem item) {
    int i = item.getItemId();
    if (i == R.id.action_add_note) {
      doAddNote();
    }
    return true;
  }

  private void doAddNote() {
    FragmentManager fm = getActivity().getSupportFragmentManager();
    AddNoteDialogFragment addNoteDialogFragment = new AddNoteDialogFragment();
    addNoteDialogFragment.setCancelable(false);
    addNoteDialogFragment.show(fm, "fragment_edit_name");
  }

  @Override public void onDestroy() {
    super.onDestroy();
    _subscriptions.clear();
    mSNRSubscriptions.clear();
    stopRecord();
  }

  private void stopRecord() {
/*        mLog.debug("stopRecord");*/
    _writeLogSubscriptions.clear();
  }

  private void startRecord() {
  }

  @Override public void onStart() {
    super.onStart();
  }

  public void showAddRecord(boolean force) {
    ((DataBoardActivity) getActivity()).requestAddRecord(this, force);
  }

  public void showProgressLoading() {
    mProgressDialog = ProgressDialog.show(getActivity(), getString(R.string.loading),
        getString(R.string.waiting_a_moment), false);
  }

  public void dismissProgressLoading(Throwable e) {
    if (e != null) {
      Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
    }
    if (mProgressDialog != null) {
      mProgressDialog.dismiss();
      mProgressDialog = null;
    }
  }

  public void setCurrentProfileComplete(String userId) {
    mTxtProfile.setVisibility(View.VISIBLE);
    mTxtProfile.setText(userId);
  }

  private class DataPool<T> {
    private final int size;
    private ArrayList<T> dataList = new ArrayList<>();

    public DataPool(int size) {
      this.size = size;
    }

    public void addData(T data) {
      if (size > dataList.size()) {
        dataList.add(data);
      }
    }

    public boolean isFull() {
      return size == dataList.size();
    }
  }
}
