package com.mediatek.mt2511.custom;

import android.bluetooth.BluetoothAdapter;
import android.widget.Toast;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.bluetooth.data.ATCommand;
import com.mediatek.mt2511.exceptions.ATCommandException;
import com.mediatek.mt2511.framework.bt.RxBtDevice;
import com.mediatek.mt2511.utils.CHexConver;
import java.util.UUID;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.functions.Func2;
import timber.log.Timber;

public class CustomUtils {
  public static Observable<Boolean> sendATCommand(final ATCommand atCommand) {
    //for debug
        /*                final RxBtDevice rxBtDevice = new RxBtDevice(
            BluetoothAdapter.getDefaultAdapter().getRemoteDevice("74:04:2B:4F:2C:32"),
                    UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));*/
    return Observable.create(new Observable.OnSubscribe<Boolean>() {
      @Override public void call(final Subscriber<? super Boolean> subscriber) {
        final RxBtDevice rxBtDevice = RxBtDevice.getInstance(BluetoothAdapter.getDefaultAdapter()
            .getRemoteDevice(BTDeviceFactory.getBTDevice().getAddress()),
            UUID.fromString("00001101-0000-1000-8000-00805F9B345B"));

        Observable userId = sendCommandAndComfirm(rxBtDevice, "userid", atCommand.getUserId());
        Observable height =
            sendCommandAndComfirm(rxBtDevice, "height", String.valueOf(atCommand.getHeight()));
        Observable weight =
            sendCommandAndComfirm(rxBtDevice, "weight", String.valueOf(atCommand.getWeight()));
        Observable gender =
            sendCommandAndComfirm(rxBtDevice, "gender", String.valueOf(atCommand.getGender()));
        Observable age =
            sendCommandAndComfirm(rxBtDevice, "age", String.valueOf(atCommand.getAge()));
        Observable handlen =
            sendCommandAndComfirm(rxBtDevice, "handlen", String.valueOf(atCommand.getHandLen()));

        Observable writeMode =
            sendCommandAndComfirm(rxBtDevice, "mode", "0");

        Observable.concat(userId, height, weight, gender, age, handlen,writeMode)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(new Subscriber<Object>() {
              @Override public void onCompleted() {
                subscriber.onCompleted();
                rxBtDevice.disconnect();
                Toast.makeText(MContext.getInstance().getApplication(),
                    R.string.at_command_completed, Toast.LENGTH_SHORT).show();
              }

              @Override public void onError(Throwable e) {
                subscriber.onError(e);
                rxBtDevice.disconnect();
              }

              @Override public void onNext(Object object) {
              }
            });
      }
    });
  }

  private static byte[] str2CommandBytes(String fieldName, String value) {
    final String format = "AT+ENVDM=1,2511,%s,%d,%s\r\n";
    return String.format(format, fieldName, value.length(), CHexConver.str2HexStr(value))
        .getBytes();
  }

  private static Observable sendCommandAndComfirm(RxBtDevice rxBtDevice, String fileName,
      String value) {
    return Observable.concat(sendCommand(rxBtDevice, fileName, value),
        readCommand(rxBtDevice, fileName, value)).retry(new Func2<Integer, Throwable, Boolean>() {
      @Override public Boolean call(Integer retryCount, Throwable throwable) {
        if(retryCount < 2 && throwable instanceof ATCommandException){
          return true;
        }
        return false;
      }
    });
  }

  private static Observable sendCommand(RxBtDevice rxBtDevice, String fieldName, String value) {
    final String format = "AT+ENVDM=1,2511,%s,%d,%s\r\n";
    String strCommand =  String.format(format, fieldName, value.length(), CHexConver.str2HexStr(value));
    Timber.d("ATCommand %s -->", strCommand);
    byte[] command =
        strCommand.getBytes();
    return rxBtDevice.writeCommand(command).flatMap(new Func1<byte[], Observable<?>>() {
      @Override public Observable<?> call(byte[] bytes) {
        String result = new String(bytes);
        Timber.d("ATCommand %s <--", result);
        if (!result.endsWith("OK\r\n")) {
          return Observable.error(new ATCommandException("Sync data error"));
        } else {
          return Observable.just(true);
        }
      }
    });
  }

  private static Observable readCommand(RxBtDevice rxBtDevice, String fieldName,
      final String value) {
    final String format = "AT+ENVDM=0,2511,%s\r\n";
    String strCommand = String.format(format, fieldName, value.length(), CHexConver.str2HexStr(value));
    Timber.d("ATCommand %s -->", strCommand);
    byte[] command =
        strCommand.getBytes();
    return rxBtDevice.writeCommand(command).flatMap(new Func1<byte[], Observable<?>>() {
      @Override public Observable<?> call(byte[] bytes) {
        String result = new String(bytes).trim();
        Timber.d("ATCommand %s <--", result);
        if (!result.equals(value + "OK")) {
          return Observable.error(
              new ATCommandException(String.format("double confirm fail %s != %s", result, value)));
        } else {
          return Observable.just(true);
        }
      }
    });
  }
}
