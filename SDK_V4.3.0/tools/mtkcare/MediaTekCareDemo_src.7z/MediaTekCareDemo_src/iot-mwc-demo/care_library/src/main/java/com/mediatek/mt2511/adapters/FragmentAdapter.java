package com.mediatek.mt2511.adapters;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import com.mediatek.mt2511.fragments.CustomFragment;
import java.util.List;

public class FragmentAdapter extends ArrayAdapter<CustomFragment> {
  public FragmentAdapter(Context context, int resource, List<CustomFragment> objects) {
    super(context, resource, objects);
  }

  @Override public View getView(int position, View convertView, ViewGroup parent) {
    View view =super.getView(position, convertView, parent);
    CustomFragment fragment  = getItem(position);
    return view;
  }
}
