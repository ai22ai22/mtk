package com.mediatek.mt2511.services;

import android.content.Context;
import android.widget.Toast;
import com.mediatek.iot.Device;
import com.mediatek.iot.data.bt.BTBaseData;
import com.mediatek.mt2511.AppConstants;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.custom.BTDeviceFactory;
import com.mediatek.mt2511.events.DataLostEvent;
import com.mediatek.mt2511.exceptions.AbortException;
import com.mediatek.mt2511.utils.DatatypeConverter;
import com.mediatek.mt2511.utils.RxUtils;
import com.mediatek.utils.RxBus;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;
import rx.subjects.PublishSubject;
import rx.subscriptions.CompositeSubscription;

public class RecordService {
  private static RecordService sInstance;
  private final String mLogPath;
  private final String mLogPath_Temp;
  private boolean inRecording;
  private PublishSubject<Boolean> mRecordingSubject;
  private CompositeSubscription mSubscriptions = new CompositeSubscription();

  private File mTempFile;
  private FileWriter mFileWriter;
  private File currentFile;
  private long startTimeStamp;
  private HashMap<Integer, Integer> mLastSequences;

  private RecordService() {
    this.mLogPath = MContext.getInstance().getLogPath();
    this.mLogPath_Temp = mLogPath + "_Temp";
  }

  public static RecordService getInstance() {
    if (sInstance == null) {
      sInstance = new RecordService();
    }
    return sInstance;
  }

  public long getStartTimeStamp() {
    return startTimeStamp;
  }

  public synchronized File getCurrentFile() {
    return currentFile;
  }

  public void init() {
    mSubscriptions.clear();
    mRecordingSubject = PublishSubject.create();
    mTempFile = null;
    if (mFileWriter != null) {
      try {
        mFileWriter.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }

  public synchronized void startRecord() throws IOException {
    if (inRecording) {
      return;
    }
    mLastSequences = new HashMap<>();
    this.startTimeStamp = System.currentTimeMillis();
    final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
    String fileName = mLogPath_Temp + "/" + dateFormat.format(System.currentTimeMillis());
    fileName = fileName.replace(".", "_").replace(":", "-");
    if (UserSession.getInstance().getRecordInfo() != null
        && UserSession.getInstance().getRecordInfo().userId != null) {
      fileName += "_" + UserSession.getInstance().getRecordInfo().userId;
    }
    fileName += ".txt";
    mTempFile = new File(fileName);
    mTempFile.getParentFile().mkdirs();
    mTempFile.createNewFile();
    mFileWriter = new FileWriter(mTempFile, true);

    currentFile = mTempFile;
    mSubscriptions.add(RxBus.getInstance()
        .toObservable(BTBaseData.class)
        .observeOn(Schedulers.io())
        .subscribe(new Action1<BTBaseData>() {
          @Override public void call(BTBaseData btBaseData) {
            synchronized (RecordService.this) {
              try {
                checkSequence(btBaseData);

                if (btBaseData.get(BTBaseData.INDEX_MAGIC) != AppConstants.SENSOR_SPP_DATA_MAGIC) {
                  write("data lost(discard):" + DatatypeConverter.intArrayToString(
                      btBaseData.getRawData(), 0));
                } else {
                  write(DatatypeConverter.intArrayToString(btBaseData.getRawData(), 1));
                }
                write("," + String.valueOf(System.currentTimeMillis() / 1000L) + "\r\n");
              } catch (IOException e) {
                e.printStackTrace();
                stopRecord();
                mRecordingSubject.onError(e);
              }
            }
          }
        }));
    mSubscriptions.add(
        BTDeviceFactory.getBTDevice().getStateObservable().subscribe(new Action1<Integer>() {
          @Override public void call(Integer state) {
            if (state != Device.STATE_CONNECTED) {
              stopRecord();
            }
          }
        }));

    mSubscriptions.add(RxBus.getInstance()
        .toObservable(DataLostEvent.class)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<DataLostEvent>() {
          @Override public void call(DataLostEvent dataLostEvent) {
            Toast.makeText(MContext.getInstance().getApplication(), dataLostEvent.getMessage(),
                Toast.LENGTH_LONG).show();
          }
        }));
    setState(true);
  }

  private synchronized void checkSequence(BTBaseData btBaseData) {
    if (mLastSequences == null) return;
    int thisSeq = btBaseData.get(BTBaseData.INDEX_SEQUENCE);
    int thisType = btBaseData.get(BTBaseData.INDEX_SENSOR_TYPE);
    Integer lastSeq = mLastSequences.get(thisType);
    switch (thisType) {
      case 0:
      case 5:
      case 9:
      case 11:
      case 12: {
        if (lastSeq != null && lastSeq + 1 != thisSeq) {
          String msg =
              String.format("data lost(discard): type:%d; [%d ,%d],%d \r\n", thisType, lastSeq + 1,
                  thisSeq - 1, System.currentTimeMillis() / 1000L);
          RxBus.getInstance().post(new DataLostEvent(msg));
          try {
            write(msg);
          } catch (IOException e) {
            e.printStackTrace();
          }
        }
        break;
      }
    }
    mLastSequences.put(thisType, thisSeq);
  }

  public synchronized void write(String text) throws IOException {
    if (inRecording) {
      mFileWriter.write(text);
      mFileWriter.flush();
    } else {
      throw new IOException("recording is stopped");
    }
  }

  public synchronized void stopRecord() {
    if (inRecording) {
      try {
        mFileWriter.flush();
        mFileWriter.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
      mSubscriptions.clear();
      mLastSequences = null;
      setState(false);
    }
  }

  private synchronized void save() {
    if (mTempFile != null && mTempFile.exists()) {
      File toFile = new File(mLogPath + "/" + mTempFile.getName());
      toFile.getParentFile().mkdirs();
      mTempFile.renameTo(toFile);
      mTempFile = null;
      currentFile = null;
    }
  }

  public synchronized void stopSave() {
    if (isInRecording()) {
      stopRecord();
    }
    if (isInTemp()) {
      save();
    }
  }

  private synchronized void setState(boolean state) {
    this.inRecording = state;
    mRecordingSubject.onNext(inRecording);
  }

  public synchronized boolean isInTemp() {
    return mTempFile != null;
  }

  public synchronized boolean isInRecording() {
    return inRecording;
  }

  public Observable<Boolean> getRecordingObservable() {
    return Observable.create(new Observable.OnSubscribe<Boolean>() {
      @Override public void call(Subscriber<? super Boolean> subscriber) {
        subscriber.onNext(inRecording);
        mRecordingSubject.asObservable().subscribe(subscriber);
      }
    });
  }

  public synchronized void drop() {
    mTempFile = null;
  }

  public Observable<String> confirmSave(Context context) {
    Observable<Boolean> confirmObservable =
        RxUtils.alertDialog(context, context.getString(R.string.confirm),
            context.getString(R.string.confirm_to_save_record), context.getString(R.string.save));
    return confirmSave(confirmObservable);
  }

  public Observable<String> confirmSave(final Observable<Boolean> confirmObservable) {
    if (isInRecording()) {
      stopRecord();
    }
    return Observable.create(new Observable.OnSubscribe<String>() {
      @Override public void call(final Subscriber<? super String> subscriber) {
        if (isInTemp()) {
          confirmObservable.subscribe(new Subscriber<Boolean>() {
            @Override public void onCompleted() {
              subscriber.onCompleted();
            }

            @Override public void onError(Throwable e) {
              subscriber.onError(e);
            }

            @Override public void onNext(Boolean isOK) {
              if (isOK) {
                save();
                subscriber.onNext("");
              } else {
                drop();
                subscriber.onError(new AbortException("User cancelled"));
              }
            }
          });
        } else {
          Observable.just("").subscribe(subscriber);
        }
      }
    });
  }
}
