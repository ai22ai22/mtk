package com.mediatek.mt2511.models.pojo;

import java.util.ArrayList;

public class AddFileRequest {
  public ArrayList<String> fileList = new ArrayList<>();
}
