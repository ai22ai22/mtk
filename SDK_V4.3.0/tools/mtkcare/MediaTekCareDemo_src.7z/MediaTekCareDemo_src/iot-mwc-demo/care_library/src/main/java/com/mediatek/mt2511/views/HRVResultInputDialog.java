package com.mediatek.mt2511.views;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.InputFilter;
import android.text.TextUtils;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.services.UserSession;
import rx.Observable;
import rx.Subscriber;

public class HRVResultInputDialog extends AlertDialog {

  Button btnStart;

  EditText edtUserName;

  EditText edtUserAge;

  View mBtnClose;

  public HRVResultInputDialog(Context context) {
    super(context);
    // TODO Auto-generated constructor stub
    LayoutInflater inflater =
        (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    View view = inflater.inflate(R.layout.dialog_hrv_request, null);
    initView(view);

    edtUserAge.setFilters(new InputFilter[] { new InputFilterMinMax("1", "122") });
    setView(view);
  }

  private void initView(View view) {

    btnStart = (Button) view.findViewById(R.id.btn_start);

    edtUserName = (EditText) view.findViewById(R.id.edt_user_name);

    edtUserAge = (EditText) view.findViewById(R.id.edt_user_age);

    mBtnClose = view.findViewById(R.id.record_cancel_btn);
  }

  @Override public void show() {
    // TODO Auto-generated method stub
    super.show();
    this.getWindow()
        .clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
    this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
  }

  public Observable<Pair<String, Integer>> show2() {
    return Observable.create(new Observable.OnSubscribe<Pair<String, Integer>>() {
      @Override public void call(final Subscriber<? super Pair<String, Integer>> subscriber) {
        if (UserSession.getInstance().getRecordInfo() != null
            && UserSession.getInstance().getRecordInfo().userId != null) {
          subscriber.onNext(
              new Pair<String, Integer>(UserSession.getInstance().getRecordInfo().userId,
                  UserSession.getInstance().getRecordInfo().age));
          subscriber.onCompleted();
        } else {
          HRVResultInputDialog.this.show();
          HRVResultInputDialog.this.setOnCancelListener(new OnCancelListener() {
            @Override public void onCancel(DialogInterface dialog) {
              subscriber.onCompleted();
            }
          });

          mBtnClose.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
              HRVResultInputDialog.this.dismiss();
              subscriber.onCompleted();
            }
          });
          btnStart.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
              if (!TextUtils.isEmpty(edtUserName.getText()) && !TextUtils.isEmpty(
                  edtUserAge.getText())) {
                Pair<String, Integer> pair =
                    new Pair<String, Integer>(edtUserName.getText().toString(),
                        Integer.parseInt(edtUserAge.getText().toString()));
                subscriber.onNext(pair);
                HRVResultInputDialog.this.dismiss();
              }
            }
          });
        }
      }
    });
  }
}
