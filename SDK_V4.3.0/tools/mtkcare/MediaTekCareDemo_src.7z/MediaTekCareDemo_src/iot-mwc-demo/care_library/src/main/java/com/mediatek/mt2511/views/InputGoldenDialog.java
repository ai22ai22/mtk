package com.mediatek.mt2511.views;

import android.app.Activity;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.internal.view.ContextThemeWrapper;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.exceptions.AbortException;
import com.mediatek.mt2511.models.Golden;
import com.mediatek.mt2511.presentation.InputGoldenPresenter;
import com.mediatek.mt2511.utils.UIUtils;
import com.mediatek.mt2511.views.validation.CompositeValidation;
import com.mediatek.mt2511.views.validation.NumberValidate;
import com.mediatek.mt2511.views.validation.RequiredValidate;
import com.mediatek.mt2511.views.validation.ValidateEvent;
import com.mediatek.mt2511.views.validation.ViewValidation;
import com.mediatek.utils.RxBus;
import rx.Observable;
import rx.Subscriber;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;

public class InputGoldenDialog {
  private final Activity activity;
  private final InputGoldenPresenter presenter;
  private AlertDialog mDialog;
  private EditText mEdtSystolic;
  private EditText mEdtDiastolic;
  private View mButton1;
  private int step;
  private CompositeSubscription mSubscriptions = new CompositeSubscription();
  private CompositeValidation mFormValidation = new CompositeValidation();

  public InputGoldenDialog(Activity activity, InputGoldenPresenter goldenPresenter, int step) {
    this.activity = activity;
    this.presenter = goldenPresenter;
    goldenPresenter.setView(this);
    this.step = step;
  }

  public Observable<Golden> show() {
    return Observable.create(new Observable.OnSubscribe<Golden>() {
      @Override public void call(final Subscriber<? super Golden> subscriber) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        View dialogView = View.inflate(new ContextThemeWrapper(activity, R.style.MAlertDialog),
            R.layout.dialog_layout_golden, null);
        mEdtSystolic = (EditText) dialogView.findViewById(R.id.edt_systolic);
        mEdtDiastolic = (EditText) dialogView.findViewById(R.id.edt_diastolic);
        UIUtils.setFormEdit(mEdtSystolic, "");
        UIUtils.setFormEdit(mEdtDiastolic, "");
        builder.setTitle(getStepTitle())
            .setCancelable(false)
            .setView(dialogView)
            .setPositiveButton(R.string.btn_ok, new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialogInterface, int i) {
                mSubscriptions.clear();
                dialogInterface.dismiss();
                subscriber.onNext(getFromInput());
                subscriber.onCompleted();
              }
            })
            .setNegativeButton(R.string.btn_cancel, new DialogInterface.OnClickListener() {
              @Override public void onClick(DialogInterface dialogInterface, int i) {
                mSubscriptions.clear();
                dialogInterface.dismiss();
                subscriber.onError(new AbortException(activity.getString(R.string.user_cancel)));
              }
            });
        mDialog = builder.create();
        mDialog.show();
        initView(mDialog);
      }
    });
  }

  private void initView(AlertDialog mDialog) {
    mButton1 = mDialog.findViewById(android.R.id.button1);
    TextView txtSubTitle = ((TextView) mDialog.findViewById(R.id.txt_subtitle));
    txtSubTitle.setText(
        step == 2 ? R.string.subtitle_input_golden_2 : R.string.subtitle_input_golden_4);

    RequiredValidate requiredValidate = new RequiredValidate();
    mFormValidation.addValidation(new ViewValidation(mEdtSystolic).addValid(requiredValidate)
        .addValid(new NumberValidate(50, 300)));
    mFormValidation.addValidation(new ViewValidation(mEdtDiastolic).addValid(requiredValidate)
        .addValid(new NumberValidate(30, 200)));

    mSubscriptions.add(RxBus.getInstance()
        .toObservable(ValidateEvent.class)
        .subscribe(new Action1<ValidateEvent>() {
          @Override public void call(ValidateEvent validateEvent) {
            mButton1.setEnabled(mFormValidation.isValid());
          }
        }));
    mButton1.setEnabled(mFormValidation.isValid());
  }

  private Golden getFromInput() {
    Golden golden = new Golden();
    String systolic = mEdtSystolic.getText().toString();
    String diastolic = mEdtDiastolic.getText().toString();
    if (!TextUtils.isEmpty(systolic)) {
      golden.systolicSp = Integer.parseInt(systolic);
    }
    if (!TextUtils.isEmpty(diastolic)) {
      golden.diastolicSp = Integer.parseInt(diastolic);
    }
    return golden;
  }

  private String getStepTitle() {
    switch (step) {
      case 2: {
        return "2. " + activity.getString(R.string.input_golden);
      }
    }
    return "4. " + activity.getString(R.string.input_golden_again);
  }
}
