package com.mediatek.mt2511.views.chart;

import android.content.Context;
import com.mediatek.mt2511.utils.UnitConverter;
import lombok.Getter;

public class SleepStagesChartConstant {

  private int DP_LABEL_TEXT_SIZE = 13;
  private int DP_DOC_RADIUS = 7;
  private int DP_LABEL_MARGIN_LEFT = 20;
  private int DP_LABEL_MARGIN_RIGHT = 20;
  private int DP_LABEL_INTERVAL = 20;
  private int DP_LABEL_SUB_INTERVAL = 8;
  private int DP_CHART_MARGIN_BOTTOM = 82;
  private int DP_CHART_MARGIN_TOP = 58;
  private int DP_CHART_HEIGHT = 68;
  @Getter private float px_label_text_size;
  @Getter private float px_doc_radius;
  @Getter private float px_label_margin_left;
  @Getter private float px_label_margin_right;
  @Getter private float px_chart_margin_bottom;
  @Getter private float px_chart_margin_top;
  @Getter private float px_chart_height;
  @Getter private float px_label_interval;
  @Getter private float px_label_sub_interval;


  public void convertUnit(Context context) {
    UnitConverter unit_converter = new UnitConverter(context);
    this.px_doc_radius = unit_converter.spToPx(DP_DOC_RADIUS);
    this.px_label_text_size = unit_converter.spToPx(DP_LABEL_TEXT_SIZE);
    this.px_label_margin_left = unit_converter.dpToPx(DP_LABEL_MARGIN_LEFT);
    this.px_label_margin_right = unit_converter.dpToPx(DP_LABEL_MARGIN_RIGHT);
    this.px_chart_margin_bottom = unit_converter.dpToPx(DP_CHART_MARGIN_BOTTOM);
    this.px_chart_margin_top = unit_converter.dpToPx(DP_CHART_MARGIN_TOP);
    this.px_chart_height = unit_converter.dpToPx(DP_CHART_HEIGHT);
    this.px_label_interval = unit_converter.dpToPx(DP_LABEL_INTERVAL);
    this.px_label_sub_interval = unit_converter.dpToPx(DP_LABEL_SUB_INTERVAL);
  }
}
