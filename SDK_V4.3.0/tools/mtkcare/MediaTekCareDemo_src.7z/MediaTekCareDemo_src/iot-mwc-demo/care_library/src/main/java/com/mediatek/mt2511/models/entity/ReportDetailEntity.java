package com.mediatek.mt2511.models.entity;

import com.google.gson.Gson;
import com.mediatek.mt2511.models.SleepContent;
import lombok.AccessLevel;
import lombok.Getter;

@Getter public class ReportDetailEntity extends com.mediatek.mt2511.models.entity.ApiResponseEntity {

  private String asleepAt;
  private String awakeAt;
  private String duration;
  private String efficiency;
  private String comment;
  @Getter(AccessLevel.NONE) private StagesChartEntity content;

  public SleepContent getSleepContent() {
    return new SleepContent(this.content);
  }

  public ReportDetailEntity fromJson(String json) {
    String str = getResultsString(json);
    return new Gson().fromJson(str, ReportDetailEntity.class);
  }
}
