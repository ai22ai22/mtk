package com.mediatek.mt2511.fragments;

import android.support.v4.app.Fragment;
import com.mediatek.mt2511.interfaces.closeable;
import com.mediatek.mt2511.interfaces.Titled;
import com.mediatek.mt2511.services.RecordService;
import rx.Observable;
import rx.Subscriber;
import rx.subjects.PublishSubject;

public class CustomFragment extends Fragment implements Titled, closeable {
  private String title;
  private boolean active;
  private PublishSubject<String> mTitleSubject = PublishSubject.create();

  @Override public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    mTitleSubject.onNext(title);
    this.title = title;
  }

  public Observable<String> getTitleObservable() {
    return Observable.create(new Observable.OnSubscribe<String>() {
      @Override public void call(Subscriber<? super String> subscriber) {
        subscriber.onNext(title);
        mTitleSubject.asObservable().subscribe(subscriber);
      }
    });
  }

  @Override public Observable<String> preClose() {
    return RecordService.getInstance().confirmSave(getActivity());
  }

  @Override public void close() {

  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  @Override public String toString() {
    return getTitle();
  }
}
