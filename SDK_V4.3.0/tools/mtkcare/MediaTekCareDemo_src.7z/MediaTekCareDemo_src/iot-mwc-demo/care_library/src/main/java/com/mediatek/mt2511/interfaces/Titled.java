package com.mediatek.mt2511.interfaces;

public interface Titled {
  String getTitle();
  boolean isActive();
}
