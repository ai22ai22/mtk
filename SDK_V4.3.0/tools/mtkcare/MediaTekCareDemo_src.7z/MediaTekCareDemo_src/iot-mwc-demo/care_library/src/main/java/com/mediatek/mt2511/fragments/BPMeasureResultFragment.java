package com.mediatek.mt2511.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.views.chart.PwttBrokenLineGraph;
import java.util.ArrayList;

/**
 * Created by MTK40108 on 7/6/2016.
 */
public class BPMeasureResultFragment extends BaseFragment {
  PwttBrokenLineGraph stepBrokenLineGraph;
  private ArrayList<String> xData;
  private ArrayList<Integer> yData;

  public BPMeasureResultFragment() {
    super();
  }

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    if (savedInstanceState == null) {
      savedInstanceState = getActivity().getIntent().getExtras();
    }
  }

  @Override public View onCreateView(LayoutInflater inflater, ViewGroup container,
      Bundle savedInstanceState) {
    View v = super.inflate(R.layout.fragment_bp_measure_result, inflater, container);
    stepBrokenLineGraph = (PwttBrokenLineGraph) v.findViewById(R.id.broken_line_graph_step);
    return v;
  }

  public void init(ArrayList<String> xData, ArrayList<Integer> yData) {
    this.xData = xData;
    this.yData = yData;
    if (stepBrokenLineGraph != null) {
      stepBrokenLineGraph.initBrokenLineGraph(xData, yData);
    }
  }
}
