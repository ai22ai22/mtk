package com.mediatek.mt2511.snr;

import java.util.ArrayList;

/**
 * Created by MTK40526 on 3/23/2016.
 */
public class PPGFilterService {

  private static final int I4PPGLPFORDER = 128 + 1;
  private static final double[] f4PggLpf40HzOrder128Coeff = {
      0.001860f, 0.002115f, 0.002348f, 0.002552f, 0.002718f, 0.002838f, 0.002904f, 0.002911f,
      0.002851f, 0.002720f, 0.002515f, 0.002235f, 0.001878f, 0.001447f, 0.000945f, 0.000377f,
      -0.000249f, -0.000925f, -0.001641f, -0.002384f, -0.003140f, -0.003895f, -0.004634f,
      -0.005340f, -0.005997f, -0.006588f, -0.007096f, -0.007507f, -0.007803f, -0.007973f,
      -0.008002f, -0.007881f, -0.007600f, -0.007152f, -0.006532f, -0.005738f, -0.004769f,
      -0.003628f, -0.002319f, -0.000849f, 0.000773f, 0.002534f, 0.004424f, 0.006425f, 0.008521f,
      0.010694f, 0.012926f, 0.015195f, 0.017482f, 0.019764f, 0.022021f, 0.024231f, 0.026374f,
      0.028430f, 0.030378f, 0.032201f, 0.033882f, 0.035404f, 0.036753f, 0.037917f, 0.038885f,
      0.039647f, 0.040196f, 0.040528f, 0.040639f, 0.040528f, 0.040196f, 0.039647f, 0.038885f,
      0.037917f, 0.036753f, 0.035404f, 0.033882f, 0.032201f, 0.030378f, 0.028430f, 0.026374f,
      0.024231f, 0.022021f, 0.019764f, 0.017482f, 0.015195f, 0.012926f, 0.010694f, 0.008521f,
      0.006425f, 0.004424f, 0.002534f, 0.000773f, -0.000849f, -0.002319f, -0.003628f, -0.004769f,
      -0.005738f, -0.006532f, -0.007152f, -0.007600f, -0.007881f, -0.008002f, -0.007973f,
      -0.007803f, -0.007507f, -0.007096f, -0.006588f, -0.005997f, -0.005340f, -0.004634f,
      -0.003895f, -0.003140f, -0.002384f, -0.001641f, -0.000925f, -0.000249f, 0.000377f, 0.000945f,
      0.001447f, 0.001878f, 0.002235f, 0.002515f, 0.002720f, 0.002851f, 0.002911f, 0.002904f,
      0.002838f, 0.002718f, 0.002552f, 0.002348f, 0.002115f, 0.001860f
  };
  int LpfCoefLength = 128 + 1;
  private double f4PpgBuf[] = new double[LpfCoefLength];

  private boolean initialized = false;

  private double f4PpgDc;

  public PPGFilterService() {
    for (int i = 0; i < LpfCoefLength; i++) {
      f4PpgBuf[i] = 0f;
    }
  }

  public double filter(double data) {
    if (!initialized) {
      f4PpgDc = data;
      initialized = true;
    }
    double s_hpf = (data - f4PpgDc);
    f4PpgDc += (s_hpf / 32);
    return (s_hpf);
  }

  // do Convolution
  public ArrayList<Double> conv(ArrayList<Double> s_hpf) {
    ArrayList<Double> sig_filt = new ArrayList<Double>();
    ArrayList<Double> inputB = new ArrayList<Double>();
    int m = s_hpf.size();
    LpfCoefLength = f4PggLpf40HzOrder128Coeff.length;
    for (int i = 0; i < LpfCoefLength; i++) {
      inputB.add(f4PggLpf40HzOrder128Coeff[i]);
    }
    for (int i = LpfCoefLength; i < m + LpfCoefLength - 1; i++) {
      inputB.add(0.0);
    }

    for (int i = 0; i < m + LpfCoefLength - 1; i++) {
      double result = 0.0;
      int tem = i >= m ? m - 1 : i;
      for (int j = 0; j <= tem; j++) {
        result += (s_hpf.get(j) * inputB.get(i - j));
      }
      sig_filt.add(result);
    }
    return sig_filt;
  }
}
