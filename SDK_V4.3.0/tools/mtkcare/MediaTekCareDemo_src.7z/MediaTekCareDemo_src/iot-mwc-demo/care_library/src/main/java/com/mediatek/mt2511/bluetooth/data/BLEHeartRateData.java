package com.mediatek.mt2511.bluetooth.data;

import com.mediatek.iot.data.BaseData;

public class BLEHeartRateData extends BaseData {
  private int value;
  public BLEHeartRateData(byte[] bytes) {
    value = bytes[1] & 0xFF;
  }
  public int getValue() {
    return value;
  }
}
