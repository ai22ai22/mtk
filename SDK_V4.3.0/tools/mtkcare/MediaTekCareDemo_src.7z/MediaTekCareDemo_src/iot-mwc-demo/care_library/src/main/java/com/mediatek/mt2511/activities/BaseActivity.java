package com.mediatek.mt2511.activities;

import android.support.v7.app.AppCompatActivity;
import com.mediatek.mt2511.utils.PauseHandler;
import rx.Observable;

public class BaseActivity extends AppCompatActivity {
  private PauseHandler mPauseHandler = new PauseHandler(new PauseHandler.OnHandler() {
    @Override public void onHandle(Observable observable) {

    }
  });

  @Override protected void onPause() {
    super.onPause();
    mPauseHandler.pause();
  }

  @Override protected void onResume() {
    super.onResume();
    mPauseHandler.resume();
  }
}
