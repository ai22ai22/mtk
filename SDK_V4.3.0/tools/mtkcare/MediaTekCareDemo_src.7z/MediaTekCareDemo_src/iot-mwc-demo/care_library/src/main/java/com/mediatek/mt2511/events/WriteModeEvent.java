package com.mediatek.mt2511.events;

public class WriteModeEvent {
  public WriteModeEvent() {

  }
}
