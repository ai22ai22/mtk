package com.mediatek.mt2511.views.validation;

import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;

public class NumberValidate extends Validate {
  private final int maxValue;
  private final int minValue;

  public NumberValidate(int minValue, int maxValue ) {
    super(MContext.getInstance().getApplication().getString(R.string.validate_number_range_invalid, minValue, maxValue));
    this.minValue = minValue;
    this.maxValue = maxValue;
  }

  @Override protected boolean isValid(String value) {
    try {
      int intValue = Integer.parseInt(value);
      if (intValue < minValue || intValue > maxValue) {
        return false;
      }
      return true;
    }catch (NumberFormatException e){
      return false;
    }
  }
}
