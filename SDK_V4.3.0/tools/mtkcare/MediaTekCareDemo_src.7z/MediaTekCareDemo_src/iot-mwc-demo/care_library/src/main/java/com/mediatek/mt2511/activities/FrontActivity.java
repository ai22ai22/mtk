package com.mediatek.mt2511.activities;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.mediatek.mt2511.AppConstants;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.framework.DeviceSupportException;
import com.mediatek.mt2511.services.UserSession;

/**
 * Created by MTK40526 on 1/8/2016.
 */
public class FrontActivity extends Activity {
  private boolean isDeviceEnabled = false;

  public static int px2dip(float pxValue, float scale) {
    return (int) (pxValue / scale + 0.5f);
  }

  public static int dip2px(float dipValue, float scale) {
    return (int) (dipValue * scale + 0.5f);
  }

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    MContext.getInstance().registerFrontActivity(this);
    setContentView(R.layout.front_page);
    initView();
    if (getIntent().getBooleanExtra("EXIT", false)) {
      finish();
    } else {
      UserSession.getInstance().reset();
      DisplayMetrics dm = getResources().getDisplayMetrics();
      ImageView appIcon = (ImageView) findViewById(R.id.appIcon);
      TextView appName = (TextView) findViewById(R.id.appName);
      TextView appHint = (TextView) findViewById(R.id.appHint);

      ObjectAnimator oa2 = ObjectAnimator.ofFloat(appName, "textSize", 0f,
          px2dip(appName.getTextSize(), dm.density));
      ObjectAnimator oa = ObjectAnimator.ofFloat(appIcon, "alpha", 0f, 1f);
      ObjectAnimator oa1 = ObjectAnimator.ofFloat(appHint, "textSize", 0f,
          px2dip(appHint.getTextSize(), dm.density));
      oa.setDuration(1000);
      oa1.setDuration(1000);
      oa2.setDuration(1000);
      oa2.start();
      oa.start();
      oa1.start();

      try {
        preCheckEnvironment();
      } catch (DeviceSupportException e) {
        e.printStackTrace();
        Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        finish();
      }

      isDeviceEnabled = isEnabled();
      if (!isDeviceEnabled) {
        startIntentToEnable(this);
      }
    }
  }

  private void initView() {
    findViewById(R.id.btn_sign_in).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        doSignIn();
      }
    });

    findViewById(R.id.btn_offline).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        doOffline();
      }
    });
  }

  @Override protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    if (intent.getBooleanExtra("EXIT", false)) {
      finish();
    }
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == AppConstants.REQUEST_ENABLE_BLUETOOTH && !isEnabled()) {
      finish();
      return;
    }
    super.onActivityResult(requestCode, resultCode, data);

    this.finish();
    Intent intent = new Intent(this, DevicesActivity.class);
    startActivity(intent);
  }

  public void preCheckEnvironment() throws DeviceSupportException {
    if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
      throw new DeviceSupportException(getString(R.string.ble_not_supported));
    }
    final BluetoothManager bluetoothManager =
        (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
    BluetoothAdapter mBluetoothAdapter = bluetoothManager.getAdapter();
    if (mBluetoothAdapter == null) {
      throw new DeviceSupportException(getString(R.string.error_bluetooth_not_supported));
    }
  }

  public boolean isEnabled() {
    BluetoothManager bluetoothManager =
        (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
    return bluetoothManager.getAdapter().isEnabled();
  }

  public void startIntentToEnable(Activity activity) {
    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
    activity.startActivityForResult(enableBtIntent, AppConstants.REQUEST_ENABLE_BLUETOOTH);
  }

  void doSignIn() {
    Intent intent = new Intent(this, LoginActivity.class);
    startActivity(intent);
    //finish();

  }

  void doOffline() {
    Intent intent = new Intent(this, DevicesActivity.class);
    startActivity(intent);
    // finish();
  }
}
