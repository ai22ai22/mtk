package com.mediatek.mt2511.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.PersonalModel;
import com.mediatek.mt2511.models.PersonalProfileEntity;
import com.mediatek.mt2511.presentation.WriteProfilePresenter;
import com.mediatek.mt2511.services.RecordService;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

public class ApplyPersonalBPMeasureFragment extends BPMeasureFragment {
  private WriteProfilePresenter presenter;

  public ApplyPersonalBPMeasureFragment() {
    presenter = new WriteProfilePresenter();
    presenter.setView(this);
    setTitle(MContext.getInstance().getApplication().getString(R.string.bp_measure_apply_personal));
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = super.onCreateView(inflater, container, savedInstanceState);
    Bundle args = getArguments();
    String id = args.getString("profile_id", "");
    presenter.setCurrentProfile(id);
    return view;
  }

  @Override public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
    inflater.inflate(R.menu.bp_measure_calibration_menu, menu);
  }

  @Override public boolean onOptionsItemSelected(MenuItem item) {
    if (item.getItemId() == R.id.action_user_list) {
      if (RecordService.getInstance().isInRecording()) {
        Toast.makeText(getActivity(), R.string.warn_in_recording, Toast.LENGTH_LONG).show();
        return true;
      }
      Fragment fragment = getParentFragment();
      if (fragment instanceof BPMeasurePersonalFragment) {
        ((BPMeasurePersonalFragment) fragment).showUserList();
      }
    }
    return false;
  }


  @Override public void onDestroy() {
    super.onDestroy();
    presenter.exit();
  }

  @Override public void setCurrentProfileComplete(String userId) {
    super.setCurrentProfileComplete(userId);
    Toast.makeText(getActivity(),R.string.ready_to_bp, Toast.LENGTH_LONG).show();
  }
}
