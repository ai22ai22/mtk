package com.mediatek.mt2511.apx;

public class UniqueDataSet {
  int[] dataTimestamp;
  int[] data;
}
