package com.mediatek.mt2511.models.pojo;

import java.util.ArrayList;

public class UploadCareRequest {
  public String userNickname;
  public int age;
  public String gender;
  public String comment;
  public ArrayList<String> fileList = new ArrayList<>();
}
