package com.mediatek.mt2511.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.DialogFragment;
import android.support.v7.internal.view.ContextThemeWrapper;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.jakewharton.rxbinding.widget.TextViewTextChangeEvent;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.bluetooth.data.ATCommand;
import com.mediatek.mt2511.custom.CustomUtils;
import com.mediatek.mt2511.models.Record;
import com.mediatek.mt2511.models.pojo.RecordResult;
import com.mediatek.mt2511.models.pojo.UploadCareRequest;
import com.mediatek.mt2511.network.MyProjectApi;
import com.mediatek.mt2511.services.UserSession;
import com.mediatek.mt2511.utils.DateUtils;
import com.mediatek.mt2511.utils.UIUtils;
import com.mediatek.mt2511.views.validation.CompositeValidation;
import com.mediatek.mt2511.views.validation.NumberValidate;
import com.mediatek.mt2511.views.validation.RequiredValidate;
import com.mediatek.mt2511.views.validation.ValidateEvent;
import com.mediatek.mt2511.views.validation.ViewValidation;
import com.mediatek.utils.RxBus;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.functions.Func5;
import rx.subscriptions.CompositeSubscription;
import timber.log.Timber;

/**
 * Created by MTK40526 on 5/5/2016.
 */
public class AddRecordFragment extends FormFragment {
  public static final String SP_USERID = "userid";
  private static final String SP_BIRTH_YEAR = "birth_year";
  private static final String SP_SEX = "sex";
  private static final String SP_HEIGHT = "height";
  private static final String SP_WEIGHT = "weight";
  private static final String SP_ARM_LENGTH = "arm_length";
  private static final String SP_DISEASE = "disease";
  private static final int DISEASE_HYPERTENSION = 0b0001;
  private static final int DISEASE_HYPOTENSION = 0b0010;
  private static final int DISEASE_DIABETES = 0b0100;
  private static final int DISEASE_HEART_DISEASE = 0b1000;

  RadioGroup mRGSex;
  EditText mEdtUserId;
  EditText mEdtBirthYear;
  TextInputLayout mInputLayoutAge;
  TextInputLayout mInputLayoutUserId;
  TextInputLayout mInputLayoutHeight;
  TextInputLayout mInputLayoutWeight;
  TextInputLayout mInputLayoutArmLength;
  EditText mEdtHeight;
  EditText mEdtWeight;
  EditText mEdtArmLength;

  RadioButton mRBMale;
  RadioButton mRBFemale;

  private SharedPreferences mSp;
  private CompositeSubscription mSubscriptions = new CompositeSubscription();
  private ViewGroup mLayoutCheckboxs;
  private CompositeValidation mValidations = new CompositeValidation();

  public AddRecordFragment() {
    setTitle(MContext.getInstance().getApplication().getString(R.string.add_record));
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    final Context contextThemeWrapper =
        new ContextThemeWrapper(getActivity(), R.style.MAlertDialog);
    LayoutInflater localInflater = inflater.cloneInContext(contextThemeWrapper);
    View view = localInflater.inflate(R.layout.fragment_add_record, container, false);
    initView(view);
   // bindValidEvent();
    buildValidation();
    return view;
  }

  private void buildValidation() {
    mValidations.clear();
    RequiredValidate requiredValidate = new RequiredValidate();
    mValidations.addValidation(new ViewValidation(mEdtUserId).addValid(requiredValidate));
    mValidations.addValidation(new ViewValidation(mEdtBirthYear).addValid(requiredValidate)
        .addValid(new NumberValidate(1900, UIUtils.getYear())));
    mValidations.addValidation(new ViewValidation(mEdtHeight).addValid(requiredValidate)
        .addValid(new NumberValidate(90, 260)));
    mValidations.addValidation(new ViewValidation(mEdtWeight).addValid(requiredValidate)
        .addValid(new NumberValidate(20, 250)));
    mSubscriptions.add(RxBus.getInstance()
        .toObservable(ValidateEvent.class)
        .subscribe(new Action1<ValidateEvent>() {
          @Override public void call(ValidateEvent validateEvent) {
            if (validateEvent.isValid() && mValidations.isValid()){
              setValidation(true);
            }else {
              setValidation(false);
            }
          }
        }));
    setValidation(mValidations.isValid());
  }

  private void initView(View view) {
    mRGSex = (RadioGroup) view.findViewById(R.id.rg_sex);

    mInputLayoutAge = (TextInputLayout) view.findViewById(R.id.input_layout_age);
    mInputLayoutUserId = (TextInputLayout) view.findViewById(R.id.input_layout_user_id);
    mInputLayoutHeight = (TextInputLayout) view.findViewById(R.id.input_layout_height);
    mInputLayoutWeight = (TextInputLayout) view.findViewById(R.id.input_layout_weight);
    mInputLayoutArmLength = (TextInputLayout) view.findViewById(R.id.input_layout_arm_length);

    mEdtUserId = (EditText) view.findViewById(R.id.txt_user_id);
    mEdtBirthYear = (EditText) view.findViewById(R.id.txt_birth_year);
    mEdtHeight = (EditText) view.findViewById(R.id.txt_height);
    mEdtWeight = (EditText) view.findViewById(R.id.txt_weight);
    mEdtArmLength = (EditText) view.findViewById(R.id.txt_arm_length);
    mRBMale = (RadioButton) view.findViewById(R.id.rb_male);
    mRBFemale = (RadioButton) view.findViewById(R.id.rb_female);

    mLayoutCheckboxs = (ViewGroup) view.findViewById(R.id.cbs_chronic_disease);

    final ScrollView scrollView = (ScrollView) view.findViewById(R.id.scrollView_root);
    mEdtArmLength.setOnEditorActionListener(new TextView.OnEditorActionListener() {
      @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_DONE) {
          scrollView.scrollTo(0, mLayoutCheckboxs.getBottom());
        }
        return false;
      }
    });
    restoreInput();
  }


  private void restoreInput() {
    mSp = getActivity().getSharedPreferences("addRecord", Context.MODE_PRIVATE);
    UIUtils.setFormEdit(mEdtUserId, mSp.getString(SP_USERID, ""));
    UIUtils.setFormEdit(mEdtBirthYear, mSp.getString(SP_BIRTH_YEAR, ""));
    UIUtils.setFormEdit(mEdtWeight, mSp.getString(SP_WEIGHT, ""));
    UIUtils.setFormEdit(mEdtHeight, mSp.getString(SP_HEIGHT, ""));
    UIUtils.setFormEdit(mEdtArmLength, mSp.getString(SP_ARM_LENGTH, ""));
    setAge(mSp.getString(SP_SEX, "M"));
    UIUtils.selectCheckbox(mSp.getString(SP_DISEASE, ""), mLayoutCheckboxs);
  }

  private String getSex() {
    int id = mRGSex.getCheckedRadioButtonId();
    if (id == R.id.rb_male) {
      return "M";
    } else if (id == R.id.rb_female) {
      return "F";
    }
    return "";
  }

  public void setAge(String sex) {
    if (sex.equals("M")) {
      mRBMale.setChecked(true);
    } else {
      mRBFemale.setChecked(true);
    }
  }

  private void dofinish() {
    if (getParentFragment() instanceof DialogFragment) {
      ((DialogFragment) getParentFragment()).dismiss();
    } else {
      getActivity().finish();
    }
  }

  @Override public void onDestroy() {
    super.onDestroy();
    mSubscriptions.clear();
  }

  public void preSubmit() {
    String selecteId = UIUtils.getSelectedCheckeBoxs(mLayoutCheckboxs);
    mSp.edit()
        .putString(SP_USERID, mEdtUserId.getText().toString())
        .putString(SP_BIRTH_YEAR, mEdtBirthYear.getText().toString())
        .putString(SP_SEX, getSex())
        .putString(SP_HEIGHT, mEdtHeight.getText().toString())
        .putString(SP_WEIGHT, mEdtWeight.getText().toString())
        .putString(SP_ARM_LENGTH, mEdtArmLength.getText().toString())
        .putString(SP_DISEASE, selecteId)
        .apply();
  }

  @Override public Observable<Record> submit() {
    //return submitForm();
    return Observable.create(new Observable.OnSubscribe<Record>() {
      @Override public void call(final Subscriber<? super Record> subscriber) {
        Observable.concat(writeToDevice(), submitForm()).subscribe(new Subscriber<Boolean>() {
          @Override public void onCompleted() {
            Record record = new Record();
            record.userId = mEdtUserId.getText().toString();
            record.age = String.valueOf(
                DateUtils.calcAge(Integer.valueOf(mEdtBirthYear.getText().toString())));
            record.gendor = getSex();
            record.height = mEdtHeight.getText().toString();
            record.weight = mEdtWeight.getText().toString();
            record.armLength = "0";
            record.disease = UIUtils.getSelectedCheckeBoxs(mLayoutCheckboxs);
            subscriber.onNext(record);
            subscriber.onCompleted();
          }

          @Override public void onError(Throwable e) {
            subscriber.onError(e);
          }

          @Override public void onNext(Boolean aBoolean) {

          }
        });
      }
    });
  }

  private Observable<Boolean> submitForm() {
    preSubmit();

    return Observable.create(new Observable.OnSubscribe<Boolean>() {
      @Override public void call(final Subscriber<? super Boolean> subscriber) {

        UploadCareRequest recordRequest = new UploadCareRequest();
        recordRequest.age = DateUtils.calcAge(Integer.parseInt(mEdtBirthYear.getText().toString()));
        recordRequest.userNickname = mEdtUserId.getText().toString();
        recordRequest.gender = getSex();
        recordRequest.comment =
            "This chart represent the physiological age of yourscomparing with others ";
        final ProgressDialog progressDialog =
            ProgressDialog.show(getActivity(), getString(R.string.add_record),
                getString(R.string.waiting_a_moment), true);
        MyProjectApi.getIoTService()
            .createRecord(recordRequest)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(new Subscriber<RecordResult>() {
              @Override public void onCompleted() {
                progressDialog.dismiss();
                subscriber.onCompleted();
              }

              @Override public void onError(Throwable e) {
                progressDialog.dismiss();
                Log.e("error", e.getMessage(), e);
                Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
                subscriber.onError(e);
              }

              @Override public void onNext(RecordResult recordResult) {
                UserSession.RecordInfo recordInfo = new UserSession.RecordInfo();
                recordInfo.recordId = recordResult.recordId;
                recordInfo.userId = recordResult.userNickname;
                recordInfo.age = recordResult.age;
                recordInfo.gender = getSex();
                recordInfo.weight = Integer.parseInt(mEdtWeight.getText().toString());
                recordInfo.height = Integer.parseInt(mEdtHeight.getText().toString());
                recordInfo.armLen = TextUtils.isEmpty(mEdtArmLength.getText()) ? 0
                    : Integer.parseInt(mEdtArmLength.getText().toString());
                UserSession.getInstance().saveRecordInfo(recordInfo);
                UserSession.getInstance().saveDefaultProfile(recordInfo);
                subscriber.onNext(true);
              }
            });
      }
    });
  }

  private Observable<Boolean> writeToDevice() {
    String userId = mEdtUserId.getText().toString();
    int height = Integer.parseInt(mEdtHeight.getText().toString());
    int weight = Integer.parseInt(mEdtWeight.getText().toString());
    int gender = getSex().equals("M") ? 1 : 2;
    int age = DateUtils.calcAge(Integer.parseInt(mEdtBirthYear.getText().toString()));
    int armLen = TextUtils.isEmpty(mEdtArmLength.getText()) ? 0
        : Integer.parseInt(mEdtArmLength.getText().toString());
    ATCommand atCommand = new ATCommand(userId, height, weight, gender, age, armLen);
    return CustomUtils.sendATCommand(atCommand);
  }

  private byte[] readCommandBytes(String fieldName) {
    final String format = "AT+ENVDM=0,2511,%s\r\n";
    return String.format(format, fieldName).getBytes();
  }
}
