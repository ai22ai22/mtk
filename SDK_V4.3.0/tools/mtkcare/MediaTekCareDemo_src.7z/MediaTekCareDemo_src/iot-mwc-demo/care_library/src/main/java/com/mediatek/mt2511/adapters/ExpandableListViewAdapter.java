package com.mediatek.mt2511.adapters;

import android.content.Context;
import android.support.v4.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;
import com.mediatek.mt2511.fragments.CustomFragment;
import com.mediatek.mt2511.interfaces.Titled;
import java.util.ArrayList;

public class ExpandableListViewAdapter extends BaseExpandableListAdapter {
  private final Context context;
  private final int groupLayout;
  private final int childLayout;
  private ArrayList<Pair<String, ArrayList<Pair<String, CustomFragment>>>> groupData = new ArrayList<>();

  public ExpandableListViewAdapter(Context context, ArrayList<? extends CustomFragment> listData,
      int groupLayout, int childLayout) {
    this.context = context;
    this.groupLayout = groupLayout;
    this.childLayout = childLayout;
    buildGroupData(listData);
  }

  private void buildGroupData(ArrayList<? extends CustomFragment> listData) {
    String lastTitle = "";
    for (CustomFragment item : listData) {
      String[] gTitle = item.getTitle().split("/");
      String groupTitle = item.getTitle();
      if (gTitle.length > 1) {
        groupTitle = gTitle[0];
      }
      ArrayList<Pair<String, CustomFragment>> subItems;
      if (lastTitle.endsWith(groupTitle)) {
        subItems = groupData.get(groupData.size() - 1).second;
      } else {
        subItems = new ArrayList<>();
        groupData.add(new Pair<>(groupTitle, subItems));
      }
      lastTitle = groupTitle;
      subItems.add(new Pair<>(item.getTitle(), item));
    }
  }

  @Override public int getGroupCount() {
    return groupData.size();
  }

  @Override public int getChildrenCount(int groupPosition) {
    ArrayList subItems = groupData.get(groupPosition).second;
    if (subItems.size() > 1) {
      return subItems.size();
    }
    return 0;
  }

  @Override public Pair<String, ArrayList<Pair<String, CustomFragment>>> getGroup(int groupPosition) {
    return groupData.get(groupPosition);
  }

  @Override public Pair<String, CustomFragment> getChild(int groupPosition, int childPosition) {
    return groupData.get(groupPosition).second.get(childPosition);
  }

  @Override public long getGroupId(int groupPosition) {
    return groupPosition;
  }

  @Override public long getChildId(int groupPosition, int childPosition) {
    return groupPosition * 100 + childPosition;
  }

  @Override public boolean hasStableIds() {
    return false;
  }

  @Override public View getGroupView(int groupPosition, boolean isExpanded, View convertView,
      ViewGroup parent) {
    Pair<String, ArrayList<Pair<String, CustomFragment>>> group = getGroup(groupPosition);
    String headerTitle = group.first;
    if (convertView == null) {
      LayoutInflater inflater =
          (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
      convertView = inflater.inflate(groupLayout, null);
    }
    TextView lblListHeader = (TextView) convertView;
    lblListHeader.setText(headerTitle);
    if (group.second.size() == 1) {
      CustomFragment firstChild = group.second.get(0).second;
      convertView.setSelected(firstChild.isActive());
      convertView.setActivated(firstChild.isActive());
    } else {
      convertView.setSelected(false);
      convertView.setActivated(false);
    }
    return convertView;
  }

  @Override public View getChildView(int groupPosition, int childPosition, boolean isLastChild,
      View convertView, ViewGroup parent) {
    Pair<String, CustomFragment> child = getChild(groupPosition, childPosition);
    String[] ss = child.first.split("/");
    String childTitle = ss[ss.length -1];
    if (convertView == null) {
      LayoutInflater inflater =
          (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
      convertView = inflater.inflate(childLayout, null);
    }
    TextView lblListChild = (TextView) convertView;
    lblListChild.setText(childTitle);
    convertView.setSelected(child.second.isActive());
    convertView.setActivated(child.second.isActive());
    return convertView;
  }

  @Override public boolean isChildSelectable(int groupPosition, int childPosition) {
    return true;
  }
}
