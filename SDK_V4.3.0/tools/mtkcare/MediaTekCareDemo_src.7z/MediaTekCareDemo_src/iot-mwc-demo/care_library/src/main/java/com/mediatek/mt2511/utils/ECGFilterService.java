package com.mediatek.mt2511.utils;

import com.mediatek.mt2511.interfaces.FilterService;

/**
 * Created by MTK40526 on 3/23/2016.
 */
public class ECGFilterService implements FilterService {
    int i4EcgLpfOrder = 32;
    float f4EcgLpfCoeff[] = {
        0.004823f, -0.007923f, 0.000878f, 0.013837f,
        -0.019279f, 0.001859f, 0.026757f, -0.034345f,
        0.002673f, 0.044334f, -0.055630f, 0.003130f,
        0.080969f, -0.114953f, 0.003291f, 0.550358f,
        0.550358f, 0.003291f, -0.114953f, 0.080969f,
        0.003130f, -0.055630f, 0.044334f, 0.002673f,
        -0.034345f, 0.026757f, 0.001859f, -0.019279f,
        0.013837f, 0.000878f, -0.007923f, 0.004823f};

    private boolean initialized = false;
    private float f4EcgDc;
    private int i4EcgBufIndex = 0; // should be global variable
    private  float[] f4EcgBuf = new float[32]; // size = i4EcgLpfOrder
    public ECGFilterService(){
        for(int i=0; i<i4EcgLpfOrder; i++) {
            f4EcgBuf[i] = 0;
        }
    }

    @Override
    public float filter(float data) {
        if (!initialized){
            f4EcgDc  = data;
            initialized = true;
        }
        f4EcgDc += (data - f4EcgDc) / 32;
        f4EcgBuf[i4EcgBufIndex % i4EcgLpfOrder] = (data - f4EcgDc);
        float varLPF = 0;
        for (int idx = 0; idx < i4EcgLpfOrder; idx++) {
            varLPF += f4EcgLpfCoeff[idx] * f4EcgBuf[(i4EcgBufIndex + idx) % i4EcgLpfOrder];
        }
        i4EcgBufIndex = (i4EcgBufIndex + 1) % i4EcgLpfOrder;
        return varLPF;


    }
}
