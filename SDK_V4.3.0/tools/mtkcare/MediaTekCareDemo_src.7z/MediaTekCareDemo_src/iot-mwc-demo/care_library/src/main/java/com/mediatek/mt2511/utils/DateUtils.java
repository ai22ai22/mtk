package com.mediatek.mt2511.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DateUtils {

  /**
   * For UI display purpose.
   * @param apiTimeStamp timestamp from api.
   * @return formatted date string.
   */
  public static String formatApiDate(String apiTimeStamp) {
    String dateSdfPattern = "yyyy/MM/dd";
    return formatTimeStampBy(dateSdfPattern, apiTimeStamp);
  }

  /**
   * For UI display purpose.
   * @param apiTimeStamp timestamp from api.
   * @return formatted time string.
   */
  public static String formatApiTime(String apiTimeStamp) {
    String timeSdfPattern = "HH:mm";
    return formatTimeStampBy(timeSdfPattern, apiTimeStamp);
  }

  private static String formatTimeStampBy(String sdfPattern, String timeStamp) {
    String apiSdfPattern = "yyyy-MM-dd'T'HH:mm:ss";
    return formatDate(timeStamp, apiSdfPattern, sdfPattern);
  }

  public static String formatDate(String date, String inputSdfPattern, String outputSdfPattern) {
    try {
      SimpleDateFormat inputSdf = new SimpleDateFormat(inputSdfPattern, Locale.getDefault());
      SimpleDateFormat outputSdf = new SimpleDateFormat(outputSdfPattern, Locale.getDefault());
      Date d = inputSdf.parse(date);
      return outputSdf.format(d);
    } catch (ParseException e) {
//      GsLog.e(e);
      return "";
    }
  }
  public static int calcAge(int birthYear){
    Calendar calendar = Calendar.getInstance();
    return calendar.get(Calendar.YEAR) - birthYear;
  }
}
