package com.mediatek.mt2511.views.validation;

import android.text.TextUtils;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;

public class RequiredValidate extends Validate{
  public RequiredValidate() {
    super(MContext.getInstance().getApplication().getString(R.string.validate_required_invalid));
  }

  @Override protected boolean isValid(String value) {
    return !TextUtils.isEmpty(value);
  }
}
