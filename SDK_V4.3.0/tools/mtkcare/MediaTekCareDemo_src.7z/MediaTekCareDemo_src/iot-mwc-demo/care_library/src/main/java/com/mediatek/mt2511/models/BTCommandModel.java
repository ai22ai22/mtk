package com.mediatek.mt2511.models;

import android.bluetooth.BluetoothAdapter;
import com.mediatek.mt2511.custom.BTDeviceFactory;
import com.mediatek.mt2511.exceptions.ATCommandException;
import com.mediatek.mt2511.framework.bt.RxBtDevice;
import com.mediatek.mt2511.utils.CHexConver;
import java.util.UUID;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action0;
import rx.functions.Func1;
import timber.log.Timber;

public class BTCommandModel {
  private static BTCommandModel DEFAULT;
  private final RxBtDevice rxBtDevice;

  private BTCommandModel() {
    rxBtDevice = RxBtDevice.getInstance(BluetoothAdapter.getDefaultAdapter()
            .getRemoteDevice(BTDeviceFactory.getBTDevice().getAddress()),
        UUID.fromString("00001101-0000-1000-8000-00805F9B345B"));
  }

  public static BTCommandModel getDefault() {
    if (DEFAULT == null) {
      DEFAULT = new BTCommandModel();
    }
    return DEFAULT;
  }

  public Observable<byte[]> sendCommand(final byte[] command) {
    return Observable.create(new Observable.OnSubscribe<byte[]>() {
      @Override public void call(Subscriber<? super byte[]> subscriber) {
        rxBtDevice.writeCommand(command).subscribe(subscriber);
      }
    });
  }

  public Observable<String> sendCommand(final String fieldName, final String value) {
    final String format = "AT+ENVDM=1,2511,%s,%d,%s\r\n";
    final String strCommand =
        String.format(format, fieldName, value.length(), CHexConver.str2HexStr(value));
    byte[] command = strCommand.getBytes();
    return sendCommand(command).doOnSubscribe(new Action0() {
      @Override public void call() {
        Timber.d("ATCommand %s -->", strCommand);
      }
    }).flatMap(new Func1<byte[], Observable<String>>() {
      @Override public Observable<String> call(byte[] bytes) {
        String result = new String(bytes);
        Timber.d("ATCommand %s <--", result);
        if (!result.endsWith("OK\r\n")) {
          return Observable.error(new ATCommandException("Sync data error"));
        } else {
          return Observable.just("OK");
        }
      }
    });
  }

  public Observable<String> validField(final String fieldName, final String value) {
    final String format = "AT+ENVDM=0,2511,%s\r\n";
    final String strCommand =
        String.format(format, fieldName, value.length(), CHexConver.str2HexStr(value));
    byte[] command = strCommand.getBytes();
    return sendCommand(command).doOnSubscribe(new Action0() {
      @Override public void call() {
        Timber.d("ATCommand %s -->", strCommand);
      }
    }).flatMap(new Func1<byte[], Observable<String>>() {
      @Override public Observable<String> call(byte[] bytes) {
        String result = new String(bytes).trim();
        Timber.d("ATCommand %s <--", result);
        if (!result.equals(value + "OK")) {
          return Observable.error(
              new ATCommandException(String.format("double confirm fail %s != %s", result, value)));
        } else {
          return Observable.just("");
        }
      }
    });
  }

  public Observable<String> writeAndValid(final String fieldName, final String value) {
    Observable<String> ob1 = sendCommand(fieldName, value);
    Observable<String> ob2 = validField(fieldName, value);
    return Observable.concat(ob1, ob2);
  }



  public Observable<String> writeProfile(PersonalProfileEntity personalProfileEntity) {

    Observable userId = writeAndValid("userid", personalProfileEntity.getUserId());
    Observable height = writeAndValid("height", String.valueOf(personalProfileEntity.getHeight()));
    Observable weight = writeAndValid("weight", String.valueOf(personalProfileEntity.getWeight()));
    Observable gender = writeAndValid("gender", String.valueOf(personalProfileEntity.getGender()));
    Observable age = writeAndValid("age", String.valueOf(personalProfileEntity.getAge()));
    Observable handlen =
        writeAndValid("handlen", String.valueOf(personalProfileEntity.getArmLength()));
    Observable writeMode = writeAndValid("mode", personalProfileEntity.getMode());
    Observable result = Observable.concat(userId, height, weight, gender, age, handlen,writeMode);
    CalibrationResult calibrationResult = personalProfileEntity.getCalibrationResult();
    if (calibrationResult != null) {
      result = result.concatWith(
          writeCalibaration(personalProfileEntity.getCalibrationResult()));
    }

    return result;
  }

  private Observable<String> writeCalibaration(final CalibrationResult calibrationResult) {
    return Observable.create(new Observable.OnSubscribe<String>() {
      @Override public void call(Subscriber<? super String> subscriber) {
        Observable<String> ob = Observable.empty();
        int index = 0;
        for (RealmSPPack spPack : calibrationResult.getSpPacks()) {
          index++;
          ob = ob.concatWith(writeAndValid("sbp" + index, String.valueOf(spPack.getSbp())));
          ob = ob.concatWith(writeAndValid("dbp" + index, String.valueOf(spPack.getDdp())));
        }
        index = 0;
        for (RealmInteger value : calibrationResult.getParas().getValues()) {
          index++;
          ob = ob.concatWith(writeAndValid("para" + index, String.valueOf(value.getValue())));
        }
        ob.subscribe(subscriber);
      }
    }).subscribeOn(AndroidSchedulers.mainThread());
  }

  public void clear(){
    rxBtDevice.disconnect();
    DEFAULT = null;
  }

}
