package com.mediatek.mt2511.apx;

import java.util.ArrayList;

public class AP {
	public static APResult compute_performance(
			int[] hr_record_time_gold, int[] hr_data_gold, 
			int[] hr_record_time_test, int[] hr_data_test) {
		/*
		 *  % hr_record_time_gold: time stamp of reference device (BLE HR)
		 *  % hr_data_gold: HR bpm of reference device (BLE HR)
	   *  % hr_record_time_test: time stamp of test device (MTK demo kit)
	   *  % hr_data_test: HR bpm of test device (MTK demo kit)
		 */
		APResult result = null;
		APResult candidateResult = null;
		int discardTestSecDEF = 20;
		int discardGoldSecDEF = 20;
		UniqueDataSet goldUnique = uniquify_timestamp(hr_record_time_gold, hr_data_gold);
		UniqueDataSet testUnique  =uniquify_timestamp(hr_record_time_test, hr_data_test);

		for(int discardTestSec = 0 ; discardTestSec <= discardTestSecDEF && discardTestSec < testUnique.data.length; discardTestSec++) {
			candidateResult = computeResult(goldUnique, testUnique, 0, discardTestSec);
			if (result == null || result.getMin_mean_error() > candidateResult.getMin_mean_error() ) {
				result = candidateResult;
			}
		}
		for (int discardGoldSec = 0; discardGoldSec <= discardGoldSecDEF && discardGoldSec < goldUnique.data.length; discardGoldSec++) {
			candidateResult = computeResult(goldUnique, testUnique, discardGoldSec, 0);
			if (result == null || result.getMin_mean_error()  > candidateResult.getMin_mean_error() ) {
				result = candidateResult;
			}
		}
		
		return result;
	}
	public static APResult computeResult (UniqueDataSet goldUnique, UniqueDataSet testUnique, int discardGoldSec, int discardTestSec) {
		ArrayList<Integer> errorList = new ArrayList<Integer>();
    for (int j = 0; j < testUnique.data.length; j++) {
    	if (discardTestSec + j < testUnique.data.length && discardGoldSec + j < goldUnique.data.length) {
    	  errorList.add(testUnique.data[discardTestSec + j] - goldUnique.data[discardGoldSec + j]);
    	} else {
    		break;
    	}
    }
    int[] errorArray = new int[errorList.size()];
    for(int i = 0; i < errorArray.length; i++) {
    	errorArray[i] = errorList.get(i);
    }
    //Util.printArray(errorArray);
    int curError5to10Count = 0;
    int curErrorOver10Count = 0;
    for(int i = 0; i < errorArray.length; i++) {
    	if (Math.abs(errorArray[i]) <= 5) {
    		continue;
    	} else if (Math.abs(errorArray[i]) <= 10) {
    		curError5to10Count++;
    	} else {
    		curErrorOver10Count++;
    	}
    }
    double curMean = mean(errorArray);
    return new APResult(curMean, stdev(errorArray), testUnique.dataTimestamp[discardTestSec],
    		goldUnique.dataTimestamp[discardGoldSec], errorArray.length, errorArray,
    		testUnique.dataTimestamp[discardTestSec] - goldUnique.dataTimestamp[discardGoldSec],
    		1 - ((double)curErrorOver10Count / errorArray.length), 
    		1 - ((double)curErrorOver10Count / errorArray.length) - ((double)curError5to10Count / errorArray.length));
    
	}
	public static UniqueDataSet uniquify_timestamp(int[] inputTimestamp, int[] inputData) {
  	UniqueDataSet result = new UniqueDataSet();
  	result.dataTimestamp = new int[inputTimestamp[inputTimestamp.length - 1] - inputTimestamp[0] + 1];
  	result.dataTimestamp[0] = inputTimestamp[0];
  	for(int i = 1; i < result.dataTimestamp.length;i++) {
  		result.dataTimestamp[i] = result.dataTimestamp[i - 1] + 1;
  	}
  	//timestamp checked
  	
  	result.data = new int[result.dataTimestamp.length];
  	int inputIndex = 0;
  	for ( int i = 0; i < result.dataTimestamp.length; i++) {
  		while(inputTimestamp[inputIndex] < result.dataTimestamp[i]) {
  			inputIndex++;
  		}
  		//now the inputTimestamp[inputIndex] would be equal and larger than result.dataTimestamp[i]
  		if (inputTimestamp[inputIndex] == result.dataTimestamp[i]) {
  			int sameTimestampLength = 1; 
  			while((inputIndex + sameTimestampLength < inputTimestamp.length) && inputTimestamp[inputIndex + sameTimestampLength] == inputTimestamp[inputIndex]) {
  				sameTimestampLength++;
  			}
  			//all the index of the same timestamp is collected.
  			int sum = 0;
  			for(int k = 0; k < sameTimestampLength; k++) {
  				sum += inputData[inputIndex + k];
  			} 
  			result.data[i] = (int) (sum / sameTimestampLength); 
  		} else {
  			result.data[i] = result.data[i - 1];
  		}
  	}
  	return result;
  }

  public static double mean(int[] input) {
  	double sum = 0.0;
  	for (int i=0; i < input.length; i++){
      sum+=Math.abs(input[i]);
    }
  	return sum/(input.length);
  }
  public static double stdev(int[] input){
    double num=0.0;
    double sum=0.0;
    double mean = 0.0;
    for (int i = 0 ; i < input.length; i++) {
    	sum+=input[i];
    }
    mean = sum/input.length;
    for (int i=0; i <input.length; i++){
      num+=Math.pow((input[i] - mean),2);
    }
    return Math.sqrt(num/input.length-1);
  }
}
