package com.mediatek.mt2511.models;

public class Golden {
  public Integer systolicSp;
  public Integer diastolicSp;

  public boolean isValid() {
    return (systolicSp != null && systolicSp > 0) && (diastolicSp != null && diastolicSp > 0);
  }
}
