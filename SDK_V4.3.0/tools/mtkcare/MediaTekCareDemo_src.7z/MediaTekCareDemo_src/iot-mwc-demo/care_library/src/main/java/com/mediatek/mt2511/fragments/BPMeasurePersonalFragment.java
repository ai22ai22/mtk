package com.mediatek.mt2511.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.mediatek.mt2511.MContext;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.interfaces.closeable;
import com.mediatek.mt2511.interfaces.Titled;
import com.mediatek.mt2511.presentation.BPMeasurePersonalModelPresenter;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;

public class BPMeasurePersonalFragment extends CustomFragment {
  protected BPMeasurePersonalModelPresenter presenter;
  private UserListFragment userListFragment = new UserListFragment();
  private CalibrationFragment calibrationFragment = new CalibrationFragment();
  private ApplyPersonalBPMeasureFragment applyPersonalBPMeasureFragment = new ApplyPersonalBPMeasureFragment();
  private Fragment mCurrentFragment = null;

  public BPMeasurePersonalFragment() {
    super();
    setTitle(MContext.getInstance().getApplication().getString(R.string.bp_measure_personal_model));
    presenter = new BPMeasurePersonalModelPresenter();
    presenter.setView(this);
  }

  @Nullable @Override
  public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_bp_measure_personal, container, false);
    initView(view);
    return view;
  }

  private void initView(View view) {
    showFragment(userListFragment);
  }

  private void showFragment(final Fragment fragment) {
    if (mCurrentFragment != null && mCurrentFragment instanceof closeable) {
      ((closeable) mCurrentFragment).close();
    }
    FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
    transaction.replace(R.id.content_frame, fragment).commit();
    if (fragment instanceof Titled) {
      setTitle(((Titled) fragment).getTitle());
    }
    mCurrentFragment = fragment;
  }

  public void showUserList() {
    showFragment(userListFragment);
  }

  public void showCalibration() {
    showFragment(calibrationFragment);
  }

  @Override public Observable<String> preClose() {
    return Observable.create(new Observable.OnSubscribe<String>() {
      @Override public void call(Subscriber<? super String> subscriber) {
        if (mCurrentFragment != null && mCurrentFragment instanceof closeable) {
          ((closeable) mCurrentFragment).preClose().subscribe(subscriber);
        } else {
          subscriber.onCompleted();
        }
      }
    });
  }

  public void showApplyPersonalFragment(String id){
    Bundle args = new Bundle();
    args.putString("profile_id",  id);
    applyPersonalBPMeasureFragment.setArguments(args);
    showFragment(applyPersonalBPMeasureFragment);
  }
}
