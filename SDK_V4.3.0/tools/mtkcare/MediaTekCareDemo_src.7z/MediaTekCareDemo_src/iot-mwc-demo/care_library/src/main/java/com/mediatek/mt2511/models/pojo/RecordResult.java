package com.mediatek.mt2511.models.pojo;

import java.util.HashMap;

public class RecordResult {
  public String recordId;
  public int recordSize;
  public String recordIdSeq;
  public String userNickname;
  public int age;
  public String gender;
  public String comment;
  public String filepath;
  public UploadCareResponse.UpdateStatus updateStatus;
  public HashMap<String, String> uploadURLs;

  public static class UpdateStatus {
    public int progress;
    public int totalSteps;
    public String description;
  }
}
