package com.mediatek.mt2511.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.widget.Toast;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.services.ErrorMessageMonitor;
import com.mediatek.mt2511.utils.DatatypeConverter;
import com.mediatek.mt2511.utils.ECGFilterService;
import com.mediatek.mt2511.utils.MContextCompat;
import com.mediatek.mt2511.utils.PPGFilterService;
import com.mediatek.utils.RxBus;
import com.mediatek.iot.data.bt.BTBaseData;
import com.mediatek.iot.data.bt.EKGData;
import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;

/**
 * Created by MTK40526 on 3/21/2016.
 */
public class HeartBeatView extends View {
  public static final int TYPE_ECG = 1;
  public static final int TYPE_PPG = 2;
  private HeartBeatDraw ecgDraw;
  private HeartBeatDraw ppgDraw;
  private CompositeSubscription mSubscriptions = new CompositeSubscription();
  private Matrix matrix = new Matrix();
  public HeartBeatView(Context context) {
    this(context, null);
  }

  public HeartBeatView(Context context, AttributeSet attrs) {
    this(context, attrs, 0);
  }

  public HeartBeatView(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    ecgDraw = new HeartBeatDraw(MContextCompat.getDrawable(getContext(), R.drawable.ic_ecg),
        getPaint(TYPE_ECG));
    ppgDraw = new HeartBeatDraw(MContextCompat.getDrawable(getContext(), R.drawable.ic_ppg),
        getPaint(TYPE_PPG));

    initEvent();
  }

  private void initEvent() {


    setOnLongClickListener(new OnLongClickListener() {
      @Override public boolean onLongClick(View v) {
        ErrorMessageMonitor.getsInstance().toggleEngMode();
        return true;
      }
    });

  }

  @Override protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
    super.onLayout(changed, left, top, right, bottom);
    if (changed) {
      int width = right - left;
      int height = bottom - top;
      ecgDraw.layout(width, height / 2);
      ppgDraw.layout(width, height / 2);
      initDataSubscribe();
    }
  }

  private void initDataSubscribe() {
    mSubscriptions.clear();
    mSubscriptions.add(RxBus.getInstance()
        .toObservable(EKGData.class)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<EKGData>() {
          private long ecgTimeStamp = 0;
          private ECGFilterService ecgFilterService = new ECGFilterService();

          private void receiveECG(int value) {
            if (ecgTimeStamp == 0) {
              ecgTimeStamp = System.currentTimeMillis();
            }
            float mv = DatatypeConverter.ecgConvertToMv(value);
            float filtedmv = ecgFilterService.filter(mv);
            ecgTimeStamp += 8;
            addECG(filtedmv, ecgTimeStamp);
          }

          @Override public void call(EKGData ekgData) {
            receiveECG(ekgData.get(3));
            receiveECG(ekgData.get(7));
            receiveECG(ekgData.get(11));
          }
        }));

    mSubscriptions.add(RxBus.getInstance()
        .toObservable(BTBaseData.class)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<BTBaseData>() {
          private int ppgDataCount = 0;
          private float delta;
          private float baseline;
          private float min, max;
          private long ppgTimeStamp = 0;
          private PPGFilterService ppgFilterService = new PPGFilterService();

          private void receivePPG(int value) {
            if (ppgTimeStamp == 0) {
              ppgTimeStamp = System.currentTimeMillis();
            }

            float mv = DatatypeConverter.ppg1ConvertToMv(value);
            float filtereddmv = ppgFilterService.filter(mv);
            float drawMv = filtereddmv;

            ppgDataCount++;
            int stage = ppgDataCount / 500;
            if (ppgDataCount % 500 == 1 && stage > 0) {
              min = filtereddmv;
              max = filtereddmv;
            } else if (ppgDataCount == 126) {
              min = filtereddmv;
              max = filtereddmv;
            }

            if (ppgDataCount > 125) {
              min = Math.min(min, filtereddmv);
              max = Math.max(max, filtereddmv);
            }
            if (ppgDataCount % 500 == 0) {
              delta = max - min;
              baseline = (max + min) / 2;
            }
            if (stage > 0) {
              //drawMv = (filtedmv * 1.875f / (delta)) - baseline + 1 + 0.0625f;
              drawMv = (filtereddmv * 1.5f / (delta)) - 0.5f;
            }
            //  Log.v("ppg_data", String.format("raw:%s\tmv:%f\tfilteredMv:%f\tdrawMv:%f\tmin:%f\tmax:%f\tdelta:%f\tbaseline:%f",dataPair.second,mv, filtereddmv,drawMv,min,max,delta,baseline ));
            ppgTimeStamp += 8;
            addPPG(drawMv, ppgTimeStamp);
          }

          @Override public void call(BTBaseData btBaseData) {
            switch (btBaseData.get(BTBaseData.INDEX_SENSOR_TYPE)) {
              case BTBaseData.SENSOR_TYPE_PPG_3: {
                receivePPG(btBaseData.get(3));
                receivePPG(btBaseData.get(7));
                receivePPG(btBaseData.get(11));
                break;
              }
              case BTBaseData.SENSOR_TYPE_PPG_9: {
                receivePPG(btBaseData.get(3));
                receivePPG(btBaseData.get(5));
                receivePPG(btBaseData.get(7));
                receivePPG(btBaseData.get(9));
                receivePPG(btBaseData.get(11));
                break;
              }
            }
          }
        }));
  }

  @Override protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    int width = this.getMeasuredWidth();
    int height = this.getMeasuredHeight();
    try {
      canvas.save();
      matrix.reset();
      //matrix.setScale(1f,-1f);
      matrix.postTranslate(0, height / 4);
      canvas.concat(matrix);
      ppgDraw.draw(canvas);
    } finally {
      canvas.restore();
    }
    try {
      canvas.save();
      Matrix matrix = new Matrix();
      // matrix.setScale(1f,-1f);
      matrix.postTranslate(0, height / 4 * 3);
      canvas.concat(matrix);

      ecgDraw.draw(canvas);
    } finally {
      canvas.restore();
    }
  }

  private Paint getPaint(int type) {
    float _1dp = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1,
        getContext().getResources().getDisplayMetrics());

    Paint paint = new Paint();
    paint.setStyle(Paint.Style.FILL_AND_STROKE);
    paint.setFilterBitmap(false);

    paint.setStrokeWidth(_1dp * 1.5f);               // set the size
    paint.setDither(true);                    // set the dither to true
    paint.setStyle(Paint.Style.STROKE);       // set to STOKE
    paint.setStrokeJoin(Paint.Join.ROUND);    // set the join to round you want
    //     paint.setStrokeCap(Paint.Cap.ROUND);      // set the paint cap to round too
    paint.setPathEffect(new CornerPathEffect(_1dp * 2f));   // set the path effect when they join.
    paint.setAntiAlias(true);

    switch (type) {
      case TYPE_ECG:
        paint.setColor(getContext().getResources().getColor(R.color.mtk_blue));
        break;
      case TYPE_PPG:
        paint.setColor(getContext().getResources().getColor(R.color.mtk_orange));
        break;
    }

    return paint;
  }

  private void addECG(float mv, long timeStamp) {
    ecgDraw.addECG(mv, timeStamp);
    invalidate();
  }

  private void addPPG(float mv, long timeStamp) {
    ppgDraw.addECG(mv, timeStamp);
    invalidate();
  }

  public void reset() {
    ecgDraw.reset();
    ppgDraw.reset();
  }

  public void subscribeData(Observable observable) {
  }

  @Override protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    mSubscriptions.clear();
  }
}
