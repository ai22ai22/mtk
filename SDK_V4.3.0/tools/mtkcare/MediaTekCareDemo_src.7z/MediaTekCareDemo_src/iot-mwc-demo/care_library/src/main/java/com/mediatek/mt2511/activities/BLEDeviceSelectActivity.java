package com.mediatek.mt2511.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.bluetooth.BLEDeviceFactory;
import com.mediatek.mt2511.fragments.BLEDevicesFragment;
import com.mediatek.iot.Device;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;

/**
 * Created by MTK40526 on 3/18/2016.
 */
public class BLEDeviceSelectActivity extends FragmentActivity {
  private Device mBLEDevice = BLEDeviceFactory.getBLEDevice();
  private CompositeSubscription mSubscriptions = new CompositeSubscription();

  @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    setContentView(R.layout.activity_bltdevic_eselect);
    BLEDevicesFragment devicesFragment =
        (BLEDevicesFragment) getSupportFragmentManager().findFragmentById(
            R.id.fragment_devicesList);

    final View loadingView = findViewById(R.id.layout_loading);
    final View deviceView = findViewById(R.id.layout_devicesList);
    mSubscriptions.add(mBLEDevice.getStateObservable()
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<Integer>() {
          @Override public void call(Integer state) {
            if (Device.STATE_CONNECTING == state) {
              loadingView.setVisibility(View.VISIBLE);
              deviceView.setVisibility(View.GONE);
            } else {
              loadingView.setVisibility(View.GONE);
              deviceView.setVisibility(View.VISIBLE);
            }
            //  loadingView.setVisibility(integer == DeviceManager.CONNECT_STATUS_CONNECTING? View.VISIBLE:View.GONE);
            if (state == Device.STATE_CONNECTED) {
              finish();
            }
          }
        }));
      /*  mSubscriptions.add(devicesFragment.getDeviceInfo()
              .observeOn(AndroidSchedulers.mainThread())
              .subscribe(new Action1<Device>() {
                  @Override
                  public void call(Device o) {
                      connect(o.getMacAddress());
                  }
              }));

        mSubscriptions.add(mDeviceManager.getStatus()
              .observeOn(AndroidSchedulers.mainThread())
              .subscribe(new Subscriber<Integer>() {
                  @Override
                  public void onCompleted() {
                      hideLoadingFragment();
                  }

                  @Override
                  public void onError(Throwable e) {
                      Toast.makeText(getApplication(),e.getMessage(),Toast.LENGTH_LONG).show();
                      e.printStackTrace();
                  }

                  @Override
                  public void onNext(Integer integer) {
                      if(integer == DeviceManager.CONNECT_STATUS_CONNECTED){
                          setResult(integer);
                          finish();
                      }
                  }
              }));*/
  }

  private void connect(String macAddress) {
 /*       mDeviceManager.connect(macAddress);
        FragmentTransaction transaction =getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.layout_loading, new LoadingFragment(), LoadingFragment.TAG);
        transaction.commit();
        findViewById(R.id.layout_loading).setVisibility(View.VISIBLE);*/

  }

  private void hideLoadingFragment() {
/*        findViewById(R.id.layout_loading).setVisibility(View.GONE);
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(LoadingFragment.TAG);
        if(fragment != null) {
            getSupportFragmentManager().beginTransaction().remove(fragment).commit();
        }*/
  }

  @Override protected void onDestroy() {
    super.onDestroy();
    mSubscriptions.clear();
  }
}
