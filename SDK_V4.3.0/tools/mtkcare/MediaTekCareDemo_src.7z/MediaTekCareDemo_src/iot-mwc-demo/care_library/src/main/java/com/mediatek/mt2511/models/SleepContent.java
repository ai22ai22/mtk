package com.mediatek.mt2511.models;

import com.mediatek.mt2511.BuildConfig;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.entity.StagesChartEntity;
import com.mediatek.mt2511.models.entity.StagesChartEntity.Chart.BspMeta;
import com.mediatek.mt2511.models.entity.StagesChartEntity.Chart.Data;
import com.mediatek.mt2511.utils.UIUtils;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter public class SleepContent {

  private int efficiency;
  private String asleepDate;  // "yyyy/MM/dd HH:mm"
  private String awakeDate;   // "yyyy/MM/dd HH:mm"
  private Time duration;
  private Time asleepTime;

  private Stage light;
  private Stage deep;
  private Stage rem;

  private ChartData chartData;    // time: "MM-dd HH:mm:ss"

  @Getter(AccessLevel.NONE) private String yearString;

  public SleepContent(StagesChartEntity entity) {
    StagesChartEntity.Chart chart = entity.getCharts().get(0);
    BspMeta meta = chart.getBspMeta();
    BspMeta.Ratios ratios = meta.getRatios();
    Data data = chart.getData();

    this.efficiency = UIUtils.roundDown(meta.getSleepEfficiency());
    this.duration = convertToTime(meta.getSleepDuration());
    this.asleepTime = convertToTime(meta.getAsleepTime());

    this.light = convertToStage(Stage.LIGHT, ratios.getLight());
    this.deep = convertToStage(Stage.DEEP, ratios.getDeep());
    this.rem = convertToStage(Stage.REM, ratios.getREM());

    this.yearString = meta.getTime().substring(0, 4);
    initChart(data);
  }

  @AllArgsConstructor @Getter public static class Time {
    private int hour;
    private int minute;

    public String toDurationString() {
      return (this.hour == 0) ?
          String.format("%d min", this.minute)
          : String.format("%1$d:%2$d", this.hour, this.minute);
    }

    public String toTimeString() {
      return this.hour + ":" + this.minute;
    }
  }

  @AllArgsConstructor @Getter public static class Stage {
    private int type;
    private Time time;
    private String percentage;

    public static final int AWAKE = 0;
    public static final int REM = -1;
    public static final int LIGHT = -2;
    public static final int DEEP = -3;

    public String getStageText() {
      switch (this.type) {
        case AWAKE: return "Wake";
        case REM: return "REM";
        case LIGHT: return "Light";
        case DEEP: return "Deep";
        default: return "";
      }
    }

    public int getStageColor() {
      switch (this.type) {
        case AWAKE: return R.color.gs_red;
        case REM: return R.color.gs_yellow;
        case LIGHT: return R.color.gs_green;
        case DEEP: return R.color.gs_blue;
        default: return -9;
      }
    }
  }

  @AllArgsConstructor @Getter public static class ChartData {
    private List<Integer> stages;
    private List<String> times;
  }

  private Time convertToTime(List<String> list) {
    return new Time(Integer.parseInt(list.get(0)),
        Integer.parseInt(list.get(1)));
  }

  private Stage convertToStage(int stage, List<String> list) {
    return new Stage(stage, convertToTime(list), list.get(2));
  }

  @SuppressWarnings("unchecked")
  private void initChart(StagesChartEntity.Chart.Data data) throws ClassCastException {
    if (BuildConfig.DEBUG && !data.getXFormat().equals("%m-%d %H:%M:%S")) {
      //GsLog.e(new GsException("Date Format error"));
    }
    List<String> times = (List<String>) data.getColumns().get(1);
    this.asleepDate = formatTimeStamp(times.get(1));
    this.awakeDate = formatTimeStamp(times.get(times.size() - 1));

    List<Object> ss = (List<Object>) data.getColumns().get(0);
    List<Number> numberSleepStages = (List<Number>)(List<?>) ss.subList(1, ss.size());
    List<Integer> sleepStages = new ArrayList<>();
    for (Number stage : numberSleepStages) {
      sleepStages.add(stage.intValue());
    }

    this.chartData = new ChartData(
        sleepStages,
        times.subList(1, times.size())
    );
  }

  private String formatTimeStamp(String time) {
    String inputTime = this.yearString + "-" + time;
    String inputFormat = "yyyy-" + "MM-dd HH:mm:ss";
    String outputFormat = "yyyy/MM/dd HH:mm";
    SimpleDateFormat inputSdf = new SimpleDateFormat(inputFormat, Locale.getDefault());
    SimpleDateFormat outputSdf = new SimpleDateFormat(outputFormat, Locale.getDefault());
    try {
      Date d = inputSdf.parse(inputTime);
      return outputSdf.format(d);
    } catch (ParseException e) {
//      GsLog.e(e);
      return "";
    }
  }
}
