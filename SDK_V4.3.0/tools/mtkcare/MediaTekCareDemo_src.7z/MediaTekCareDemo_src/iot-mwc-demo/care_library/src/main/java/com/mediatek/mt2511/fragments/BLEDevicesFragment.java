package com.mediatek.mt2511.fragments;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import com.mediatek.iot.BluetoothDeviceInfo;
import com.mediatek.iot.Device;
import com.mediatek.iot.Scanner;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.bluetooth.BLEDeviceFactory;
import java.util.ArrayList;
import java.util.HashMap;
import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.subscriptions.CompositeSubscription;

/**
 * Created by MTK40526 on 4/1/2016.
 */
public class BLEDevicesFragment extends Fragment {
  ListView mListDevice;
  ImageView mImgBlueToothConnect;
  TextView mTxtLoading;
  private Device mBLEDevice = BLEDeviceFactory.getBLEDevice();
  private Scanner mBLEScanner = BLEDeviceFactory.getBLEScanner();
  private ArrayList<HashMap<String, String>> mDeviceDataList;
  private SimpleAdapter mListAdapter;
  private CompositeSubscription mCompositeSubscription = new CompositeSubscription();
  private Subscription mScanSubscription;

  public BLEDevicesFragment() {
  }

  @Override public void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
  }

  @Nullable @Override public View onCreateView(LayoutInflater inflater, ViewGroup container,
      Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_bledevices, container, false);
    initView(view);

    mDeviceDataList = new ArrayList<HashMap<String, String>>();
    mListAdapter = new SimpleAdapter(getActivity(), mDeviceDataList, R.layout.list_view_item_device,
        new String[] { "deviceName" }, new int[] { android.R.id.text1 });
    mListDevice.setAdapter(mListAdapter);
    return view;
  }

  private void initView(View view) {
    mListDevice = (ListView) view.findViewById(R.id.list_device);
    mImgBlueToothConnect = (ImageView) view.findViewById(R.id.bluetooth_connect);
    mTxtLoading = (TextView) view.findViewById(R.id.txt_loading);
    view.findViewById(R.id.connect_btn).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        doConnect();
      }
    });
    view.findViewById(R.id.refresh_btn).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        scan();
      }
    });
  }

  @Override public void onDestroy() {
    super.onDestroy();
    mCompositeSubscription.clear();
  }

  @Override public void onResume() {
    super.onResume();
    scan();
  }

  private void scan() {
    mDeviceDataList.clear();
    mBLEScanner.stopScan();
    ((AnimationDrawable) mImgBlueToothConnect.getDrawable()).start();
    if (mScanSubscription != null) {
      mScanSubscription.unsubscribe();
    }
    mTxtLoading.setVisibility(View.VISIBLE);
    mScanSubscription = mBLEScanner.startScan()
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<BluetoothDeviceInfo>() {
          @Override public void onCompleted() {
            ((AnimationDrawable) mImgBlueToothConnect.getDrawable()).stop();
          }

          @Override public void onError(Throwable e) {
            ((AnimationDrawable) mImgBlueToothConnect.getDrawable()).stop();
            Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
          }

          @Override public void onNext(BluetoothDeviceInfo deviceInfo) {
            mTxtLoading.setVisibility(View.INVISIBLE);
            HashMap<String, String> data = new HashMap<String, String>();
            data.put("macAddress", deviceInfo.getMacAddress());
            data.put("deviceName", deviceInfo.getName());
            if (!mDeviceDataList.contains(data)) {
              mDeviceDataList.add(data);
              mListAdapter.notifyDataSetChanged();
            }
          }
        });
    mCompositeSubscription.add(mScanSubscription);
  }

  void doConnect() {
    int position = mListDevice.getCheckedItemPosition();
    if (position > -1 && position < mDeviceDataList.size()) {
      mBLEDevice.connect(mDeviceDataList.get(position).get("macAddress"));
    }
  }
}
