package com.mediatek.mt2511.branch;

import android.support.v4.app.Fragment;
import com.mediatek.mt2511.fragments.FormFragment;

public interface IMContext {
  String getEndPoint();

  String getApplicationId();

  String[] getFeatureFragment();

  boolean isSelfSignedCA();

  FormFragment[] createAddRecordFragments();

  boolean isForceAddRecord();
}
