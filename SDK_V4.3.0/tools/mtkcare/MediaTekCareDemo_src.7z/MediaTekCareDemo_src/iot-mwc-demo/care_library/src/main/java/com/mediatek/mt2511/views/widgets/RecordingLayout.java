package com.mediatek.mt2511.views.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.activities.DataBoardActivity;
import com.mediatek.mt2511.services.RecordService;
import com.mediatek.mt2511.services.UserSession;
import java.io.IOException;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.subscriptions.CompositeSubscription;
import timber.log.Timber;

public class RecordingLayout extends LinearLayout {
  private ClockTextView mClockView;
  private Button mBtnRecordSwitch;
  private CompositeSubscription mSubscriptions = new CompositeSubscription();

  public RecordingLayout(Context context) {
    super(context);
    init();
  }

  public RecordingLayout(Context context, AttributeSet attrs) {
    super(context, attrs);
    init();
  }

  public RecordingLayout(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    init();
  }

  private void init() {
    initView();
    initEvent();
  }

  private void initEvent() {
    mBtnRecordSwitch.setOnClickListener(new OnClickListener() {
      @Override public void onClick(View v) {
        if (UserSession.getInstance().getRecordInfo() == null) {
          if (getContext() instanceof DataBoardActivity) {
            ((DataBoardActivity) getContext()).requestAddRecord(null, false);
            return;
          }
        }
        recordSwitch();
      }
    });
  }

  void recordSwitch() {
    try {
      if (!RecordService.getInstance().isInRecording()) {
        RecordService.getInstance().startRecord();
        mBtnRecordSwitch.setText(R.string.btn_stop);
      } else {
        RecordService.getInstance().stopRecord();
        mBtnRecordSwitch.setText(R.string.btn_start);
      }
    } catch (IOException e) {
      Timber.e(e);
      Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_LONG).show();
      mBtnRecordSwitch.setText(R.string.btn_start);
    }
    if (!RecordService.getInstance().isInRecording() && RecordService.getInstance().isInTemp()) {
      mBtnRecordSwitch.setEnabled(false);
      mSubscriptions.add(
          RecordService.getInstance().confirmSave(getContext()).subscribe(new Subscriber<String>() {
            @Override public void onCompleted() {
              mBtnRecordSwitch.setEnabled(true);
            }

            @Override public void onError(Throwable e) {
              Timber.e(e);
              Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_LONG).show();
              mBtnRecordSwitch.setEnabled(true);
            }

            @Override public void onNext(String s) {

            }
          }));
    }
  }

  private void initView() {
    inflate(getContext(), R.layout.view_recording_layout, this);
    mClockView = (ClockTextView) findViewById(R.id.txt_clock);
    mBtnRecordSwitch = (Button) findViewById(R.id.btn_record_switch);
  }

  @Override protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    subscribeData();
  }

  private void subscribeData() {
    mSubscriptions.add(RecordService.getInstance()
        .getRecordingObservable()
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Subscriber<Boolean>() {
          @Override public void onCompleted() {

          }

          @Override public void onError(Throwable e) {
            Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_LONG).show();
            Timber.e(e);
          }

          @Override public void onNext(Boolean inRecording) {
            if (!inRecording) {
              mBtnRecordSwitch.setText(R.string.btn_start);
              mClockView.stop();
            } else {
              mBtnRecordSwitch.setText(R.string.btn_stop);
              mClockView.start(RecordService.getInstance().getStartTimeStamp());
            }
          }
        }));
  }

  @Override protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    mSubscriptions.clear();
  }
}
