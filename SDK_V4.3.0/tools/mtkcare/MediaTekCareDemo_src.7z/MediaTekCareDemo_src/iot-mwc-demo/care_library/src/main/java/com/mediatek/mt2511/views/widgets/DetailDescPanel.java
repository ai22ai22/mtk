package com.mediatek.mt2511.views.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.mediatek.mt2511.R;
import com.mediatek.mt2511.models.SleepContent;
import com.mediatek.mt2511.models.entity.ReportDetailEntity;
import com.mediatek.mt2511.utils.DateUtils;

public class DetailDescPanel extends LinearLayout {

  TextView tv_detail_asleep_date;
  TextView tv_detail_asleep_time;
  TextView tv_detail_awake_date;
  TextView tv_detail_awake_time;
  SleepStatusTitle title_deep;
  SleepStatusTitle title_light;
  SleepStatusTitle title_rem;
  SleepStatusBar bar_deep;
  SleepStatusBar bar_light;
  SleepStatusBar bar_rem;

  TextView tv_detail_comment;

  public DetailDescPanel(Context context) {
    super(context);
    initViews();
  }

  public DetailDescPanel(Context context, AttributeSet attrs) {
    super(context, attrs);
    initViews();
  }

  public DetailDescPanel(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    initViews();
  }

  private void initViews() {
    View view = inflate(getContext(), R.layout.detail_desc_panel, this);
    tv_detail_asleep_date = (TextView) findViewById(R.id.detail_asleep_date);
    tv_detail_asleep_time = (TextView) findViewById(R.id.detail_asleep_time);
    tv_detail_awake_date = (TextView) findViewById(R.id.detail_awake_date);
    tv_detail_awake_time = (TextView) findViewById(R.id.detail_awake_time);
    title_deep = (SleepStatusTitle) findViewById(R.id.status_deep_title);
    title_light = (SleepStatusTitle) findViewById(R.id.status_light_title);
    title_rem = (SleepStatusTitle) findViewById(R.id.status_rem_title);
    bar_deep = (SleepStatusBar) findViewById(R.id.status_deep_bar);
    bar_light = (SleepStatusBar) findViewById(R.id.status_light_bar);
    bar_rem = (SleepStatusBar) findViewById(R.id.status_rem_bar);
    tv_detail_comment = (TextView) findViewById(R.id.detail_comment);
  }

  public void setData(ReportDetailEntity entity) {
    tv_detail_asleep_date.setText(DateUtils.formatApiDate(entity.getAsleepAt()));
    tv_detail_asleep_time.setText(DateUtils.formatApiTime(entity.getAsleepAt()));
    tv_detail_awake_date.setText(DateUtils.formatApiDate(entity.getAwakeAt()));
    tv_detail_awake_time.setText(DateUtils.formatApiTime(entity.getAwakeAt()));

    SleepContent content = entity.getSleepContent();
    title_deep.setTitle(content.getDeep());
    bar_deep.drawViewByStage(content.getDeep());

    title_light.setTitle(content.getLight());
    bar_light.drawViewByStage(content.getLight());

    title_rem.setTitle(content.getRem());
    bar_rem.drawViewByStage(content.getRem());

    tv_detail_comment.setText(entity.getComment());
  }
}
