package com.mediatek.mt2511.network;

import com.facebook.stetho.okhttp.StethoInterceptor;
import com.squareup.okhttp.OkHttpClient;
import retrofit.RestAdapter;
import retrofit.client.OkClient;

/**
 * Created by MTK40526 on 5/13/2016.
 */
public class MySOAApi {
  private static MySOAApi s_instance;
  private SOAService soaService;
  private MySOAApi(){
    RestAdapter restAdapter = buildRestAdapter();
    soaService = restAdapter.create(SOAService.class);
  }

  public static SOAService getApiInstance(){
    if (s_instance == null){
      s_instance = new MySOAApi();
    }
    return s_instance.soaService;
  }
  private RestAdapter buildRestAdapter() {
    OkHttpClient httpClient = new OkHttpClient();
    httpClient.networkInterceptors().add(new StethoInterceptor());

    return new RestAdapter.Builder()
        .setEndpoint("https://mds.mediatek.com/dev")
        // Out-comment the following line if you want to use the default converter Gson.
        .setConverter(new GsonConverter())
        .setClient(new OkClient(httpClient))
        .build();
  }

}
