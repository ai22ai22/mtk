package com.mediatek.mt2511.interfaces;

public interface ShowProfile {
  void showProgressLoading();
  void dismissProgressLoading(Throwable e);
  void setCurrentProfileComplete(String userId);
}
