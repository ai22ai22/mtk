package com.mediatek.mt2511.models;

import com.mediatek.mt2511.models.pojo.RecordResult;
import com.mediatek.mt2511.models.pojo.UploadCareRequest;
import com.mediatek.mt2511.network.MyProjectApi;
import com.mediatek.mt2511.services.UserSession;
import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

public class ApiModel {

  public Observable<String> requestApi(final PersonalProfileEntity entity) {
    final UploadCareRequest recordRequest = new UploadCareRequest();
    recordRequest.age = entity.getAge();
    recordRequest.userNickname = entity.getUserId();
    recordRequest.gender = entity.getGender() == 1 ? "M" : "F";
    recordRequest.comment =
        "This chart represent the physiological age of yourscomparing with others ";
    return Observable.create(new Observable.OnSubscribe<String>() {
      @Override public void call(final Subscriber<? super String> subscriber) {
        MyProjectApi.getIoTService()
            .createRecord(recordRequest)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(new Subscriber<RecordResult>() {
              @Override public void onCompleted() {
                subscriber.onCompleted();
              }

              @Override public void onError(Throwable e) {
                subscriber.onError(e);
                Timber.w(e, e.getMessage());
              }

              @Override public void onNext(RecordResult recordResult) {
                UserSession.RecordInfo recordInfo = new UserSession.RecordInfo();
                recordInfo.recordId = recordResult.recordId;
                recordInfo.userId = recordResult.userNickname;
                recordInfo.age = recordResult.age;
                recordInfo.gender = entity.getGender() == 1 ? "M" : "F";
                recordInfo.weight = entity.getWeight();
                recordInfo.height = entity.getHeight();
                recordInfo.armLen = entity.getArmLength();
                UserSession.getInstance().saveRecordInfo(recordInfo);
                subscriber.onNext("");
              }
            });
      }
    });
  }
}
