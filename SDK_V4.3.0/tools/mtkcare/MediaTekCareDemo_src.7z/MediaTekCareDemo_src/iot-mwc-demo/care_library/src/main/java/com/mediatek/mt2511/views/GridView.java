package com.mediatek.mt2511.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import com.mediatek.mt2511.R;

/**
 * Created by MTK40526 on 1/29/2016.
 */
public class GridView extends View {


    private final float m1dp;
    private float mCellSize = 0;
    private float mWidth = 0;
    private float mXMid = 0;
    private float mYMid = 0;
    private float mHeight = 0;
    private Paint mPaint = new Paint();
    private int mCellHeight =0 ;

    public GridView(Context context) {
        this(context, null);
    }

    public GridView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public GridView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        //int color = context.getResources().getColor(R.color.mtk_gold);
        int color = context.getResources().getColor(R.color.hr_grid_line_color);
        m1dp = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1, context.getResources().getDisplayMetrics());
        mPaint.setColor(color);
        mPaint.setAlpha((color & 0xFF000000) >> 24);


    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        mCellSize = (int) Math.max((float)right / 4f / 5f / 5f, m1dp *2);
        mCellHeight = (int) Math.max((float)bottom / 4f/ 2f/ 5f, m1dp *2);
        mWidth = right;
        mXMid = mWidth / 2f;
        mHeight = bottom;
        mYMid = mHeight / 2f;
        if (changed){
            invalidate();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int n = (int) Math.ceil(mXMid / mCellSize);
        for(int i = 0 - n; i< n ; ++i){
            float p = 0.5f;
            if(i % 25 ==0){
                p = 1.5f;
            }else if (i % 5 == 0){
                p = 1f;
            }
            mPaint.setStrokeWidth(p * m1dp);
            canvas.drawLine(mXMid - i * mCellSize, 0, mXMid - i * mCellSize, mHeight, mPaint);
        }
        //mPaint.setARGB(255,0,0,0);
        n = (int) Math.ceil(mYMid / mCellHeight);
        for(int i = 0 - n; i< n ; ++i){
            float p = 0.5f;
            if(i % 25 ==0){
                p = 1.5f;
            }else if (i % 5 == 0){
                p = 1f;
            }
            mPaint.setStrokeWidth( (i % 5 == 0 ? 1 : 0.5f) * m1dp);
            canvas.drawLine(0, mYMid - i * mCellHeight,mWidth,  mYMid - i * mCellHeight, mPaint);
        }
        mPaint.setStrokeWidth( 1.5f * m1dp);
        canvas.drawLine(0,mYMid, mWidth, mYMid,mPaint);
        canvas.drawLine(mXMid, 0, mXMid, mHeight,mPaint);
    }
}
