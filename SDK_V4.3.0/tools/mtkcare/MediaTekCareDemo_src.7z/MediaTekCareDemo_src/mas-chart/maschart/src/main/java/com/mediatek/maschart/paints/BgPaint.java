package com.mediatek.maschart.paints;

import android.support.annotation.ColorRes;

public class BgPaint extends ColorPaint {

  public BgPaint(@ColorRes int colorResId) {
    super(colorResId);
  }
}

