package com.mediatek.maschart.barchart;

import com.mediatek.maschart.utils.UiUtils;

public class BarChartConstant {

  public float getBar_region_width() {
    return bar_region_width;
  }

  public float getChart_width() {
    return chart_width;
  }

  public float getChart_height() {
    return chart_height;
  }

  public float getMargin_left() {
    return margin_left;
  }

  public float getMargin_right() {
    return margin_right;
  }

  public float getMargin_top() {
    return margin_top;
  }

  public float getMargin_bottom() {
    return margin_bottom;
  }

  public float getBar_corner_radius() {
    return bar_corner_radius;
  }

  public float getLast_bar_margin_right() {
    return last_bar_margin_right;
  }

  public float getLast_bar_margin_left() {
    return last_bar_margin_left;
  }

  public float getInner_percentage_margin_top() {
    return inner_percentage_margin_top;
  }

  public float getInner_percentage_margin_bottom() {
    return inner_percentage_margin_bottom;
  }

  public float getDate_margin_axis() {
    return date_margin_axis;
  }

  public float getLine_stroke_width() {
    return line_stroke_width;
  }

  public float getText_size() {
    return text_size;
  }

  public float getBar_inner_text_size() {
    return bar_inner_text_size;
  }

  public float getText_size_percentage() {
    return text_size_percentage;
  }

  public float getTitle_margin_bottom() {
    return title_margin_bottom;
  }

  private float bar_region_width;
  private float chart_width;
  private float chart_height;
  private float margin_left;
  private float margin_right;
  private float margin_top;
  private float margin_bottom;
  private float bar_corner_radius;
  private float last_bar_margin_right;
  private float last_bar_margin_left;
  private float inner_percentage_margin_top;
  private float inner_percentage_margin_bottom;
  private float date_margin_axis;
  private float line_stroke_width;
  private float text_size;
  private float bar_inner_text_size;
  private float text_size_percentage;
  private float title_margin_bottom;

  public BarChartConstant() {
    final float BAR_REGION_WIDTH = 288;
    final float CHART_WIDTH = 320;
    final float CHART_HEIGHT = 132;
    final float MARGIN_LEFT = 12;
    final float MARGIN_RIGHT = 12;
    final float MARGIN_TOP = 42;
    final float MARGIN_BOTTOM = 34;
    final float BAR_CORNER_RADIUS = 3;
    final float LAST_BAR_MARGIN_LEFT = 23;
    final float LAST_BAR_MARGIN_RIGHT = 45;
    final float PERCENTAGE_MARGIN_TOP = 8;
    final float PERCENTAGE_MARGIN_BOTTOM = 8;
    final float DATE_MARGIN_AXIS = 8;
    final float LINE_STROKE_WIDTH = 1;
    final float TITLE_MARGIN_BOTTOM = 8;
    final int TEXT_SIZE = 12;
    final int BAR_INNER_TEXT_SIZE = 10;
    final int TEXT_SIZE_PERCENTAGE = 18;

    bar_region_width = UiUtils.dpToPx(BAR_REGION_WIDTH);
    chart_width = UiUtils.dpToPx(CHART_WIDTH);
    chart_height = UiUtils.dpToPx(CHART_HEIGHT);

    margin_left = UiUtils.dpToPx(MARGIN_LEFT);
    margin_right = UiUtils.dpToPx(MARGIN_RIGHT);
    margin_top = UiUtils.dpToPx(MARGIN_TOP);
    margin_bottom = UiUtils.dpToPx(MARGIN_BOTTOM);

    inner_percentage_margin_top = UiUtils.dpToPx(PERCENTAGE_MARGIN_TOP);
    inner_percentage_margin_bottom = UiUtils.dpToPx(PERCENTAGE_MARGIN_BOTTOM);
    date_margin_axis = UiUtils.dpToPx(DATE_MARGIN_AXIS);

    bar_corner_radius = UiUtils.dpToPx(BAR_CORNER_RADIUS);
    last_bar_margin_right = UiUtils.dpToPx(LAST_BAR_MARGIN_RIGHT);
    last_bar_margin_left = UiUtils.dpToPx(LAST_BAR_MARGIN_LEFT);

    line_stroke_width = UiUtils.dpToPx(LINE_STROKE_WIDTH);

    title_margin_bottom = UiUtils.dpToPx(TITLE_MARGIN_BOTTOM);
    text_size = UiUtils.spToPx(TEXT_SIZE);
    bar_inner_text_size = UiUtils.spToPx(BAR_INNER_TEXT_SIZE);
    text_size_percentage = UiUtils.spToPx(TEXT_SIZE_PERCENTAGE);
  }
}
