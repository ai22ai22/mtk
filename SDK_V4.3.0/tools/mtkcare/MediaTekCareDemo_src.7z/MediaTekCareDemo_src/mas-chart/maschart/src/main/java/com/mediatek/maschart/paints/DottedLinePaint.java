package com.mediatek.maschart.paints;

import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.PathEffect;
import android.support.annotation.ColorRes;

public class DottedLinePaint extends ColorPaint {

  public DottedLinePaint(@ColorRes int colorResId, float strokeWidth) {
    this(colorResId, strokeWidth, Alpha.OPAQUE);
  }

  public DottedLinePaint(@ColorRes int colorResId, float strokeWidth, int alpha) {
    super(colorResId, alpha);
    setStrokeWidth(strokeWidth);
    setAlpha(alpha);
    setStyle(Paint.Style.STROKE);
    PathEffect effects = new DashPathEffect(new float[] {10, 5, 10, 5}, 1);
    setPathEffect(effects);
  }
}
