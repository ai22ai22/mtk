package com.mediatek.maschart.axis;

import com.mediatek.maschart.utils.UiUtils;

public class AxisConstant {
  public float getBar_region_width() {
    return bar_region_width;
  }

  public float getAxis_text_size() {
    return axis_text_size;
  }

  public float getAxis_margin_left() {
    return axis_margin_left;
  }

  public float getAxis_margin_right() {
    return axis_margin_right;
  }

  public float getAxis_margin_bottom() {
    return axis_margin_bottom;
  }

  public float getDate_margin_axis() {
    return date_margin_axis;
  }

  public float getLast_date_margin_right() {
    return last_date_margin_right;
  }

  public float getAxis_text_margin_line() {
    return axis_text_margin_line;
  }

  public float getDay_time_first_interval() {
    return day_time_first_interval;
  }

  public float getDay_time_second_interval() {
    return day_time_second_interval;
  }

  public float getDay_time_margin_left() {
    return day_time_margin_left;
  }

  public float getGoal_line_margin_right() {
    return goal_line_margin_right;
  }

  public float getGoal_line_stroke_width() {
    return goal_line_stroke_width;
  }

  public float getGoal_text_bg_width() {
    return goal_text_bg_width;
  }

  public float getGoal_text_bg_height() {
    return goal_text_bg_height;
  }

  public float getGoal_text_bg_triangle_side_length() {
    return goal_text_bg_triangle_side_length;
  }

  public float getGoal_text_bg_corner_radius() {
    return goal_text_bg_corner_radius;
  }

  private float bar_region_width;
  private float axis_text_size;
  private float axis_margin_left;
  private float axis_margin_right;
  private float axis_margin_bottom;
  private float date_margin_axis;
  private float last_date_margin_right;
  private float axis_text_margin_line;
  private float day_time_first_interval;
  private float day_time_second_interval;
  private float day_time_margin_left;
  private float goal_line_margin_right;
  private float goal_line_stroke_width;
  private float goal_text_bg_width;
  private float goal_text_bg_height;
  private float goal_text_bg_triangle_side_length;
  private float goal_text_bg_corner_radius;

  public AxisConstant() {
    final float BAR_REGION_WIDTH = 288;
    final int AXIS_TEXT_SIZE = 12;
    final float AXIS_MARGIN_LEFT = 12;
    final float AXIS_MARGIN_RIGHT = 12;
    final float AXIS_MARGIN_BOTTOM = 34;
    final float DATE_MARGIN_AXIS = 22;
    final float LAST_DATE_MARGIN_RIGHT = 45;
    final float AXIS_TEXT_MARGIN_LINE = 3;

    final float DAY_TIME_FIRST_INTERVAL = 132;
    final float DAY_TIME_SECOND_INTERVAL = 120;
    final float DAY_TIME_MARGIN_LEFT = 16;

    final float GOAL_LINE_MARGIN_RIGHT = 32;
    final float GOAL_LINE_STROKE_WIDTH = 2;
    final float GOAL_TEXT_BG_WIDTH = 27;
    final float GOAL_TEXT_BG_HEIGHT = 14;
    final float GOAL_TEXT_BG_TRIANGLE_SIDE_LENGTH = 5;
    final float GOAL_TEXT_BG_CORNER_RADIUS = 2;

    bar_region_width = UiUtils.dpToPx(BAR_REGION_WIDTH);
    axis_text_size = UiUtils.spToPx(AXIS_TEXT_SIZE);
    axis_margin_left = UiUtils.dpToPx(AXIS_MARGIN_LEFT);
    axis_margin_right = UiUtils.dpToPx(AXIS_MARGIN_RIGHT);
    axis_text_margin_line = UiUtils.dpToPx(AXIS_TEXT_MARGIN_LINE);
    axis_margin_bottom = UiUtils.dpToPx(AXIS_MARGIN_BOTTOM);
    date_margin_axis = UiUtils.dpToPx(DATE_MARGIN_AXIS);
    last_date_margin_right = UiUtils.dpToPx(LAST_DATE_MARGIN_RIGHT);

    day_time_first_interval = UiUtils.dpToPx(DAY_TIME_FIRST_INTERVAL);
    day_time_second_interval = UiUtils.dpToPx(DAY_TIME_SECOND_INTERVAL);
    day_time_margin_left = UiUtils.dpToPx(DAY_TIME_MARGIN_LEFT);

    goal_line_margin_right = UiUtils.dpToPx(GOAL_LINE_MARGIN_RIGHT);
    goal_line_stroke_width = UiUtils.dpToPx(GOAL_LINE_STROKE_WIDTH);
    goal_text_bg_width = UiUtils.dpToPx(GOAL_TEXT_BG_WIDTH);
    goal_text_bg_height = UiUtils.dpToPx(GOAL_TEXT_BG_HEIGHT);
    goal_text_bg_triangle_side_length = UiUtils.dpToPx(GOAL_TEXT_BG_TRIANGLE_SIDE_LENGTH);
    goal_text_bg_corner_radius = UiUtils.dpToPx(GOAL_TEXT_BG_CORNER_RADIUS);
  }
}