package com.mediatek.maschart.utils;

import com.mediatek.maschart.ChartsLog;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DateUtils {

  /**
   * For UI display purpose.
   * @param apiTimeStamp timestamp from api.
   * @return formatted date string.
   */
  public static String formatApiDate(String apiTimeStamp) {
    String dateSdfPattern = "yyyy/MM/dd";
    return formatTimeStampBy(dateSdfPattern, apiTimeStamp);
  }

  /**
   * For UI display purpose.
   * @param apiTimeStamp timestamp from api.
   * @return formatted time string.
   */
  public static String formatApiTime(String apiTimeStamp) {
    String timeSdfPattern = "HH:mm";
    return formatTimeStampBy(timeSdfPattern, apiTimeStamp);
  }

  private static String formatTimeStampBy(String sdfPattern, String timeStamp) {
    String apiSdfPattern = "yyyy-MM-dd'T'HH:mm:ssZ";
    return formatDate(timeStamp, apiSdfPattern, sdfPattern);
  }

  public static String formatDate(String date, String inputSdfPattern, String outputSdfPattern) {
    try {
      SimpleDateFormat inputSdf = new SimpleDateFormat(inputSdfPattern, Locale.getDefault());
      SimpleDateFormat outputSdf = new SimpleDateFormat(outputSdfPattern, Locale.getDefault());
      inputSdf.setTimeZone(parseApiTimeZone(date));
      outputSdf.setTimeZone(TimeZone.getDefault());
      Date d = inputSdf.parse(date);
      return outputSdf.format(d);
    } catch (NullPointerException | ParseException e) {
      //ChartsLog.e(e);
      return "";
    }
  }

  public static TimeZone parseApiTimeZone(String date) {
    String timeZoneOffset;
    try {
      timeZoneOffset = date.substring(date.lastIndexOf("+"));
    } catch (NullPointerException | StringIndexOutOfBoundsException e) {
      //ChartsLog.e(e);
      timeZoneOffset = "";
    }
    return TimeZone.getTimeZone("GMT" + timeZoneOffset);
  }

  public static boolean isToday(String dateString) {
    Date date = new Date();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
    String today = sdf.format(date);
    return dateString.equals(today);
  }
}
