package com.mediatek.maschart.brokenlinegraph;

import android.graphics.Canvas;
import android.support.annotation.ColorRes;
import android.support.v4.content.ContextCompat;

import com.mediatek.maschart.Charts;
import com.mediatek.maschart.R;
import com.mediatek.maschart.paints.ColorPaint;
import com.mediatek.maschart.utils.DrawUtils;

import java.util.List;

public class BrokenLine {

    public void setCanvas(Canvas canvas) {
        this.canvas = canvas;
    }

    private Canvas canvas;
    private List<Integer> pointValues;
    private List<String> pointDates;

    private int dotColor;
    private int circleColor;

    private ColorPaint p_dot;
    private ColorPaint p_circle;
    private ColorPaint p_line;

    private float points_width;
    private float points_interval;
    private float topValue;

    public void setPointColor(@ColorRes int circleColor, @ColorRes int dotColor) {
        this.circleColor = circleColor;
        this.dotColor = dotColor;
    }

    public void setBrokenLineData(List<Integer> pointValues, int topValue) {
        this.pointValues = pointValues;
        this.topValue = topValue;
    }

    public void setBrokenLineData(List<String> pointDates, List<Integer> pointValues, int topValue) {
        this.pointDates = pointDates;
        this.pointValues = pointValues;
        this.topValue = topValue;
    }

    public void draw(int chartStyle, float points_width, float points_interval) {
        this.points_width = points_width;
        this.points_interval = points_interval;

        setPaint();

        if (chartStyle == BrokenLineGraphType.DAY) {
            drawDay();
        } else if (chartStyle == BrokenLineGraphType.BP) {
            drawBp();
        } else {
            drawWeekAndMonth();
        }
    }

    private void drawDay() {
        BrokenLineGraphConstant constant = new BrokenLineGraphConstant();
        float chart_height = canvas.getHeight()
                - constant.getMargin_top()
                - constant.getMargin_bottom();
        float bottom_line_y = canvas.getHeight() - constant.getMargin_bottom();
        int hour;
        float position_x = 0;
        float position_y = 0;

        if (pointValues.get(0) >= 0) {
            hour = Integer.valueOf(DrawUtils.getHour(pointDates.get(0))).intValue();
            position_x = constant.getDay_first_point_margin_left()
                    + points_width / 2 + (points_width + points_interval) * hour;
            position_y = bottom_line_y - chart_height * pointValues.get(0) / topValue;
            drawPoint(position_x, position_y);
        }

        float last_x = position_x;
        float last_y = position_y;

        for (int i = 1; i < pointValues.size() - 1; i++) {
            if (pointValues.get(i) >= 0) {
                hour = Integer.valueOf(DrawUtils.getHour(pointDates.get(i))).intValue();
                position_x = constant.getDay_first_point_margin_left()
                        + points_width / 2 + (points_width + points_interval) * hour;
                position_y = bottom_line_y - chart_height * pointValues.get(i) / topValue;

                if (pointValues.get(i - 1) >= 0) {
                    drawLine(last_x, last_y, position_x, position_y);
                }

                drawPoint(position_x, position_y);
                last_x = position_x;
                last_y = position_y;
            }
        }

        if (pointValues.get(pointValues.size() - 1) >= 0) {
            position_x += (points_width + points_interval);
            position_y = bottom_line_y
                    - chart_height * pointValues.get(pointValues.size() - 1) / topValue;

            if (pointValues.get(pointValues.size() - 2) >= 0) {
                drawLine(last_x, last_y, position_x, position_y);
            }

            drawPoint(position_x, position_y);
        }
    }

    private void drawWeekAndMonth() {
        BrokenLineGraphConstant constant = new BrokenLineGraphConstant();
        float chart_height = canvas.getHeight()
                - constant.getMargin_top()
                - constant.getMargin_bottom();
        float bottom_line_y = canvas.getHeight() - constant.getMargin_bottom();
        float position_x = canvas.getWidth()
                - constant.getLast_point_margin_right() - points_width / 2;

        float last_x = position_x;
        float last_y = bottom_line_y - chart_height * pointValues.get(0) / topValue;
        if (pointValues.get(0) >= 0) {
            drawPoint(last_x, last_y);
        }
        position_x -= (points_width + points_interval);
        float point_height;
        float position_y = bottom_line_y;

        for (int i = 1; i < pointValues.size() - 1; i++) {
            if (pointValues.get(i) >= 0) {
                point_height = chart_height * pointValues.get(i) / topValue;
                position_y = bottom_line_y - point_height;

                if (pointValues.get(i - 1) >= 0) {
                    drawLine(last_x, last_y, position_x, position_y);
                }

                drawPoint(position_x, position_y);
            }
            last_x = position_x;
            last_y = position_y;
            position_x -= (points_width + points_interval);
        }

        if (pointValues.get(pointValues.size() - 1) >= 0) {
            point_height = chart_height * pointValues.get(pointValues.size() - 1) / topValue;
            position_y = bottom_line_y - point_height;

            if (pointValues.get(pointValues.size() - 2) >= 0) {
                drawLine(last_x, last_y, position_x, position_y);
            }

            drawPoint(position_x, position_y);
        }
    }

    private void drawBp() {
        BrokenLineGraphConstant constant = new BrokenLineGraphConstant();
        float chart_height = canvas.getHeight()
                - constant.getMargin_top()
                - constant.getMargin_bottom();
        float bottom_line_y = canvas.getHeight() - constant.getMargin_bottom();
        float position_x = 40;
        float position_y = 0;

        if (pointValues.get(0) >= 0) {
            position_y = bottom_line_y - chart_height * pointValues.get(0) / topValue;
            drawPoint(position_x, position_y);
        }

        float last_x = position_x;
        float last_y = position_y;

        for (int i = 1; i <= pointValues.size() - 1; i++) {
            if (pointValues.get(i) >= 0) {
                position_x += (points_width + points_interval);
                position_y = bottom_line_y - chart_height * pointValues.get(i) / topValue;

                if (pointValues.get(i - 1) >= 0) {
                    drawLine(last_x, last_y, position_x, position_y);
                }

                drawPoint(position_x, position_y);
                last_x = position_x;
                last_y = position_y;
            }
        }

//        if (pointValues.get(pointValues.size() - 1) >= 0) {
//            position_x += (points_width + points_interval);
//            position_y = bottom_line_y
//                    - chart_height * pointValues.get(pointValues.size() - 1) / topValue;
//
//            if (pointValues.get(pointValues.size() - 2) >= 0) {
//                drawLine(last_x, last_y, position_x, position_y);
//            }
//
//            drawPoint(position_x, position_y);
//        }
    }

    private void drawLine(float start_x, float start_y, float end_x, float end_y) {
        BrokenLineGraphConstant constant = new BrokenLineGraphConstant();
        float line_length = (float)
                Math.sqrt((start_x - end_x) * (start_x - end_x) + (start_y - end_y) * (start_y - end_y));
        canvas.drawLine(
                start_x - constant.getCircle_radius() * (start_x - end_x) / line_length,
                start_y - constant.getCircle_radius() * (start_y - end_y) / line_length,
                end_x,
                end_y,
                p_line);
    }

    private void drawPoint(float center_x, float center_y) {
        BrokenLineGraphConstant constant = new BrokenLineGraphConstant();
        canvas.drawCircle(center_x, center_y, constant.getCircle_radius(), p_circle);
        canvas.drawCircle(center_x, center_y, constant.getDot_radius(), p_dot);
    }

    private void setPaint() {
        BrokenLineGraphConstant constant = new BrokenLineGraphConstant();
        p_dot = new ColorPaint(dotColor);
        p_circle = new ColorPaint(circleColor);
        p_line = new ColorPaint(circleColor);
        p_line.setStrokeWidth(constant.getLine_stroke_width());
    }
}
