package com.mediatek.maschart;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
  /**
   * testing data
   */
  private List<String> barDates = Arrays.asList("2016/05/25", "2016/04/25", "2016/04/24",
      "2016/04/23", "2016/04/22", "2016/04/21", "2016/04/20", "2016/04/19", "2016/04/18",
      "2016/04/17", "2016/04/16", "2016/04/15", "2016/04/14", "2016/04/13", "2016/04/12",
      "2016/04/11", "2016/04/10", "2016/04/9", "2016/04/8", "2016/04/7", "2016/04/6",
      "2016/04/5", "2016/04/4", "2016/04/3", "2016/04/2");
  private List<String> barTimes = Arrays.asList("0:55", "01:10", "02:30", "03:02", "04:53", "05:55",
      "06:55", "07:55", "08:55", "09:55", "10:55", "11:55", "12:55", "13:55", "14:55", "15:55",
      "16:55", "17:55", "18:55", "19:55", "20:55", "21:55", "22:55", "23:55");
  private List<Integer> barValue = Arrays.asList(
      100, 200, 500, 30, 10, 201, 700, 120, 0, 700, 890, 700, 650, 100,
      150, 500, 800, 405, 370, 120, 890, 700, 809, 0, 100);

  private List<String> barValueStr = Arrays.asList(
      "100", "200", "50", "30", "10.5", "21",
      "70.5","10","15.5","10","10","10","10","10",
      "10","16.8","10","10","170","10","10","10",
      "10","10","10","10.9","10","10");

  private List<Integer> stages = Arrays.asList(0, -2, -3, -2, -1, 0, -2, -3, -2, -2, -1, 0);

  private int[] y_scale = {0, 35250, 70500};
  private String[] yScaleStr = {"0", "35.2k", "70.5k"};
  private int todayValue = 0;
  private String todayValueStr = "350";

  private int awakeColor = R.color.charts_x_dark_orange;
  private int firstColor = R.color.charts_purple;
  private int secondColor = R.color.charts_blue;
  private int thirdColor = R.color.charts_deep_blue;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    Charts.init(this);
    /**
     *     //* : the setting has default value
     */

    /******************************************bar chart******************************************/
   /* setContentView(R.layout.main_bar_chart);
    BarChart barChart = (BarChart)findViewById(R.id.bar_chart);

    barChart.setReports(barDates, barValue);
    barChart.setScale(y_scale);
    barChart.setLeftTitle("Sleep Efficiency");
    barChart.setRightTitleUnit("%");
    barChart.setGoalValue(10000);
    barChart.setTodayValueStr(String.valueOf(todayValue));
    */
    /**
     * special setting for string, if u don't need to set a special string, just ignore it.
     */
    /*barChart.setScaleStr(yScaleStr);
    barChart.setGoalStr("10K");
    barChart.setReportValueStr(barValueStr);
    */
    /**
     * these settings have default value
     */
    //barChart.setBarInnerValueText(true);                        //* true
    //barChart.setBarShape(BarShape.ROUND_RECTANGLE);             //* BarShape.RECTANGLE
    //barChart.setBarColor(R.color.bar_bg, R.color.charts_bg);    //* R.color.bar_bg, R.color.charts_bg
    //barChart.setChartBgColor(R.color.charts_bg);                //* R.color.charts_bg
    //barChart.setChartStyle(BarChartType.WEEK);                  //* BarChartType.WEEK



    /*****************************************stage chart*****************************************/
    /*setContentView(R.layout.main_stages_chart);
    StagesChart stageChart = (StagesChart)findViewById(R.id.stage_chart);

    stageChart.setTime("23:16", "08:30");
    stageChart.setTitle("Efficiency", 72, "5分");
    stageChart.setStages(stages);
    stageChart.isDraw();
    */

    /**
     * these settings have default value
     */
    //stageChart.setStageAmount(3);                                                 //* 4
    //stageChart.setStageColor(awakeColor, firstColor, secondColor, thirdColor);    //* #F39A1E, #ABCBDD, #00AFED, #007ABD
    //stageChart.setStageText("Awake", "Rem", "Light", "Deep");                     //* "Awake", "Rem", "Light", "Deep"
    //stageChart.setChartBgColor(R.color.charts_bg);                                //* #353630



    /**************************************broken line graph**************************************/
    /*setContentView(R.layout.main_broken_line_graph);
    BrokenLineGraph brokenLineGraph = (BrokenLineGraph)findViewById(R.id.broken_line_graph);

    brokenLineGraph.setReports(barTimes, barValue);
    brokenLineGraph.setLeftTitle("Daily avg. 3.41 km");
    brokenLineGraph.setTodayValueStr(todayValueStr);
    */

    /**
     * these settings have default value
     */
    //brokenLineGraph.setPointColor(R.color.bar_bg, R.color.charts_bg);  //* #F39A1E, #353630
    //brokenLineGraph.setRightTitleUnit("km");                           //* min
    //brokenLineGraph.setChartBgColor(R.color.charts_bg);                //* #353630
    //brokenLineGraph.setChartStyle(BrokenLineGraphType.DAY);            //* WEEK
    //brokenLineGraph.setScale(y_scale);                                 //* {0, 50, 100}

    /**
     * set special scale, if u don't need to set a special string as scale, just ignore it.
     */
    //brokenLineGraph.setScaleStr(yScaleStr);
  }
}
