package com.mediatek.maschart.barchart;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.support.annotation.ColorRes;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import com.mediatek.maschart.Charts;
import com.mediatek.maschart.R;
import com.mediatek.maschart.axis.Axis;
import com.mediatek.maschart.axis.XAxisTime;
import com.mediatek.maschart.axis.XAxisType;
import com.mediatek.maschart.paints.Alpha;
import com.mediatek.maschart.paints.BgPaint;
import com.mediatek.maschart.paints.BlackTextPaint;
import com.mediatek.maschart.utils.DateUtils;
import com.mediatek.maschart.utils.DrawUtils;
import java.util.ArrayList;
import java.util.List;

public class BarChart extends LinearLayout {
  private final int DAY_BAR_LIMIT = 25;
  private final int WEEK_BAR_LIMIT = 7;
  private final int MONTH_BAR_LIMIT = 31;

  /**
   * Default
   */
  private int bgColor = R.color.charts_bg;
  private int chartStyle = BarChartType.WEEK;
  private int barsLimit = 7;
  private int[] yScale = {0, 50, 100};
  private int goalValue = 0;
  private int barColor = R.color.bar_bg;
  private int innerTodayColor = R.color.charts_bg;
  private int barShape = BarShape.RECTANGLE;
  private boolean isBarInnerValue = true;

  private Canvas canvas;
  private Bar single_bar;
  private float bar_interval;
  private float bar_width;

  private String todayValueStr = "";
  private String goalStr = "";
  private String leftTitle = "";
  private String titleUnit = "";
  private String[] yScaleStr;
  private float sub_title_x;
  private BgPaint p_bg;
  private BlackTextPaint tp_title;
  private BlackTextPaint tp_percentage;
  private BlackTextPaint tp_bottom;

  private List<String> barDates = new ArrayList<>();
  private List<Integer> barValues = new ArrayList<>();
  private List<String> barValueStr = new ArrayList<>();

  public BarChart(Context context) {
    super(context);
    initViews();
  }

  public BarChart(Context context, AttributeSet attributeSet) {
    super(context, attributeSet);
    initViews();
  }

  public BarChart(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    initViews();
  }

  /**
   * barDates should be "yyyy/MM/dd" format
   * barValues should be Integer type
   * @param barDates
   * @param barValues
   */
  public void setReports(List<String> barDates, List<Integer> barValues) {
    this.barDates = barDates;
    this.barValues = barValues;
  }

  /**
   * if inner values are not Integer type, u can use this function to set specific value in string type for show these string  in bar.
   * @param barValueStr
   */
  public void setReportValueStr(List<String> barValueStr) {
    this.barValueStr = barValueStr;
  }

  public void setBarInnerValueText(boolean isValue) {
    this.isBarInnerValue = isValue;
  }

  public void setChartBgColor(@ColorRes int colorResId) {
    bgColor = colorResId;
  }

  public void setBarColor(@ColorRes int barColor, @ColorRes int innerTodayColor) {
    this.innerTodayColor = innerTodayColor;
    this.barColor = barColor;
  }

  public void setChartStyle(int chartStyle) {
    this.chartStyle = chartStyle;

    if (this.chartStyle == BarChartType.DAY) {
      barsLimit = DAY_BAR_LIMIT;
    } else if (this.chartStyle == BarChartType.WEEK) {
      barsLimit = WEEK_BAR_LIMIT;
    } else if (this.chartStyle == BarChartType.MONTH) {
      barsLimit = MONTH_BAR_LIMIT;
    }
  }

  public void setBarShape(int barShape) {
    this.barShape = barShape;
  }

  public void setScale(int[] yScale) {
    this.yScale = yScale;
  }

  /**
   * set special scale, including decimal number "0.5", number with unit "0.5k"...etc
   * if u don't need to set a special string as scale, just ignore it.
   * @param yScaleStr
   */
  public void setScaleStr(String[] yScaleStr) {
    this.yScaleStr = yScaleStr;
  }

  public void setGoalValue(int goalValue) {
    this.goalValue = goalValue;
  }

  /**
   * set special goal, including decimal number "0.5", number with unit "0.5k"...etc
   * if u don't need to set a special string as goal, just ignore it.
   * @param goalStr
   */
  public void setGoalStr(String goalStr) {
    this.goalStr = goalStr;
  }

  public void setTodayValueStr(String todayValueStr) {
    this.todayValueStr = todayValueStr;
  }

  public void setLeftTitle(String leftTitle) {
    this.leftTitle = leftTitle;
  }

  public void setRightTitleUnit(String titleUnit) {
    this.titleUnit = titleUnit;
  }

  private void initViews() {
    LayoutInflater inflater = LayoutInflater.from(getContext());
    inflater.inflate(R.layout.bar_chart, this, true);
    setWillNotDraw(false);
  }

  @Override protected void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    this.canvas = canvas;

    BarChartConstant constant = new BarChartConstant();
    float bottom_line_y = canvas.getHeight() - constant.getMargin_bottom();
    float axis_interval = (canvas.getHeight()
        - constant.getMargin_bottom()
        - constant.getMargin_top()
        - constant.getLine_stroke_width() * 3)
        / 2;
    float title_text_y = bottom_line_y - axis_interval * 2
        - constant.getLine_stroke_width() * 3
        - constant.getTitle_margin_bottom();

    int counter = barDates.size() < barsLimit ? barDates.size() : barsLimit;
    barDates = barDates.subList(0, counter);
    barValues = barValues.subList(0, counter);

    bar_interval = (constant.getBar_region_width()) / (barsLimit * 2);
    bar_width = (constant.getBar_region_width()) / (barsLimit * 2);

    setPaint();

    RectF rectBg = new RectF(0, 0, canvas.getWidth(), canvas.getHeight());
    canvas.drawRoundRect(rectBg, getResources().getDimension(R.dimen.chart_bg_radius),
        getResources().getDimension(R.dimen.chart_bg_radius), p_bg);

    drawAxis(bottom_line_y, axis_interval);

    canvas.drawText(leftTitle, constant.getMargin_left(), title_text_y, tp_title);

    int barCounter = barDates.size();
    if (barCounter > 0) {
      drawBar(barCounter);
      setSubTitle(title_text_y, barDates.get(0));
    }

    if (goalValue > 0) {
      drawGoalLine();
    }
  }

  private void setPaint() {
    BarChartConstant constant = new BarChartConstant();
    p_bg = new BgPaint(bgColor);

    tp_title = new BlackTextPaint(constant.getText_size());

    tp_percentage = new BlackTextPaint(constant.getText_size_percentage());
    tp_percentage.setFakeBoldText(true);

    tp_bottom = new BlackTextPaint(constant.getText_size(), Alpha.HALF);
  }

  private void drawAxis(float bottom_line_y, float axis_interval) {
    Axis.drawSolidGridLine(canvas, bottom_line_y);

    String scale = (yScaleStr != null) ? yScaleStr[1] :  String.valueOf(yScale[1]);
    Axis.drawSolidGridLineWithLowerText(
        canvas, bottom_line_y - axis_interval, scale);

    scale = (yScaleStr != null) ? yScaleStr[2] :  String.valueOf(yScale[2]);
    Axis.drawSolidGridLineWithLowerText(
        canvas, bottom_line_y - axis_interval * 2, scale);

    if (barDates.size() > 0) {
      XAxisTime xAxisTime = new XAxisTime(canvas, tp_bottom);
      xAxisTime.setBarWidth(bar_width, bar_interval);

      if (chartStyle == BarChartType.DAY) {
        xAxisTime.drawDayTime();
      } else if (chartStyle == BarChartType.WEEK) {
        xAxisTime.drawWeekOrMonth(barDates, XAxisType.WEEK);
      } else if (chartStyle == BarChartType.MONTH) {
        xAxisTime.drawWeekOrMonth(barDates, XAxisType.MONTH);
      }
    }
  }

  private void drawGoalLine() {
    BarChartConstant constant = new BarChartConstant();
    float chart_height = canvas.getHeight()
        - constant.getMargin_top()
        - constant.getMargin_bottom();
    float bottom_line_y = canvas.getHeight() - constant.getMargin_bottom();
    float goal_height = chart_height * goalValue / yScale[2];
    float goal_top = bottom_line_y - goal_height + constant.getBar_corner_radius();

    String goalValueStr = (goalStr != "") ? goalStr: String.valueOf(goalValue);
    Axis.drawDottedGoalLine(canvas, bgColor, goal_top, goalValueStr);
  }

  private void drawBar(int barCounter) {
    single_bar = new Bar(Charts.getApplicationContext());
    single_bar.setBarShape(barShape);
    single_bar.setBarColor(barColor);
    single_bar.setIsBarInnerValueText(isBarInnerValue);
    single_bar.setInnerTodayTextColor(innerTodayColor);
    single_bar.setCanvas(canvas);
    single_bar.setBarWidthAndInterval(bar_width, bar_interval);
    single_bar.setTopValue(yScale[2]);

    BarChartConstant constant = new BarChartConstant();
    float position_x = canvas.getWidth()
        - constant.getLast_bar_margin_right() - bar_width;

    if (chartStyle == BarChartType.DAY) {
      drawDayBar(barCounter);
    } else {
      drawWeekAndMonthBar(barCounter, position_x);
    }
  }

  private void drawDayBar(int barCounter) {
    float position_x = 0;
    boolean isToday = true;

    BarChartConstant constant = new BarChartConstant();
    for (int i = 0; i < barCounter - 1; i++) {
      single_bar.setHighlighted(isToday, barValues.get(i));
      int hour = Integer.valueOf(DrawUtils.getHour(barDates.get(i))).intValue();
      position_x = constant.getLast_bar_margin_left() - bar_width + bar_width * hour * 2;
      single_bar.draw(position_x, barValues.get(i), "");
    }
    single_bar.setHighlighted(isToday, barValues.get(barDates.size() - 1));
    position_x = position_x + bar_width * 2;
    single_bar.draw(position_x, barValues.get(barDates.size() - 1), "");
  }

  private void drawWeekAndMonthBar(int barCounter, float position_x) {
    String barValueStr = "";
    for (int i = 0; i < barCounter - 1; i++) {
      barValueStr = (this.barValueStr.size() != 0) ?
          this.barValueStr.get(i) : String.valueOf(barValues.get(i));
      single_bar.setHighlighted(DateUtils.isToday(barDates.get(i)), barValues.get(i));
      single_bar.draw(position_x, barValues.get(i), barValueStr);
      position_x -= bar_width + bar_interval;
    }

    barValueStr = (this.barValueStr.size() != 0) ?
        this.barValueStr.get(barCounter - 1) : String.valueOf(barValues.get(barCounter - 1));
    single_bar.setHighlighted(
        DateUtils.isToday(barDates.get(barCounter - 1)), barValues.get(barCounter - 1));
    single_bar.draw(position_x, barValues.get(barCounter - 1), barValueStr);
  }

  private void setSubTitle(float title_text_y, String title_date) {
    BarChartConstant constant = new BarChartConstant();
    sub_title_x = canvas.getWidth() - constant.getMargin_left();
    setSubTitleText(title_text_y, "  " + titleUnit);
    setSubTitleText(title_text_y, " " + getPercentageStr(title_date));
    setSubTitleText(title_text_y, "Today");
  }

  private void setSubTitleText(float title_text_y, String str) {
    sub_title_x -= DrawUtils.getTextWidth(str, tp_title) + 5;
    canvas.drawText(str, sub_title_x, title_text_y, tp_title);
  }

  private String getPercentageStr(String dateString) {
    if (chartStyle == BarChartType.DAY) {
      return todayValueStr;
    } else {
      return (DateUtils.isToday(dateString)) ? todayValueStr : "-";
    }
  }
}
