package com.mediatek.maschart.paints;

import com.mediatek.maschart.R;

public class BlackTextPaint extends TextPaint {

  public BlackTextPaint(float textSize) {
    this(textSize, Alpha.OPAQUE);
  }

  public BlackTextPaint(float textSize, int alpha) {
    super(R.color.charts_grey, textSize);
    setAlpha(alpha);
  }
}
