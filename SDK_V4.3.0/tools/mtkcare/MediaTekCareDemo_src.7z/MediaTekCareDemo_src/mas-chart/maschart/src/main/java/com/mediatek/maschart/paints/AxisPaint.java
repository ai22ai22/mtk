package com.mediatek.maschart.paints;

import android.support.annotation.ColorRes;

public class AxisPaint extends ColorPaint {

  public AxisPaint(@ColorRes int colorResId, float strokeWidth) {
    this(colorResId, strokeWidth, Alpha.OPAQUE);
  }

  public AxisPaint(@ColorRes int colorResId, float strokeWidth, int alpha) {
    super(colorResId, alpha);
    setStrokeWidth(strokeWidth);
    setAlpha(alpha);
  }
}
