package com.mediatek.maschart.paints;

import android.support.annotation.ColorRes;

public class TextPaint extends ColorPaint {

  public TextPaint(@ColorRes int colorResId, float textSize) {
    this(colorResId, textSize, Alpha.OPAQUE);
  }

  public TextPaint(@ColorRes int colorResId, float textSize, int alpha) {
    super(colorResId, alpha);
    setTextSize(textSize);
  }
}
