package com.mediatek.maschart.utils;

import android.graphics.Paint;
import android.graphics.Rect;
import com.mediatek.maschart.ChartsLog;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class DrawUtils {

  public static float getTextHeight(String text, Paint paint) {
    return getTextBounds(text, paint).height();
  }

  public static float getTextWidth(String text, Paint paint) {
    return getTextBounds(text, paint).width();
  }

  private static Rect getTextBounds(String text, Paint paint) {
    Rect textBounds = new Rect();
    paint.setAntiAlias(true);
    paint.getTextBounds(text, 0, text.length(), textBounds);
    return textBounds;
  }

  public static String getHour(String inputDate) {
    try {
      String inputSdfPattern = "HH:mm";
      String outputSdfPattern = "HH";
      SimpleDateFormat inputSdf = new SimpleDateFormat(inputSdfPattern, Locale.getDefault());
      SimpleDateFormat outputSdf = new SimpleDateFormat(outputSdfPattern, Locale.getDefault());
      return outputSdf.format(inputSdf.parse(inputDate));
    } catch (NullPointerException | ParseException e) {
      ChartsLog.e(e);
      return "";
    }
  }

  public static String getDateDay(String inputDate) {
    String inputSdfPattern = "yyyy/MM/dd";
    String outputSdfPattern = "dd";
    return DateUtils.formatDate(inputDate, inputSdfPattern, outputSdfPattern);
  }

  public static String getDateMonth(String inputDate) {
    String inputSdfPattern = "yyyy/MM/dd";
    String outputSdfPattern = "MM";
    return DateUtils.formatDate(inputDate, inputSdfPattern, outputSdfPattern);
  }

  public static String reFormatDateWithMonth(String inputDate) {
    String day = getDateDay(inputDate);
    String month = getDateMonth(inputDate);

    return (Integer.valueOf(month) < 10) ? (month.substring(1) + "/" + day) : (month + "/" + day);
  }
}