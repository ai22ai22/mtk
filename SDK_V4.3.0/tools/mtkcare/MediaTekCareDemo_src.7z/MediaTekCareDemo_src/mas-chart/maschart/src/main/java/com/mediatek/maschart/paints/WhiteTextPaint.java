package com.mediatek.maschart.paints;

import com.mediatek.maschart.R;

public class WhiteTextPaint extends TextPaint {

  public WhiteTextPaint(float textSize) {
    this(textSize, Alpha.OPAQUE);
  }

  public WhiteTextPaint(float textSize, int alpha) {
    super(R.color.charts_white, textSize);
    setAlpha(alpha);
  }
}
