package com.mediatek.maschart.brokenlinegraph;

public class BrokenLineGraphType {
    public static int DAY = 0;
    public static int WEEK = 1;
    public static int MONTH = 2;
    public static int BP = 3;
}
