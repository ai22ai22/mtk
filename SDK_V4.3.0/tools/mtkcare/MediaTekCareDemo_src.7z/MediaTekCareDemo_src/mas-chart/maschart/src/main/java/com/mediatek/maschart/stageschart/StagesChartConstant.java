package com.mediatek.maschart.stageschart;

import com.mediatek.maschart.utils.UiUtils;

public class StagesChartConstant {
  public float getLabel_text_size() {
    return label_text_size;
  }

  public float getDoc_radius() {
    return doc_radius;
  }

  public float getLabel_margin_left() {
    return label_margin_left;
  }

  public float getLabel_margin_right() {
    return label_margin_right;
  }

  public float getLabel_margin_bottom() {
    return label_margin_bottom;
  }

  public float getLabel_interval() {
    return label_interval;
  }

  public float getLabel_sub_interval() {
    return label_sub_interval;
  }

  public float getTitle_bottom_margin_top() {
    return title_bottom_margin_top;
  }

  public float getTitle_margin_left() {
    return title_margin_left;
  }

  public float getEfficiency_text_size() {
    return efficiency_text_size;
  }

  public float getPercentage_text_size() {
    return percentage_text_size;
  }

  public float getDuration_text_size() {
    return duration_text_size;
  }

  public float getEfficiency_clock_interval() {
    return efficiency_clock_interval;
  }

  public float getClock_margin_top() {
    return clock_margin_top;
  }

  public float getAxis_margin_top() {
    return axis_margin_top;
  }

  public float getHead_min_awake() {
    return head_min_awake;
  }

  public float getTail_min_awake() {
    return tail_min_awake;
  }

  public float getHead_awake_margin_left() {
    return head_awake_margin_left;
  }

  public float getTail_awake_margin_right() {
    return tail_awake_margin_right;
  }

  public float getAsleep_time_line_height() {
    return asleep_time_line_height;
  }

  public float getAwake_time_line_height() {
    return awake_time_line_height;
  }

  public float getTime_text_margin_line() {
    return time_text_margin_line;
  }

  public float getTime_text_size() {
    return time_text_size;
  }

  public float getHeight_awake() {
    return height_awake;
  }

  public float getHeight_rem() {
    return height_rem;
  }

  public float getHeight_light() {
    return height_light;
  }

  public float getHeight_deep() {
    return height_deep;
  }

  private float label_text_size;
  private float doc_radius;
  private float label_margin_left;
  private float label_margin_right;
  private float label_margin_bottom;
  private float label_interval;
  private float label_sub_interval;

  private float title_bottom_margin_top;
  private float title_margin_left;
  private float efficiency_text_size;
  private float percentage_text_size;
  private float duration_text_size;
  private float efficiency_clock_interval;
  private float clock_margin_top;

  private float axis_margin_top;
  private float head_min_awake;
  private float tail_min_awake;
  private float head_awake_margin_left;
  private float tail_awake_margin_right;
  private float asleep_time_line_height;
  private float awake_time_line_height;
  private float time_text_margin_line;
  private float time_text_size;

  private float height_awake;
  private float height_rem;
  private float height_light;
  private float height_deep;


  public StagesChartConstant() {
    int LABEL_TEXT_SIZE = 13;
    int DOC_RADIUS = 7;
    int LABEL_MARGIN_LEFT = 20;
    int LABEL_MARGIN_RIGHT = 20;
    int LABEL_MARGIN_BOTTOM = 16;
    int LABEL_INTERVAL = 15;
    int LABEL_SUB_INTERVAL = 8;

    int TITLE_BOTTOM_MARGIN_TOP = 43;
    int TITLE_MARGIN_LEFT = 24;
    int EFFICIENCY_TEXT_SIZE = 16;
    int PERCENTAGE_TEXT_SIZE = 36;
    int DURATION_TEXT_SIZE = 16;
    int EFFICIENCY_CLOCK_INTERVAL = 29;
    int CLOCK_MARGIN_TOP = 29;

    int AXIS_MARGIN_TOP = 100;
    int HEAD_MIN_AWAKE = 8;
    int TAIL_MIN_AWAKE = 8;
    int HEAD_AWAKE_MARGIN_LEFT = 12;
    int TAIL_AWAKE_MARGIN_RIGHT = 12;
    int ASLEEP_TIME_LINE_HEIGHT = 64;
    int AWAKE_TIME_LINE_HEIGHT = 30;
    int TIME_TEXT_MARGIN_LINE = 5;
    int TIME_TEXT_SIZE = 12;

    int HEIGHT_AWAKE = 20;
    int HEIGHT_REM = 20;
    int HEIGHT_LIGHT = 40;
    int HEIGHT_DEEP = 60;

    doc_radius = UiUtils.dpToPx(DOC_RADIUS);
    label_text_size = UiUtils.spToPx(LABEL_TEXT_SIZE);
    label_margin_left = UiUtils.dpToPx(LABEL_MARGIN_LEFT);
    label_margin_right = UiUtils.dpToPx(LABEL_MARGIN_RIGHT);
    label_margin_bottom = UiUtils.dpToPx(LABEL_MARGIN_BOTTOM);
    label_interval = UiUtils.dpToPx(LABEL_INTERVAL);
    label_sub_interval = UiUtils.dpToPx(LABEL_SUB_INTERVAL);

    title_bottom_margin_top = UiUtils.dpToPx(TITLE_BOTTOM_MARGIN_TOP);
    title_margin_left = UiUtils.dpToPx(TITLE_MARGIN_LEFT);
    efficiency_text_size = UiUtils.spToPx(EFFICIENCY_TEXT_SIZE);
    percentage_text_size = UiUtils.spToPx(PERCENTAGE_TEXT_SIZE);
    duration_text_size = UiUtils.spToPx(DURATION_TEXT_SIZE);
    efficiency_clock_interval = UiUtils.dpToPx(EFFICIENCY_CLOCK_INTERVAL);
    clock_margin_top = UiUtils.dpToPx(CLOCK_MARGIN_TOP);

    axis_margin_top = UiUtils.dpToPx(AXIS_MARGIN_TOP);
    head_min_awake = UiUtils.dpToPx(HEAD_MIN_AWAKE);
    tail_min_awake = UiUtils.dpToPx(TAIL_MIN_AWAKE);
    head_awake_margin_left = UiUtils.dpToPx(HEAD_AWAKE_MARGIN_LEFT);
    tail_awake_margin_right = UiUtils.dpToPx(TAIL_AWAKE_MARGIN_RIGHT);
    asleep_time_line_height = UiUtils.dpToPx(ASLEEP_TIME_LINE_HEIGHT);
    awake_time_line_height = UiUtils.dpToPx(AWAKE_TIME_LINE_HEIGHT);
    time_text_margin_line = UiUtils.dpToPx(TIME_TEXT_MARGIN_LINE);
    time_text_size = UiUtils.spToPx(TIME_TEXT_SIZE);

    height_awake = UiUtils.dpToPx(HEIGHT_AWAKE);
    height_rem = UiUtils.dpToPx(HEIGHT_REM);
    height_light = UiUtils.dpToPx(HEIGHT_LIGHT);
    height_deep = UiUtils.dpToPx(HEIGHT_DEEP);
  }
}

