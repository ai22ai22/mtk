package com.mediatek.maschart.barchart;

public class BarShape {
  public static int RECTANGLE = 0;
  public static int ROUND_RECTANGLE = 1;
}