package com.mediatek.maschart.brokenlinegraph;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.support.annotation.ColorRes;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.LinearLayout;

import com.mediatek.maschart.R;
import com.mediatek.maschart.axis.Axis;
import com.mediatek.maschart.axis.XAxisTime;
import com.mediatek.maschart.axis.XAxisType;
import com.mediatek.maschart.paints.BgPaint;
import com.mediatek.maschart.paints.BlackTextPaint;
import com.mediatek.maschart.utils.DateUtils;

import com.mediatek.maschart.utils.UiUtils;
import java.util.ArrayList;
import java.util.List;

public class BrokenLineGraph extends LinearLayout {
    private final int DAY_POINT_LIMIT = 25;
    private final int WEEK_POINT_LIMIT = 7;
    private final int MONTH_POINT_LIMIT = 31;
    private final int BP_POINT_LIMIT = 50;

    /**
     * Default
     */
    private int bg_color = R.color.charts_bg;
    private int[] yScale = {0, 50, 100};
    private int chartStyle = BrokenLineGraphType.BP;
    private int pointsLimit = 7;
    private int dotColor = R.color.chart_dot;
    private int circleColor = R.color.bar_bg;
    private String rightTitleUnit = "min";

    private String leftTitle = "";
    private String todayValueStr = "";
    private String[] yScaleStr;
    private BrokenLine brokenLine;
    private float points_width;
    private float points_interval;
    private float sub_title_x;
    private List<String> pointsDates = new ArrayList<>();
    private List<Integer> pointsValues = new ArrayList<>();

    private Canvas canvas;
    private BgPaint p_bg;
    private BlackTextPaint tp_title;
    private BlackTextPaint tp_value;
    private BlackTextPaint tp_bottom;

    public BrokenLineGraph(Context context) {
        super(context);
        initViews();
    }

    public BrokenLineGraph(Context context, AttributeSet attrs) {
        super(context, attrs);
        initViews();
    }

    public BrokenLineGraph(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initViews();
    }

    private void initViews() {
        inflate(getContext(), R.layout.broken_line_graph, this);
        setWillNotDraw(false);
    }

    /**
     * pointDates should be "yyyy/MM/dd" format
     * pointValue should be Integer type
     *
     * @param pointsDates
     * @param pointsValues
     */
    public void setReports(List<String> pointsDates, List<Integer> pointsValues) {
        this.pointsDates = pointsDates;
        this.pointsValues = pointsValues;
    }

    public void setLeftTitle(String leftTitle) {
        this.leftTitle = leftTitle;
    }

    public void setChartBgColor(@ColorRes int colorResId) {
        bg_color = colorResId;
    }

    public void setScale(int[] yScales) {
        yScale = yScales;
    }

    /**
     * set special scale, including decimal number "0.5", number with unit "0.5k"...etc
     * if u don't need to set a special string as scale, just ignore it.
     *
     * @param yScaleStr
     */
    public void setScaleStr(String[] yScaleStr) {
        this.yScaleStr = yScaleStr;
    }

    public void setChartStyle(int chartStyle) {
        if (chartStyle == BrokenLineGraphType.DAY) {
            pointsLimit = DAY_POINT_LIMIT;
        } else if (chartStyle == BrokenLineGraphType.WEEK) {
            pointsLimit = WEEK_POINT_LIMIT;
        } else if (chartStyle == BrokenLineGraphType.MONTH) {
            pointsLimit = MONTH_POINT_LIMIT;
        } else if (chartStyle == BrokenLineGraphType.BP) {
            pointsLimit = pointsDates.size();
        }

        this.chartStyle = chartStyle;
    }

    public void setTodayValueStr(String todayValueStr) {
        this.todayValueStr = todayValueStr;
    }

    public void setRightTitleUnit(String rightTitleUnit) {
        this.rightTitleUnit = rightTitleUnit;
    }

    public void setPointColor(@ColorRes int circleColor, @ColorRes int dotColor) {
        this.circleColor = circleColor;
        this.dotColor = dotColor;
    }

    private int w;
    private int h;
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        this.w = w;
        Log.i("test", "onSizeChanged this.w:"+this.w);
        this.h = h;
        super.onSizeChanged(w, h, oldw, oldh);
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.canvas = canvas;

        if (pointsDates.size() == 0) {
            return;
        }

        BrokenLineGraphConstant constant = new BrokenLineGraphConstant();
        float bottom_line_y = canvas.getHeight() - constant.getMargin_bottom();
        float axis_interval = (canvas.getHeight()
                - constant.getMargin_bottom()
                - constant.getMargin_top()
                - constant.getLine_stroke_width() * 3)
                / 2;
        float title_text_y = bottom_line_y - axis_interval * 2
                - constant.getLine_stroke_width() * 3
                - constant.getTitle_margin_bottom();

        int counter = pointsDates.size() < pointsLimit ? pointsDates.size() : pointsLimit;
        pointsDates = pointsDates.subList(0, counter);
        pointsValues = pointsValues.subList(0, counter);

        //points_interval = (constant.getBroken_line_region_width()) / (pointsLimit * 2);
        //Log.i("test", "onDraw this.w:"+this.w);
        points_interval = this.w/ (pointsLimit * 2);
        //points_width = (constant.getBroken_line_region_width()) / (pointsLimit * 2);
        points_width = this.w / (pointsLimit * 2);

        setPaint();

        RectF rectBg = new RectF(0, 0, canvas.getWidth(), canvas.getHeight());
        canvas.drawRoundRect(rectBg, getResources().getDimension(R.dimen.chart_bg_radius),
                getResources().getDimension(R.dimen.chart_bg_radius), p_bg);

        drawAxis(bottom_line_y, axis_interval);

        canvas.drawText(leftTitle, constant.getMargin_left(), title_text_y, tp_title);

        brokenLine = new BrokenLine();
        brokenLine.setPointColor(circleColor, dotColor);

        int barCounter = pointsDates.size();
        if (barCounter > 0) {
            if (chartStyle == BrokenLineGraphType.DAY) {
                brokenLine.setBrokenLineData(pointsDates, pointsValues, yScale[2]);
            } else {
                brokenLine.setBrokenLineData(pointsValues, yScale[2]);
            }
            brokenLine.setCanvas(canvas);
            brokenLine.draw(chartStyle, points_width, points_interval);
            setSubTitle(title_text_y, pointsDates.get(0));
        }
    }

    private void setPaint() {
        BrokenLineGraphConstant constant = new BrokenLineGraphConstant();
        p_bg = new BgPaint(bg_color);
        tp_title = new BlackTextPaint(constant.getText_size());
        tp_value = new BlackTextPaint(constant.getText_size_percentage());
        tp_bottom = new BlackTextPaint(constant.getText_size());
    }

    private void drawAxis(float bottom_line_y, float axis_interval) {
        Axis.drawSolidGridLine(canvas, bottom_line_y);

        String scale = (yScaleStr != null) ? yScaleStr[1] : String.valueOf(yScale[1]);
        Axis.drawSolidGridLineWithLowerText(
                canvas, bottom_line_y - axis_interval, scale);

        scale = (yScaleStr != null) ? yScaleStr[2] : String.valueOf(yScale[2]);
        Axis.drawSolidGridLineWithLowerText(
                canvas, bottom_line_y - axis_interval * 2, scale);

        if (pointsDates.size() > 0) {
            XAxisTime xAxisTime = new XAxisTime(canvas, tp_bottom);
            xAxisTime.setBarWidth(points_width, points_interval);

            if (chartStyle == BrokenLineGraphType.DAY) {
                xAxisTime.drawDayTime();
            } else if (chartStyle == BrokenLineGraphType.WEEK) {
                xAxisTime.drawWeekOrMonth(pointsDates, XAxisType.WEEK);
            } else if (chartStyle == BrokenLineGraphType.MONTH) {
                xAxisTime.drawWeekOrMonth(pointsDates, XAxisType.MONTH);
            } else if (chartStyle == BrokenLineGraphType.BP) {
                xAxisTime.drawBp(pointsDates, XAxisType.BP);
            }
        }
    }

    private void setSubTitle(float title_text_y, String title_date) {
        BrokenLineGraphConstant constant = new BrokenLineGraphConstant();
        sub_title_x = canvas.getWidth() - constant.getMargin_left();
        setSubTitleText(title_text_y, rightTitleUnit);
//        setSubTitleText(title_text_y, " " + getPercentageStr(title_date));
//        setSubTitleText(title_text_y, "Today");
    }

    private void setSubTitleText(float title_text_y, String str) {
//        sub_title_x -= DrawUtils.getTextWidth(str, tp_title) + 5;
        sub_title_x =  5;
        canvas.drawText(str, sub_title_x, title_text_y, tp_title);
    }

    private String getPercentageStr(String dateString) {
        if (chartStyle == BrokenLineGraphType.DAY) {
            return todayValueStr;
        } else {
            return (DateUtils.isToday(dateString)) ? todayValueStr : "-";
        }
    }
}
