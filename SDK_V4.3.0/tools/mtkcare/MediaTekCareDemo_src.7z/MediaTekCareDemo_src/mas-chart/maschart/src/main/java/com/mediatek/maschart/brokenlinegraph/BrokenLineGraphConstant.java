package com.mediatek.maschart.brokenlinegraph;

import com.mediatek.maschart.utils.UiUtils;

public class BrokenLineGraphConstant {

  public float getBroken_line_region_width() {
    return broken_line_region_width;
  }

  public float getChart_width() {
    return chart_width;
  }

  public float getChart_height() {
    return chart_height;
  }

  public float getMargin_left() {
    return margin_left;
  }

  public float getMargin_right() {
    return margin_right;
  }

  public float getMargin_top() {
    return margin_top;
  }

  public float getMargin_bottom() {
    return margin_bottom;
  }

  public float getDate_margin_axis() {
    return date_margin_axis;
  }

  public float getLine_stroke_width() {
    return line_stroke_width;
  }

  public float getText_size() {
    return text_size;
  }

  public float getText_size_percentage() {
    return text_size_percentage;
  }

  public float getTitle_margin_bottom() {
    return title_margin_bottom;
  }

  public float getCircle_radius() {
    return circle_radius;
  }

  public float getDot_radius() {
    return dot_radius;
  }

  public float getLine_thinkness() {
    return line_thinkness;
  }

  public float getLast_point_margin_right() {
    return last_point_margin_right;
  }

  public float getDay_first_point_margin_left() {
    return day_first_point_margin_left;
  }

  private float broken_line_region_width;
  private float chart_width;
  private float chart_height;
  private float margin_left;
  private float margin_right;
  private float margin_top;
  private float margin_bottom;
  private float date_margin_axis;
  private float line_stroke_width;
  private float text_size;
  private float text_size_percentage;
  private float title_margin_bottom;

  private float circle_radius;
  private float dot_radius;
  private float line_thinkness;

  private float last_point_margin_right;

  private float day_first_point_margin_left;

  public BrokenLineGraphConstant() {
    final float BROKEN_LINE_REGION_WIDTH = 2880;
    final float CHART_WIDTH = 320;
    final float CHART_HEIGHT = 132;
    final float MARGIN_LEFT = 12;
    final float MARGIN_RIGHT = 12;
    final float MARGIN_TOP = 42;
    final float MARGIN_BOTTOM = 34;
    final float DATE_MARGIN_AXIS = 8;
    final float LINE_STROKE_WIDTH = 2;
    final float TITLE_MARGIN_BOTTOM = 8;
    final int TEXT_SIZE = 12;
    final int TEXT_SIZE_PERCENTAGE = 18;

    final float CIRCLE_RADIUS = 3;
    final float DOT_RADIUS = 2;
    final float LINE_THINKNESS = 2;

    final float LAST_POINT_MARGIN_RIGHT = 45;

    final float DAY_FIRST_POINT_MARGIN_LEFT = 15;

    broken_line_region_width = UiUtils.dpToPx(BROKEN_LINE_REGION_WIDTH);
    chart_width = UiUtils.dpToPx(CHART_WIDTH);
    chart_height = UiUtils.dpToPx(CHART_HEIGHT);

    margin_left = UiUtils.dpToPx(MARGIN_LEFT);
    margin_right = UiUtils.dpToPx(MARGIN_RIGHT);
    margin_top = UiUtils.dpToPx(MARGIN_TOP);
    margin_bottom = UiUtils.dpToPx(MARGIN_BOTTOM);

    line_stroke_width = UiUtils.dpToPx(LINE_STROKE_WIDTH);
    date_margin_axis = UiUtils.dpToPx(DATE_MARGIN_AXIS);
    title_margin_bottom = UiUtils.dpToPx(TITLE_MARGIN_BOTTOM);
    text_size = UiUtils.spToPx(TEXT_SIZE);
    text_size_percentage = UiUtils.spToPx(TEXT_SIZE_PERCENTAGE);

    circle_radius = UiUtils.dpToPx(CIRCLE_RADIUS);
    dot_radius = UiUtils.dpToPx(DOT_RADIUS);
    line_thinkness = UiUtils.dpToPx(LINE_THINKNESS);

    last_point_margin_right = UiUtils.dpToPx(LAST_POINT_MARGIN_RIGHT);

    day_first_point_margin_left = UiUtils.dpToPx(DAY_FIRST_POINT_MARGIN_LEFT);
  }
}

