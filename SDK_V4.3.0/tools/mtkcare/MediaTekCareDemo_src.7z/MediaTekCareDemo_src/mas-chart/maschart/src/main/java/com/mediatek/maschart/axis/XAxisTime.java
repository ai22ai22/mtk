package com.mediatek.maschart.axis;

import android.graphics.Canvas;

import com.mediatek.maschart.paints.Alpha;
import com.mediatek.maschart.paints.BlackTextPaint;
import com.mediatek.maschart.utils.DateUtils;
import com.mediatek.maschart.utils.DrawUtils;

import java.util.List;

public class XAxisTime {
    private Canvas canvas;
    private BlackTextPaint tp_bottom;
    private float bar_width;
    private float bar_interval;

    public XAxisTime(Canvas canvas, BlackTextPaint tp_bottom) {
        this.canvas = canvas;
        this.tp_bottom = tp_bottom;
    }

    public void setBarWidth(float bar_width, float bar_interval) {
        this.bar_width = bar_width;
        this.bar_interval = bar_interval;
    }

    public void drawWeekOrMonth(List<String> barDates, int type) {
        AxisConstant constant = new AxisConstant();
        int date_text_color_alpha;
        float position_x = canvas.getWidth() - constant.getLast_date_margin_right() - bar_width;
        float text_center;
        float text_y = canvas.getHeight()
                - constant.getAxis_margin_bottom()
                + constant.getDate_margin_axis();
        String dateStr;

        int bar_counter_interval = (type == XAxisType.WEEK) ? 1 : 5;
        int i = 0;
        if (barDates.size() < bar_counter_interval) {
            dateStr = (DrawUtils.getDateMonth(barDates.get(0)).equals(DrawUtils.getDateMonth(
                    barDates.get(barDates.size() - 1)))) ?
                    DrawUtils.getDateDay(barDates.get(0)) : DrawUtils.reFormatDateWithMonth(
                    barDates.get(0));

            date_text_color_alpha = (DateUtils.isToday(barDates.get(barDates.size() - 1))) ?
                    Alpha.OPAQUE : Alpha.HALF;
            tp_bottom.setAlpha(date_text_color_alpha);

            text_center = bar_width / 2 - DrawUtils.getTextWidth(dateStr, tp_bottom) / 2;

            canvas.drawText(dateStr, position_x + text_center, text_y, tp_bottom);
            position_x = position_x - (bar_width + bar_interval) * (barDates.size() - 1);
            i++;
        }

        for (int j = i; j < barDates.size() - bar_counter_interval; j++) {
            if (j % bar_counter_interval == 0) {
                dateStr = (DrawUtils.getDateMonth(barDates.get(j)).equals(DrawUtils.getDateMonth(
                        barDates.get(j + bar_counter_interval)))) ?
                        DrawUtils.getDateDay(barDates.get(j)) : DrawUtils.reFormatDateWithMonth(
                        barDates.get(j));

                text_center = bar_width / 2 - DrawUtils.getTextWidth(dateStr, tp_bottom) / 2;

                date_text_color_alpha = (DateUtils.isToday(barDates.get(j))) ?
                        Alpha.OPAQUE : Alpha.HALF;
                tp_bottom.setAlpha(date_text_color_alpha);
                canvas.drawText(dateStr, position_x + text_center, text_y, tp_bottom);
            }
            position_x -= (bar_width + bar_interval);
            i++;
        }

        for (int j = i; j < barDates.size() - 1; j++) {
            if (j % bar_counter_interval == 0) {
                dateStr = (DrawUtils.getDateMonth(barDates.get(j)).equals(DrawUtils.getDateMonth(
                        barDates.get(barDates.size() - 1)))) ?
                        DrawUtils.getDateDay(barDates.get(j)) : DrawUtils.reFormatDateWithMonth(
                        barDates.get(j));

                text_center = bar_width / 2 - DrawUtils.getTextWidth(dateStr, tp_bottom) / 2;

                date_text_color_alpha = (DateUtils.isToday(barDates.get(j))) ?
                        Alpha.OPAQUE : Alpha.HALF;
                tp_bottom.setAlpha(date_text_color_alpha);
                canvas.drawText(dateStr, position_x + text_center, text_y, tp_bottom);
            }
            position_x -= (bar_width + bar_interval);
            i++;
        }

        dateStr = DrawUtils.reFormatDateWithMonth(barDates.get(barDates.size() - 1));
        date_text_color_alpha = (DateUtils.isToday(barDates.get(barDates.size() - 1))) ?
                Alpha.OPAQUE : Alpha.HALF;
        tp_bottom.setAlpha(date_text_color_alpha);

        text_center = bar_width / 2 - DrawUtils.getTextWidth(dateStr, tp_bottom) / 2;

        canvas.drawText(dateStr, position_x + text_center, text_y, tp_bottom);
    }

    public void drawDayTime() {
        AxisConstant constant = new AxisConstant();
        String[] time_text = {"0", "12", "24"};
        float time_text_y = canvas.getHeight()
                - constant.getAxis_margin_bottom()
                + constant.getDate_margin_axis();
        float time_text_x = constant.getDay_time_margin_left();

        canvas.drawText(time_text[0], time_text_x, time_text_y, tp_bottom);
        time_text_x += constant.getDay_time_first_interval()
                + DrawUtils.getTextWidth(time_text[0], tp_bottom);

        canvas.drawText(time_text[1], time_text_x, time_text_y, tp_bottom);
        time_text_x += constant.getDay_time_second_interval()
                + DrawUtils.getTextWidth(time_text[1], tp_bottom);
        canvas.drawText(time_text[2], time_text_x, time_text_y, tp_bottom);
    }

    public void drawBp(List<String> barDates, int type) {
        AxisConstant constant = new AxisConstant();
//        float position_x = canvas.getWidth() - constant.getLast_date_margin_right() - bar_width;
        float position_x = 40 - bar_width;
        float text_center;
        float text_y = canvas.getHeight()
                - constant.getAxis_margin_bottom()
                + constant.getDate_margin_axis();
        String dateStr;

        tp_bottom.setAlpha(Alpha.OPAQUE);

        for (int i = 0; i <= barDates.size() - 1; i++) {
            dateStr = barDates.get(i);
            text_center = bar_width / 2 - DrawUtils.getTextWidth(dateStr, tp_bottom) / 2;

            canvas.drawText(dateStr, position_x + text_center, text_y, tp_bottom);
            position_x += (bar_width + bar_interval);
        }


//        dateStr = DrawUtils.reFormatDateWithMonth(barDates.get(barDates.size() - 1));
//        date_text_color_alpha = (DateUtils.isToday(barDates.get(barDates.size() - 1))) ?
//                Alpha.OPAQUE : Alpha.HALF;
//        tp_bottom.setAlpha(date_text_color_alpha);
//
//        text_center = bar_width / 2 - DrawUtils.getTextWidth(dateStr, tp_bottom) / 2;
//
//        canvas.drawText(dateStr, position_x + text_center, text_y, tp_bottom);
    }

}
