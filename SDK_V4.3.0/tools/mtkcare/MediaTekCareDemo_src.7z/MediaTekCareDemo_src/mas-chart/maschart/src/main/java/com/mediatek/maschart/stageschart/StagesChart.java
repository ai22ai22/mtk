package com.mediatek.maschart.stageschart;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.RectF;
import android.support.annotation.ColorRes;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import com.mediatek.maschart.Charts;
import com.mediatek.maschart.R;
import com.mediatek.maschart.paints.BgPaint;
import com.mediatek.maschart.paints.ColorPaint;
import com.mediatek.maschart.paints.DottedLinePaint;
import com.mediatek.maschart.paints.BlackTextPaint;
import com.mediatek.maschart.utils.DrawUtils;
import com.mediatek.maschart.utils.UiUtils;
import java.util.List;

public class StagesChart extends LinearLayout {
  /**
   * Default
   */
  private boolean draw_flag = false;
  private int stageAmount = 4;
  private int efficiencyPercentage = 95;
  private String efficiencyStr = "Efficiency";
  private String awakeText = "Wake";
  private String remText = "Rem";
  private String lightText = "Light";
  private String deepText = "Deep";
  private @ColorRes int awakeColor = R.color.charts_x_dark_orange;
  private @ColorRes int remColor = R.color.charts_purple;
  private @ColorRes int lightColor = R.color.charts_blue;
  private @ColorRes int deepColor = R.color.charts_deep_blue;
  private int bg_color = R.color.charts_bg;

  private List<Integer> stages;
  private String asleepTime = "";
  private String awakeTime = "";
  private String duration = "";

  private Canvas canvas;
  private BlackTextPaint tp_label;
  private BlackTextPaint tp_title;
  private DottedLinePaint p_dotted_axis;
  private ColorPaint p_circle;
  private ColorPaint p_bar;
  private BgPaint p_bg;

  private float width = 0;
  private float height = 0;
  private float label_textWidth = 0;
  private float label_x = 10;

  public StagesChart(Context context) {
    super(context);
    initViews();
  }

  public StagesChart(Context context, AttributeSet attrs) {
    super(context, attrs);
    initViews();
  }

  public StagesChart(Context context, AttributeSet attrs, int defStyleAttr) {
    super(context, attrs, defStyleAttr);
    initViews();
  }

  private void initViews() {
    inflate(getContext(), R.layout.stages_chart, this);
    setWillNotDraw(false);
  }

  public void setTitle(String efficiencyStr, int efficiencyPercentage, String duration) {
    this.efficiencyStr = efficiencyStr;
    this.efficiencyPercentage = efficiencyPercentage;
    this.duration = duration;
  }

  /**
   * the time format should be mm:ss
   * @param asleepTime
   * @param awakeTime
   */
  public void setTime(String asleepTime, String awakeTime) {
    this.asleepTime = asleepTime;
    this.awakeTime = awakeTime;
  }

  public void setStages(List<Integer> stages) {
    this.stages = stages;
  }

  public void setStageAmount(int stageAmount) {
    this.stageAmount = stageAmount;
  }

  public void isDraw() {
    draw_flag = true;
  }

  public void setChartBgColor(@ColorRes int colorResId) {
    bg_color = colorResId;
  }

  public void setStageColor(@ColorRes int awakeColor, @ColorRes int remColor, @ColorRes int lightColor, @ColorRes int deepColor) {
    this.awakeColor = awakeColor;
    this.remColor = remColor;
    this.lightColor = lightColor;
    this.deepColor = deepColor;
  }

  public void setStageText(String awakeText, String remText, String lightText, String deepText) {
    this.awakeText = awakeText;
    this.remText = remText;
    this.lightText = lightText;
    this.deepText = deepText;
  }

  @Override public void onDraw(Canvas canvas) {
    super.onDraw(canvas);
    this.canvas = canvas;

    if (draw_flag) {
      setPaint();
      RectF rect_bg = new RectF(0, 0, canvas.getWidth(), canvas.getHeight());
      canvas.drawRoundRect(rect_bg, getResources().getDimension(R.dimen.chart_bg_radius),
          getResources().getDimension(R.dimen.chart_bg_radius), p_bg);

      drawTitle();

      int stateCounter = 0;
      for (int i = 0; i < stageAmount; i++) {
        drawLabel(stateCounter);
        stateCounter = stateCounter - 1;
      }
      drawDetailBarChart();
    } else {
      invalidate();
    }

    resetPosition();
  }

  private void setPaint() {
    StagesChartConstant constant = new StagesChartConstant();
    p_bg = new BgPaint(bg_color);

    tp_label = new BlackTextPaint(constant.getLabel_text_size());

    tp_title = new BlackTextPaint(constant.getEfficiency_text_size());

    p_circle = new ColorPaint(R.color.charts_white);

    p_bar = new ColorPaint(R.color.charts_white);

    p_dotted_axis = new DottedLinePaint(R.color.charts_white, UiUtils.dpToPx(2));
  }

  private void drawDetailBarChart() {
    StagesChartConstant constant = new StagesChartConstant();
    int currentStage;
    int nextStage;
    float axis_y = constant.getAxis_margin_top();
    float chart_x_tail = constant.getHead_awake_margin_left()
        + constant.getHead_min_awake();
    float chart_x_head = constant.getHead_awake_margin_left()
        + constant.getHead_min_awake();
    float bar_width = (width
        - constant.getHead_min_awake()
        - constant.getTail_min_awake()
        - constant.getHead_awake_margin_left()
        - constant.getTail_awake_margin_right())
        / stages.size();

    p_bar.setColor(
        Charts.getApplicationContext().getResources().getColor(getStageColor(StageType.AWAKE))
        //ContextCompat.getColor(Charts.getApplicationContext(), getStageColor(StageType.AWAKE))
    );
    drawBar(StageType.AWAKE, constant.getHead_min_awake(), chart_x_tail);

    for (int i = 0; i < stages.size() - 1; i++) {
      currentStage = stages.get(i);
      nextStage = stages.get(i + 1);
      chart_x_tail += bar_width;

      if (currentStage != nextStage) {
        p_bar.setColor(
            //ContextCompat.getColor(Charts.getApplicationContext(),getStageColor(currentStage))
            Charts.getApplicationContext().getResources().getColor(getStageColor(currentStage))
        );
        drawBar(currentStage, chart_x_head, chart_x_tail);
        chart_x_head = chart_x_tail;
      }
    }

    /**
     * We expect that the last stage is "wake"
     */
    p_bar.setColor(
        //ContextCompat.getColor(Charts.getApplicationContext(),getStageColor(stages.get(stages.size() - 1)))
        Charts.getApplicationContext().getResources().getColor(getStageColor(stages.get(stages.size() - 1)))
    );
    drawBar(StageType.AWAKE,
        chart_x_head,
        width - constant.getTail_awake_margin_right());

    StagesChartTimeMark mark = new StagesChartTimeMark(canvas, stages);
    mark.draw(asleepTime, awakeTime);

    drawDottedAxis(axis_y);
  }

  private void drawBar(int stage, float chart_x_head, float chart_x_tail) {
    StagesChartConstant constant = new StagesChartConstant();
    float axis_y = constant.getAxis_margin_top();
    if (stage == StageType.AWAKE) {
      this.canvas.drawRect(chart_x_head, axis_y - getStageBarHeight(stage),
          chart_x_tail, axis_y, p_bar);
    } else {
      this.canvas.drawRect(chart_x_head, axis_y, chart_x_tail,
          axis_y + getStageBarHeight(stage), p_bar);
    }
  }

  private void drawDottedAxis(float axis_y) {
    Path path = new Path();
    path.moveTo(0, axis_y);
    path.lineTo(width, axis_y);
    canvas.drawPath(path, p_dotted_axis);
  }

  private void drawTitle() {
    StagesChartConstant constant = new StagesChartConstant();
    String efficiencyStr = this.efficiencyStr;
    float text_x =  constant.getTitle_margin_left();
    float text_y = constant.getTitle_bottom_margin_top();
    canvas.drawText(efficiencyStr, text_x, text_y, tp_title);

    String percentageStr = String.valueOf(efficiencyPercentage);
    text_x = text_x + DrawUtils.getTextWidth(efficiencyStr, tp_title) + 20;
    tp_title.setTextSize(constant.getPercentage_text_size());
    canvas.drawText(percentageStr, text_x, text_y, tp_title);

    String operatorStr = "%";
    text_x = text_x + DrawUtils.getTextWidth(percentageStr, tp_title) + 10;
    tp_title.setTextSize(constant.getEfficiency_text_size());
    canvas.drawText(operatorStr, text_x, text_y, tp_title);

    text_x = text_x + DrawUtils.getTextWidth(operatorStr, tp_title)
        + constant.getEfficiency_clock_interval();
    Bitmap img_heart = BitmapFactory.decodeResource(getResources(), R.drawable.ic_clock);
    canvas.drawBitmap(img_heart, text_x, constant.getClock_margin_top(), tp_title);

    text_x = text_x + img_heart.getWidth() + 10;
    tp_title.setTextSize(constant.getDuration_text_size());
    canvas.drawText(duration, text_x, text_y, tp_title);
  }

  private void drawLabel(int stage) {
    StagesChartConstant constant = new StagesChartConstant();
    String stageStr = getStageText(stage);
    width = this.getWidth();
    height = this.getHeight();
    float circle_center_y = height
        - constant.getLabel_margin_bottom()
        - constant.getDoc_radius();

    label_x += constant.getLabel_interval()
        + constant.getDoc_radius() * 2 + label_textWidth;
    p_circle.setColor(
        //ContextCompat.getColor(Charts.getApplicationContext(), getStageColor(stage))
        Charts.getApplicationContext().getResources().getColor(getStageColor(stage))
    );
    canvas.drawCircle(label_x, circle_center_y,
        constant.getDoc_radius(), p_circle);

    float label_y = height - constant.getLabel_margin_bottom();
    label_x += constant.getLabel_sub_interval() + constant.getDoc_radius();
    canvas.drawText(stageStr, label_x, label_y, tp_label);

    label_textWidth = DrawUtils.getTextWidth(stageStr, tp_label);
  }

  private void resetPosition() {
    label_x = 10;
    label_textWidth = 0;
  }

  private float getStageBarHeight(int stage) {
    StagesChartConstant constant = new StagesChartConstant();

    switch (stage) {
      case StageType.AWAKE:
        return constant.getHeight_awake();
      case StageType.STEP_ONE:
        return constant.getHeight_rem();
      case StageType.STEP_TWO:
        return constant.getHeight_light();
      case StageType.STEP_THREE:
        return constant.getHeight_deep();
    }
    return constant.getHeight_awake();
  }

  private @ColorRes int getStageColor(int stage) {
    switch (stage) {
      case StageType.AWAKE:
        return awakeColor;
      case StageType.STEP_ONE:
        return remColor;
      case StageType.STEP_TWO:
        return lightColor;
      case StageType.STEP_THREE:
        return deepColor;
    }
    return awakeColor;
  }

  private String getStageText(int stage) {
    switch (stage) {
      case StageType.AWAKE:
        return awakeText;
      case StageType.STEP_ONE:
        return remText;
      case StageType.STEP_TWO:
        return lightText;
      case StageType.STEP_THREE:
        return deepText;
    }
    return awakeText;
  }
}
