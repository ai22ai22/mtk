package com.mediatek.maschart.axis;

import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.RectF;

import com.mediatek.maschart.R;
import com.mediatek.maschart.paints.Alpha;
import com.mediatek.maschart.paints.AxisPaint;
import com.mediatek.maschart.paints.ColorPaint;
import com.mediatek.maschart.paints.DottedLinePaint;
import com.mediatek.maschart.paints.WhiteTextPaint;
import com.mediatek.maschart.paints.TextPaint;
import com.mediatek.maschart.paints.BlackTextPaint;
import com.mediatek.maschart.utils.DrawUtils;

public class Axis {

  public static void drawSolidGridLineWithLowerText(Canvas canvas, float line_y,
      String scale_text) {
    AxisConstant constants = new AxisConstant();
    BlackTextPaint tp_axis = new BlackTextPaint(constants.getAxis_text_size());

    float scale_text_y =
        line_y + constants.getAxis_text_margin_line() + DrawUtils.getTextHeight(scale_text,
            tp_axis);
    float line_end_x = canvas.getWidth() - constants.getAxis_margin_right();

    drawSolidGridLine(canvas, line_y);
    canvas.drawText(scale_text,
        //                line_end_x - DrawUtils.getTextWidth(scale_text, tp_axis),
        5, scale_text_y, tp_axis);
  }

  public static void drawSolidGridLineWithUpperText(Canvas canvas, float line_y,
      String scale_text) {
    AxisConstant constants = new AxisConstant();
    BlackTextPaint tp_axis = new BlackTextPaint(constants.getAxis_text_size(), Alpha.HALF);
    float line_end_x = canvas.getWidth() - constants.getAxis_margin_right();
    float scale_text_y = line_y - constants.getAxis_text_margin_line();

    drawSolidGridLine(canvas, line_y);
    canvas.drawText(scale_text, line_end_x - DrawUtils.getTextWidth(scale_text, tp_axis),
        scale_text_y, tp_axis);
  }

  public static void drawSolidGridLine(Canvas canvas, float line_y) {
    AxisConstant constants = new AxisConstant();
    AxisPaint p_normal_axis = new AxisPaint(R.color.charts_white, 1, Alpha.ONE_FIFTH);
    float line_start_x = constants.getAxis_margin_left();
    float line_end_x = canvas.getWidth() - constants.getAxis_margin_right();

    canvas.drawLine(line_start_x, line_y, line_end_x, line_y, p_normal_axis);
  }

  public static void drawDottedGoalLine(Canvas canvas, int textColor, float line_y,
      String goalValue) {
    AxisConstant constants = new AxisConstant();
    DottedLinePaint p_dotted_axis =
        new DottedLinePaint(R.color.charts_white, constants.getGoal_line_stroke_width(),
            Alpha.OPAQUE);
    ColorPaint p_text_bg = new ColorPaint(R.color.charts_white);
    TextPaint tp_axis = new TextPaint(textColor, constants.getAxis_text_size());

    float line_start_x = constants.getAxis_margin_left();
    float line_end_x = canvas.getWidth() - constants.getGoal_line_margin_right();
    float scale_text_x =
        canvas.getWidth() - constants.getAxis_margin_right() - DrawUtils.getTextWidth(goalValue,
            tp_axis);
    float scale_text_y = line_y + DrawUtils.getTextHeight(goalValue, tp_axis) / 2;

    Path path = new Path();
    path.moveTo(line_start_x, line_y);
    path.lineTo(line_end_x, line_y);
    canvas.drawPath(path, p_dotted_axis);

    float text_center_x = scale_text_x + DrawUtils.getTextWidth(goalValue, tp_axis) / 2;
    float text_bg_half_width = (float) (constants.getGoal_text_bg_width()
        - constants.getGoal_text_bg_triangle_side_length() * Math.sqrt(3) / 2) / 2;
    RectF rect_bg = new RectF(text_center_x - text_bg_half_width,
        line_y - constants.getGoal_text_bg_height() / 2, text_center_x + text_bg_half_width,
        line_y + constants.getGoal_text_bg_height() / 2);
    canvas.drawRoundRect(rect_bg, constants.getGoal_text_bg_corner_radius(),
        constants.getGoal_text_bg_corner_radius(), p_text_bg);

    float tiangle_left_x = (float) (text_center_x
        - text_bg_half_width
        - constants.getGoal_text_bg_triangle_side_length() * Math.sqrt(3) / 2);
    Path path_triangle = new Path();
    path_triangle.setFillType(Path.FillType.EVEN_ODD);
    path_triangle.moveTo(tiangle_left_x, line_y);
    path_triangle.lineTo(text_center_x - text_bg_half_width + 1,
        line_y + constants.getGoal_text_bg_triangle_side_length() / 2);
    path_triangle.lineTo(text_center_x - text_bg_half_width + 1,
        line_y - constants.getGoal_text_bg_triangle_side_length() / 2);
    canvas.drawPath(path_triangle, p_text_bg);

    canvas.drawText(goalValue, scale_text_x, scale_text_y, tp_axis);
  }
}
