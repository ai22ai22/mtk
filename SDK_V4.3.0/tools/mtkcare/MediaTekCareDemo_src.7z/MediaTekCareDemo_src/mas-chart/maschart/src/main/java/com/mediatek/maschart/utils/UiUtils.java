package com.mediatek.maschart.utils;

import android.support.annotation.StringRes;
import android.util.TypedValue;
import com.mediatek.maschart.Charts;
import com.mediatek.maschart.ChartsLog;

public class UiUtils {

  public static String getString(@StringRes int resId) {
    return Charts.getApplicationContext().getString(resId);
  }

  public static int dpToPx(float dp){
    return (int) (dp * getDensity());
  }

  public static float spToPx(int sp) {
    return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,
        sp, Charts.getApplicationContext().getResources().getDisplayMetrics());
  }

  public static float getDensity(){
    return Charts.getApplicationContext().getResources().getDisplayMetrics().density;
  }

  public static int roundDown(String percentage) {
    try {
      Double p = Double.parseDouble(percentage);
      return (int) Math.floor(p);
    } catch (NumberFormatException e) {
      ChartsLog.e(e);
      return 0;
    }
  }
}