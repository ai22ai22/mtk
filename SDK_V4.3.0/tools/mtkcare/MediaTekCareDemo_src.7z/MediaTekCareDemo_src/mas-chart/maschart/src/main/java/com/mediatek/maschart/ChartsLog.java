package com.mediatek.maschart;

import android.util.Log;
//import com.splunk.mint.Mint;

public class ChartsLog {
  public static String TAG = "Charts";

  public static boolean isDebuggable() {
    return BuildConfig.DEBUG;
  }

  public static void v(String msg, Object... args) {
    if (isDebuggable()) Log.v(TAG, buildMessage(msg, args));
  }

  public static void d(String msg, Object... args) {
    if (isDebuggable()) Log.d(TAG, buildMessage(msg, args));
  }

  public static void e(String msg, Object... args) {
    if (isDebuggable()) Log.e(TAG, buildMessage(msg, args));
  }

  public static void e(Exception ex, Object... args) {
    if (isDebuggable()) {
      Log.e(TAG, buildMessage(ex.toString(), args), ex);
//      Mint.logException(ex);
    }
  }

  static String buildMessage(String msg, Object... args) {
    return msg;
  }
}