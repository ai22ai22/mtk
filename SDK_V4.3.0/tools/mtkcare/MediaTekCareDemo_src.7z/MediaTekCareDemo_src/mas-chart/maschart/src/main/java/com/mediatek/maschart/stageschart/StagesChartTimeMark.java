package com.mediatek.maschart.stageschart;

import android.graphics.Canvas;
import android.graphics.Path;
import com.mediatek.maschart.R;
import com.mediatek.maschart.paints.Alpha;
import com.mediatek.maschart.paints.DottedLinePaint;
import com.mediatek.maschart.paints.BlackTextPaint;
import com.mediatek.maschart.utils.DrawUtils;
import com.mediatek.maschart.utils.UiUtils;
import java.util.List;

public class StagesChartTimeMark {

  private final int STATUS_ASLEEP = 0;
  private final int STATUS_AWAKE = 1;

  private Canvas canvas;
  private float bar_width;
  private List<Integer> stages;
  private DottedLinePaint p_time_line;
  private BlackTextPaint tp_time;

  public StagesChartTimeMark(Canvas canvas, List<Integer> stages) {
    this.canvas = canvas;
    this.stages = stages;
    setPaint();
  }

  public void draw(String asleepTime, String awakeTime) {
    StagesChartConstant constant = new StagesChartConstant();
    bar_width = (canvas.getWidth()
        - constant.getHead_min_awake()
        - constant.getTail_min_awake()
        - constant.getHead_awake_margin_left()
        - constant.getTail_awake_margin_right())
        / stages.size();

    drawTime(STATUS_ASLEEP, asleepTime);
    drawTime(STATUS_AWAKE, awakeTime);
  }

  private void setPaint() {
    StagesChartConstant constant = new StagesChartConstant();

    p_time_line = new DottedLinePaint(R.color.charts_white, UiUtils.dpToPx(1), Alpha.HALF);

    tp_time = new BlackTextPaint(constant.getTime_text_size(), Alpha.HALF);
  }

  private void drawTime(int statusTag, String time) {
    StagesChartConstant constant = new StagesChartConstant();
    float line_x = (statusTag == STATUS_ASLEEP) ? getFirstAwakeDuration() : getLastAwakeDuration();
    float text_x = line_x - DrawUtils.getTextWidth(time, tp_time) / 2;
    float text_y = (statusTag == STATUS_ASLEEP) ?
        (constant.getAxis_margin_top()
            + constant.getAsleep_time_line_height()
            + constant.getTime_text_margin_line()
            + DrawUtils.getTextHeight(time, tp_time)) :
        (constant.getAxis_margin_top()
            - constant.getAwake_time_line_height()
            - constant.getTime_text_margin_line());
    float line_height = (statusTag == STATUS_ASLEEP) ?
        constant.getAsleep_time_line_height() :
        (-constant.getAwake_time_line_height());

    drawTimeLine(line_x, line_height);
    canvas.drawText(time, text_x, text_y, tp_time);
  }

  private float getFirstAwakeDuration() {
    StagesChartConstant constant = new StagesChartConstant();
    int nextStage;
    float chart_x_tail = constant.getHead_awake_margin_left()
        + constant.getHead_min_awake();
    float chart_x_head = constant.getHead_awake_margin_left()
        + constant.getHead_min_awake();

    for (int i = 0; i < stages.size() - 1; i++) {
      nextStage = stages.get(i + 1);
      chart_x_tail += bar_width;

      if (nextStage != StageType.AWAKE) {
        chart_x_head = chart_x_tail;
        break;
      }
    }
    return chart_x_head;
  }

  private float getLastAwakeDuration() {
    StagesChartConstant constant = new StagesChartConstant();
    int nextStage;
    float chart_x_tail = canvas.getWidth() - constant.getTail_awake_margin_right()
        - constant.getTail_min_awake();
    float chart_x_head = canvas.getWidth() - constant.getTail_awake_margin_right()
        - constant.getTail_min_awake();

    for (int i = stages.size() - 1; i > 0; i--) {
      nextStage = stages.get(i - 1);
      chart_x_head -= bar_width;

      if (nextStage != StageType.AWAKE) {
        chart_x_tail = chart_x_head;
        break;
      }
    }
    return chart_x_tail;
  }

  private void drawTimeLine(float axis_x, float time_line_height) {
    StagesChartConstant constant = new StagesChartConstant();
    float axis_y = constant.getAxis_margin_top();
    Path path = new Path();
    path.moveTo(axis_x, axis_y);
    path.lineTo(axis_x, axis_y + time_line_height);
    canvas.drawPath(path, p_time_line);
  }
}