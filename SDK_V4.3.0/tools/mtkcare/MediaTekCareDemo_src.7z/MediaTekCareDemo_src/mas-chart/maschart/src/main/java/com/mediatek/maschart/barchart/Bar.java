package com.mediatek.maschart.barchart;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.RectF;
import android.support.annotation.ColorRes;
import android.support.v4.content.ContextCompat;
import android.view.View;
import com.mediatek.maschart.Charts;
import com.mediatek.maschart.R;
import com.mediatek.maschart.paints.ColorPaint;
import com.mediatek.maschart.paints.BlackTextPaint;
import com.mediatek.maschart.utils.DrawUtils;


public class Bar extends View {
  public void setCanvas(Canvas canvas) {
    this.canvas = canvas;
  }

  public void setTopValue(int topValue) {
    this.topValue = topValue;
  }

  private Canvas canvas;
  private int topValue;
  final int INNER_MAX_VALUE = 23;

  /**
   * Default
   */
  private int inner_text_color = Charts.getApplicationContext().getResources().getColor(R.color.charts_white);
      //ContextCompat.getColor(Charts.getApplicationContext(), R.color.charts_white);

  private ColorPaint p_bar;
  private BlackTextPaint tp_inner;

  private int barColor;
  private int barShape;
  private boolean isValue;
  private float bar_interval;
  private float bar_width;
  private int bar_color_alpha;
  private int inner_text_color_alpha;
  private int date_text_color_alpha;
  private int inner_today_text_color;

  public Bar(Context context) {
    super(context);
  }

  public void setBarWidthAndInterval(float bar_width, float bar_interval) {
    this.bar_width = bar_width;
    this.bar_interval = bar_interval;
  }

  public void setInnerTodayTextColor(@ColorRes int colorResId) {
    inner_today_text_color = colorResId;
  }

  public void setIsBarInnerValueText(boolean isValue) {
    this.isValue = isValue;
  }

  public void setBarColor(@ColorRes int colorResId) {
    barColor = colorResId;
  }

  public void setBarShape(int barShape) {
    this.barShape = barShape;
  }

  public void setHighlighted(boolean isHighlighted, int barValue) {
    if (isHighlighted) {
      bar_color_alpha = 255;
      inner_text_color = ((float)(barValue * 100 / topValue) < INNER_MAX_VALUE) ?
          Color.WHITE : inner_today_text_color;
      inner_text_color_alpha = 255;
      date_text_color_alpha = 255;
    } else {
      bar_color_alpha = 255 / 2;
      inner_text_color = Color.WHITE;
      inner_text_color_alpha = 255 / 2;
      date_text_color_alpha = 255 / 2;
    }
  }

  public void draw(float position_x, int percentage, String innerValueStr) {
    BarChartConstant constant = new BarChartConstant();

    float chart_height = canvas.getHeight()
        - constant.getMargin_top()
        - constant.getMargin_bottom();
    float bottom_line_y = canvas.getHeight() - constant.getMargin_bottom();
    float bar_height = chart_height * percentage / topValue;
    float bar_top = bottom_line_y - bar_height + constant.getBar_corner_radius();

    setPaint();
    p_bar.setAlpha(bar_color_alpha);

    if (percentage > 0) {
      if (barShape == 0) {
        drawRectBar(position_x, bar_top, bottom_line_y);
      } else {
        if (bar_top < bottom_line_y - constant.getBar_corner_radius() / 2) {
          drawRoundRectBar(position_x, bar_top, bottom_line_y);
        }
      }
    }

    if (isValue == true) {
      if (percentage != -1) {
        drawInnerPercentage(position_x, bar_top, percentage, innerValueStr);
      }
    }
  }

  private void setPaint() {
    BarChartConstant constant = new BarChartConstant();
    p_bar = new ColorPaint(barColor);

    tp_inner = new BlackTextPaint(constant.getBar_inner_text_size());
  }

  private void drawRectBar(float position_x,  float bar_top, float bottom_line_y) {
    RectF bar_rect = new RectF(position_x,
        bar_top,
        position_x + bar_width,
        bottom_line_y);
    canvas.drawRect(bar_rect, p_bar);
  }

  private void drawRoundRectBar(float position_x,  float bar_top, float bottom_line_y) {
    BarChartConstant constant = new BarChartConstant();
    RectF main_rect = new RectF(position_x,
        bar_top + constant.getBar_corner_radius(),
        position_x + bar_width,
        bottom_line_y);
    canvas.drawRect(main_rect, p_bar);

    RectF top_rect = new RectF(position_x + constant.getBar_corner_radius(),
        bar_top,
        position_x + bar_width - constant.getBar_corner_radius(),
        bar_top + constant.getBar_corner_radius());
    canvas.drawRect(top_rect, p_bar);

    RectF top_left_arc = new RectF(position_x,
        bar_top,
        position_x + constant.getBar_corner_radius() * 2,
        bar_top + constant.getBar_corner_radius() * 2);
    canvas.drawArc(top_left_arc, -180, 90, true, p_bar);

    RectF top_right_arc = new RectF(
        position_x + bar_width - constant.getBar_corner_radius() * 2,
        bar_top,
        position_x + bar_width,
        bar_top + constant.getBar_corner_radius() * 2);
    canvas.drawArc(top_right_arc, -90, 90, true, p_bar);
  }

  private void drawInnerPercentage(float position_x, float position_y, int innerValue, String innerValueStr) {
    BarChartConstant constant = new BarChartConstant();

    float text_x = position_x
        + bar_width / 2
        - DrawUtils.getTextWidth(innerValueStr, tp_inner) / 2 - 1;

    float text_y = ((float)(innerValue * 100 / topValue) < INNER_MAX_VALUE) ?
        (position_y
            - constant.getBar_corner_radius() * 2
            - constant.getInner_percentage_margin_bottom()) :
        (position_y
            + constant.getInner_percentage_margin_top()
            + DrawUtils.getTextHeight(innerValueStr, tp_inner) * 3 / 2);

    tp_inner.setColor(inner_text_color);
    tp_inner.setAlpha(inner_text_color_alpha);
    canvas.drawText(innerValueStr, text_x, text_y, tp_inner);
  }
}

