package com.mediatek.maschart.barchart;

public class BarChartType {
  public static int DAY = 0;
  public static int WEEK = 1;
  public static int MONTH = 2;
}
