package com.mediatek.maschart.paints;

import android.graphics.Paint;
import android.support.annotation.ColorRes;
import android.support.v4.content.ContextCompat;
import com.mediatek.maschart.Charts;
import com.mediatek.maschart.R;

public class ColorPaint extends Paint {

  public ColorPaint(@ColorRes int colorResId) {
    this(colorResId, Alpha.OPAQUE);
  }

  public ColorPaint(@ColorRes int colorResId, int alpha) {
    setColor(Charts.getApplicationContext().getResources().getColor(colorResId)
    //ContextCompat.getgetColor(Charts.getApplicationContext(), colorResId)
    );
    setStyle(Style.FILL);
    setAlpha(alpha);
    setAntiAlias(true);
  }
}
