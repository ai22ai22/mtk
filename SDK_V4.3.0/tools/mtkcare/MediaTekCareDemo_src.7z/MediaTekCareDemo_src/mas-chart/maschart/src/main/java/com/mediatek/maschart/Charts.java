package com.mediatek.maschart;

import android.content.Context;

public class Charts {
  public static Context getApplicationContext() {
    return applicationContext;
  }

  public static Context applicationContext;

  public static void init(Context context) {
    applicationContext = context;
  }
}
