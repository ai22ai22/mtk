package com.mediatek.maschart.stageschart;

public class StageType {

  public static final int AWAKE = 0;
  public static final int STEP_ONE = -1;
  public static final int STEP_TWO = -2;
  public static final int STEP_THREE = -3;
}
