package com.mediatek.iot.events;

public class RequestWriteToDevice {

  private final byte[] bytes;

  public RequestWriteToDevice(byte[] bytes) {
    this.bytes = bytes;
  }

  public byte[] getBytes() {
    return bytes;
  }
}
