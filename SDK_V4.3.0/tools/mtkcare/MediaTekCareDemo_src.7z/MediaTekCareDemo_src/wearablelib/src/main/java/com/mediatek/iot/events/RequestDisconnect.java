package com.mediatek.iot.events;

public class RequestDisconnect {
  public RequestDisconnect(){

  }
}
