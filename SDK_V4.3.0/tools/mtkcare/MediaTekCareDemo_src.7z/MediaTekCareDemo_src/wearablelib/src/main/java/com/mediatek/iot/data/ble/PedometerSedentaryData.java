package com.mediatek.iot.data.ble;

import java.io.IOException;

public class PedometerSedentaryData extends BLEBaseData {
  private int positive;

  protected PedometerSedentaryData(byte[] bytes) throws IOException {
    super(bytes);
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    positive = bytes[0] & 0xFF;
  }

  @Override protected String toStringBody() {
    return String.format("positive: %d", positive);
  }
}
