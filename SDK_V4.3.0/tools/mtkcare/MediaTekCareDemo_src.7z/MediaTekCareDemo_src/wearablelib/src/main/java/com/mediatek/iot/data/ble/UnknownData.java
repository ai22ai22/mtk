package com.mediatek.iot.data.ble;

import com.mediatek.iot.utils.DataConverter;
import java.io.IOException;

public class UnknownData extends BLEBaseData {
  private byte[] bytes;
  protected UnknownData(byte[] bytes) throws IOException {
    super(bytes);
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    this.bytes = bytes;
  }

  @Override protected String toStringBody() {
    return DataConverter.bytesToHex(bytes ,',');
  }
}
