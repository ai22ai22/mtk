package com.mediatek.iot.data.ble;

import java.io.IOException;

public class ProfileData extends BLEBaseData {
  private int age;
  private int gender;
  private int height;
  private int weight;
  private int armLength;

  protected ProfileData(byte[] bytes) throws IOException {
    super(bytes);
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    int i = 0;
    age = bytes[i ++] & 0xFF;
    gender = bytes[i ++] & 0xFF;
    height = bytes[i ++] & 0xFF;
    weight = bytes[i ++] & 0xFF;
    armLength = bytes[i ++] & 0xFF;

  }

  @Override protected String toStringBody() {
    return String.format("age:%d, gender:%d, height:%d, weight:%d, armLength:%d", age, gender,height,weight,armLength);
  }
}
