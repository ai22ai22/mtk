package com.mediatek.iot.adapter;

import android.content.Context;
import com.mediatek.iot.Device;
import com.mediatek.iot.command.BaseCommand;
import com.mediatek.iot.data.DataParser;
import com.mediatek.iot.events.AdapterStateChange;
import com.mediatek.iot.events.ReceiveData;
import com.mediatek.iot.events.RequestConnect;
import com.mediatek.iot.events.RequestDisconnect;
import com.mediatek.iot.events.RequestWriteToDevice;
import com.mediatek.utils.RxBus;
import rx.Observable;
import rx.Subscriber;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class AdapterDevice extends Device {

  public AdapterDevice(Context applicationContext, DataParser dataParser) {
    super(applicationContext, dataParser);
    RxBus.getInstance()
        .toObservable(AdapterStateChange.class)
        .subscribe(new Action1<AdapterStateChange>() {
          @Override public void call(AdapterStateChange adapterStateChange) {
            setState(adapterStateChange.getState());
          }
        });

    RxBus.getInstance()
        .toObservable(ReceiveData.class)
        .observeOn(Schedulers.io())
        .subscribe(new Action1<ReceiveData>() {
          @Override public void call(ReceiveData receiveData) {
            byte[] data = receiveData.getBytes();
            for (int i = 0; i < data.length; ) {
              int j = Math.min(data.length, i + 64);
              byte[] buffer = new byte[j - i];
              System.arraycopy(data, i, buffer, 0, j - i);
              dataAvailable(buffer);
              i = j;
            }
          }
        });
  }

  @Override public void connect(String address) {
    RxBus.getInstance().post(new RequestConnect(address));
  }

  @Override public void disconnect() {
    RxBus.getInstance().post(new RequestDisconnect());
  }

  @Override public Observable writeToDevice(final BaseCommand baseCommand) {
    return Observable.create(new Observable.OnSubscribe<Boolean>() {
      @Override public void call(Subscriber<? super Boolean> subscriber) {
         RxBus.getInstance().post(new RequestWriteToDevice(baseCommand.toBytes()));
        subscriber.onCompleted();
      }
    });

  }

}
