package com.mediatek.iot.data.ble;

import com.mediatek.iot.utils.DataConverter;
import java.io.ByteArrayInputStream;
import java.io.IOException;

public class HRVData extends BLEBaseData {
  private int lf;
  private int hf;
  private int lfhf;
  private int sdnn;
  private int hr;

  protected HRVData(byte[] bytes) throws IOException {
    super(bytes);
  }

  public int getHf() {
    return hf;
  }

  public int getHr() {
    return hr;
  }

  public int getLf() {
    return lf;
  }

  public int getLfhf() {
    return lfhf;
  }

  public int getSdnn() {
    return sdnn;
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    if (bytes.length < 17) {
      throw new IOException("data format error :<17 " + bytes.length);
    }
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
    byte[] buffer = new byte[4];
    byteArrayInputStream.read(buffer);
    lf = DataConverter.bytesToInt(buffer);

    byteArrayInputStream.read(buffer);
    hf = DataConverter.bytesToInt(buffer);

    byteArrayInputStream.read(buffer);
    lfhf = DataConverter.bytesToInt(buffer);

    byteArrayInputStream.read(buffer);
    sdnn = DataConverter.bytesToInt(buffer);

    hr = byteArrayInputStream.read() & 0xFF;
  }

  public boolean isValid() {
    return getSdnn() > 0 && getLf() > 0 && getHf() > 0 && getLfhf() > 0;
  }

  @Override protected String toStringBody() {
    return String.format("lf:%d, hf:%d, lfhf:%d, sdnn:%d, hr:%d", lf, hf, lfhf, sdnn, hr);
  }
}
