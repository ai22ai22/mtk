package com.mediatek.iot.data.ble;

import com.mediatek.iot.utils.DataConverter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CalibrationResultData extends BLEBaseData {
  private List<Integer> paras;

  protected CalibrationResultData(byte[] bytes) throws IOException {
    super(bytes);
  }

  public List<Integer> getParas() {
    return paras;
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    if (bytes.length % 4 != 0) {
      throw new IOException(String.format("%s data format invalid", getClass().getSimpleName()));
    }
    byte[][] data = DataConverter.splitBytes(bytes, 0, 4);
    paras = new ArrayList<>();

    for (byte[] d : data) {
      paras.add(DataConverter.bytesToInt(d));
    }
  }

  @Override protected String toStringBody() {
    return String.format("paras:%s", Arrays.toString(paras.toArray()));
  }
}
