package com.mediatek.iot.events;

public class AdapterStateChange {
  private final int state;

  public AdapterStateChange(int state) {
    this.state = state;
  }

  public int getState() {
    return state;
  }
}
