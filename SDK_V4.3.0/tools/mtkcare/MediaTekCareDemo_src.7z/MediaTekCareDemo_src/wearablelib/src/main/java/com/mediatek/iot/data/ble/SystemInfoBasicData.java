package com.mediatek.iot.data.ble;

import com.mediatek.iot.utils.DataConverter;
import java.io.IOException;

public class SystemInfoBasicData extends BLEBaseData {

  private int batteryPercentage;
  private String firmwareVersion;

  public SystemInfoBasicData(byte[] bytes) throws IOException {
    super(bytes);
  }

  public String getFirmwareVersion() {
    return firmwareVersion;
  }

  public int getBatteryPercentage() {
    return batteryPercentage;
  }


  @Override protected void parseValue(byte[] bytes) throws IOException {
    batteryPercentage = bytes[0] & 0xFF;
    firmwareVersion =  String.format("%d.%d", bytes[2] & 0xff, bytes[1] & 0xff);
  }

  @Override protected String toStringBody() {
    return String.format("batteryPercentage:%d, firmwareVersion:%s", batteryPercentage,
        firmwareVersion);
  }
}
