package com.mediatek.iot.data.ble;

import com.mediatek.iot.utils.DataConverter;
import java.io.IOException;
import java.util.Arrays;

public class SleepFeatureData extends BLEBaseData {
  private int dataTimestamp;
  private int[] paras;
  protected SleepFeatureData(byte[] bytes) throws IOException {
    super(bytes);
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    if (bytes.length <4 || (bytes.length -4) % 2 != 0) {
      throw new IOException(String.format("%s data format invalid", getClass().getSimpleName()));
    }
    byte[] buffer= new byte[4];
    System.arraycopy(bytes, 0, buffer, 0 ,4);
    dataTimestamp = DataConverter.bytesToInt(buffer);
    byte[][] data = DataConverter.splitBytes(bytes, 4, 2);
    paras = new int[data.length];
    for(int i =0;i < data.length; ++i){
      paras[i] = DataConverter.bytesToInt(data[i]);
    }
  }

  @Override protected String toStringBody() {
    return String.format("dataTimestamp:%d, paras:%s ", dataTimestamp, Arrays.toString(paras));
  }
}
