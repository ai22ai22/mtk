package com.mediatek.iot.data;

public class InputRawData {
  public InputRawData(byte[] bytes) {
  }
}
