package com.mediatek.iot.events;

public class ReceiveData {

  private final byte[] bytes;

  public ReceiveData(byte[] bytes) {
    this.bytes = bytes;
  }

  public byte[] getBytes() {
    return bytes;
  }
}
