package com.mediatek.iot.data.ble;

import java.io.IOException;

public class SystemInfoSignalQualityData extends BLEBaseData {
  private int positive;

  public SystemInfoSignalQualityData(byte[] bytes) throws IOException {
    super(bytes);
  }

  public int getPositive() {
    return positive;
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    positive = bytes[0] & 0xFF;
  }

  @Override public String toStringBody() {
    return String.format("%d", positive);
  }
}
