package com.mediatek.iot.data.ble;

import java.io.IOException;

public class ReturnData extends BLEBaseData {
  private int commandId;
  private int responseCode;

  protected ReturnData(byte[] bytes) throws IOException {
    super(bytes);
  }

  public int getCommandId() {
    return commandId;
  }

  public int getResponseCode() {
    return responseCode;
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    if (bytes.length < 2) {
      throw new IOException("data format error:" + bytes.length);
    }
    commandId = bytes[0] & 0xFF;
    responseCode = bytes[1] & 0xFF;
  }

  @Override protected String toStringBody() {
    return String.format("commandId:%d (%s)hex, responseCode:%d",  commandId,
        Integer.toString(commandId, 16), responseCode);
  }
}
