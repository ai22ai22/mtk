package com.mediatek.iot.ble;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Build;
import com.mediatek.iot.Device;
import com.mediatek.iot.WearableLog;
import com.mediatek.iot.command.BaseCommand;
import com.mediatek.iot.data.BaseData;
import com.mediatek.iot.data.DataParser;
import com.mediatek.iot.utils.DataConverter;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import rx.Observable;
import rx.Subscriber;
import rx.Subscription;
import rx.functions.Action1;
import rx.subjects.PublishSubject;
import rx.subscriptions.CompositeSubscription;

public class BLEDevice extends Device {
  private static final int DATA_STATE_CHARACTERISTIC_WRITE = 1;
  private static final int PACKAGE_SIZE_COMMAND_WRITE = 20; // max size :20 bytes
  private final Object mWriteToDeviceLock = new Object();
  private final LinkedBlockingQueue<BaseCommand> mCommandQueue =
      new LinkedBlockingQueue<BaseCommand>();
  private UUID uuid_service;
  private UUID uuid_characteristic;
  private int interval_reconnect = 60000;
  private boolean config_auto_reconnect = true;
  private BluetoothGattCharacteristic mCharacteristic;
  private BluetoothManager mBluetoothManager;
  private BluetoothAdapter mBluetoothAdapter;
  private PublishSubject<Integer> mDataStateSubject = PublishSubject.create();
  private Subscription mReconnectSubscription;
  private CompositeSubscription mSubscriptions = new CompositeSubscription();
  private BluetoothGatt mBluetoothGatt;
  private String mBluetoothDeviceAddress;
  private boolean bAutoConnect = true;
  private WriteToDeviceThread mCommandThread;
  private int mWriteToDeviceStatus;
  private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {


    @Override public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
      if (newState == BluetoothProfile.STATE_CONNECTED) {
        setState(STATE_CONNECTED);
        bAutoConnect = true;
        WearableLog.i("Connected to GATT server.");
        // Attempts to discover services after successful connection.
        WearableLog.i("Attempting to start service discovery:%s", mBluetoothGatt.discoverServices());
      } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
        setState(STATE_DISCONNECTED);
        WearableLog.i("Disconnected from GATT server.");
        if (bAutoConnect && config_auto_reconnect) {
          reconnect();
        }
      }
    }

    @Override public void onServicesDiscovered(BluetoothGatt gatt, int status) {
      WearableLog.v("onServicesDiscovered received: %d", status);
      if (status == BluetoothGatt.GATT_SUCCESS) {
        discovered();
      }
    }

    @Override
    public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic,
        int status) {
      if (status == BluetoothGatt.GATT_SUCCESS) {
        dataAvailable(characteristic.getValue());
      }
    }

    @Override public void onCharacteristicChanged(BluetoothGatt gatt,
        BluetoothGattCharacteristic characteristic) {
      dataAvailable(characteristic.getValue());
    }

    @Override public void onCharacteristicWrite(BluetoothGatt gatt,
        BluetoothGattCharacteristic characteristic, int status) {
      mDataStateSubject.onNext(DATA_STATE_CHARACTERISTIC_WRITE);

      synchronized (mWriteToDeviceLock) {
        WearableLog.v("onCharacteristicWrite %d", status);
        mWriteToDeviceStatus = status;
        mWriteToDeviceLock.notify();
      }
    }

    @Override public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor,
        int status) {
      super.onDescriptorWrite(gatt, descriptor, status);
      WearableLog.v("onDescriptorWrite");
      startCommandThread();
    }

    @Override public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor,
        int status) {
      WearableLog.v("onDescriptorRead status:%d", status);
    }

    @Override public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
      WearableLog.v("onMtuChanged mtu:%d, status:%d", mtu, status);
    }

    @Override public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
      WearableLog.v("onReadRemoteRssi rssi:%d, status:%d", rssi, status);
    }

    @Override public void onReliableWriteCompleted(BluetoothGatt gatt, int status) {
      WearableLog.v("onReliableWriteCompleted  status:%d", status);

    }
  };

  private void startCommandThread() {
    mCommandThread = new WriteToDeviceThread();
    mCommandThread.start();
  }

  public BLEDevice(Context applicationContext, DataParser dataParser, BLEDeviceParams params) {
    super(applicationContext, dataParser);
    mBluetoothManager = (BluetoothManager) mContext.getSystemService(Context.BLUETOOTH_SERVICE);
    mBluetoothAdapter = mBluetoothManager.getAdapter();
    uuid_service = UUID.fromString(params.serviceUUID);
    uuid_characteristic = UUID.fromString(params.characteristicUUID);
    config_auto_reconnect = params.autoReconnect;
    interval_reconnect = params.intervalReconnect;
  }

  private void reconnect() {
    WearableLog.v("Reconnect......");
    mReconnectSubscription = Observable.just(true)
        .delay(interval_reconnect, TimeUnit.MILLISECONDS)
        .subscribe(new Action1<Boolean>() {
          @Override public void call(Boolean aBoolean) {
            close();
            connect(mBluetoothDeviceAddress);
          }
        });
  }

  private void discovered() {
    enableIndication();
  }

  private void enableIndication() {
    WearableLog.v("enableIndication");
    BluetoothGattService gattService = mBluetoothGatt.getService(uuid_service);
    if (gattService == null) {
      return;
    }
    mCharacteristic = gattService.getCharacteristic(uuid_characteristic);
    if (mCharacteristic == null) {
      return;
    }
    mBluetoothGatt.setCharacteristicNotification(mCharacteristic, true);
    for (BluetoothGattDescriptor descriptor : mCharacteristic.getDescriptors()) {
      if ((mCharacteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_INDICATE)
          == BluetoothGattCharacteristic.PROPERTY_INDICATE) {
        descriptor.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
        mBluetoothGatt.writeDescriptor(descriptor);
      }
    }

    if (SampleGattAttributes.HEART_RATE_MEASUREMENT.equalsIgnoreCase(
        mCharacteristic.getUuid().toString())) {
      BluetoothGattDescriptor descriptor = mCharacteristic.getDescriptor(
          UUID.fromString(SampleGattAttributes.CLIENT_CHARACTERISTIC_CONFIG));
      descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
      mBluetoothGatt.writeDescriptor(descriptor);
    }
  }

  @Override public void connect(String address) {
    super.connect(address);
    WearableLog.v("connect :%s", address);
    close();
    if (mBluetoothAdapter == null || address == null) {
      WearableLog.w("BluetoothAdapter not initialized or unspecified address.");
      return;
    }
    // Previously connected device.  Try to reconnect.
    if (mBluetoothDeviceAddress != null
        && address.equals(mBluetoothDeviceAddress)
        && mBluetoothGatt != null) {
      WearableLog.d("Trying to use an existing mBluetoothGatt for connection.");
      boolean b = mBluetoothGatt.connect();
      if (b) {
        setState(STATE_CONNECTING);
        return;
      } else {
        return;
      }
    }

    final BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
    if (device == null) {
      WearableLog.w("Device not found.  Unable to connect.");
      return;
    }
    // We want to directly connect to the device, so we are setting the autoConnect
    // parameter to false.
    mBluetoothGatt = device.connectGatt(mContext, false, mGattCallback);
    WearableLog.d("Trying to create a new connection.");
    mBluetoothDeviceAddress = address;
    setState(STATE_CONNECTING);
    return;
  }

  @Override public synchronized void disconnect() {
    bAutoConnect = false;
    if(mReconnectSubscription != null) {
      mReconnectSubscription.unsubscribe();
    }
    setState(STATE_DISCONNECTED);
    if (mBluetoothAdapter == null || mBluetoothGatt == null) {
      WearableLog.w("BluetoothAdapter not initialized");
      return;
    }
    mBluetoothGatt.disconnect();
  }

  public void close() {
    if (mReconnectSubscription != null) {
      mReconnectSubscription.unsubscribe();
    }
    if (mBluetoothGatt == null) {
      return;
    }
    mBluetoothGatt.close();
    mBluetoothGatt = null;
  }

  @Override public Observable<Boolean> writeToDevice(final BaseCommand baseCommand) {
    return Observable.create(new Observable.OnSubscribe<Boolean>() {
      @Override public void call(Subscriber<? super Boolean> subscriber) {
        try {
          WearableLog.v("write_to_device_q:%s", baseCommand.getClass().getSimpleName());
          baseCommand.setError(null);
          mCommandQueue.add(baseCommand);
          synchronized (baseCommand){
            baseCommand.wait();
          }
          if(baseCommand.getError() != null){
            subscriber.onError(baseCommand.getError());
          }else {
            subscriber.onNext(true);
            subscriber.onCompleted();
          }
        } catch (Exception e) {
          subscriber.onError(e);
        }
      }
    });
  }

  @Override protected synchronized void reset() {
    WearableLog.v("reset");
    mSubscriptions.clear();
    if (mCommandThread != null) {
      mCommandThread.interrupt();
      mCommandThread = null;
      synchronized (mWriteToDeviceLock) {
        mWriteToDeviceLock.notifyAll();
      }
      mCommandQueue.clear();
     // mCommandQueue.add(new StopQueueCommand()); // mark to stop thread;
    }
    mCharacteristic = null;
  }

  public static class BLEDeviceParams {
    public static final BLEDeviceParams BAND_DEFAULT;

    static {
      BAND_DEFAULT = new BLEDeviceParams("000018aa-0000-1000-8000-00805f9b34fb",
          "00002aaa-0000-1000-8000-00805f9b34fb", true, 60000);
    }

    protected String serviceUUID;
    protected String characteristicUUID;
    protected boolean autoReconnect;
    protected int intervalReconnect;

    protected BLEDeviceParams() {

    }

    public BLEDeviceParams(String serviceUUID, String characteristicUUID, boolean autoReconnect,
        int intervalReconnect) {
      this.serviceUUID = serviceUUID;
      this.characteristicUUID = characteristicUUID;
      this.autoReconnect = autoReconnect;
      this.intervalReconnect = intervalReconnect;
    }

    public String getServiceUUID() {
      return serviceUUID;
    }

    public String getCharacteristicUUID() {
      return characteristicUUID;
    }

    public int getIntervalReconnect() {
      return intervalReconnect;
    }

    public boolean isAutoReconnect() {

      return autoReconnect;
    }
  }

  public static class Builder {
    private BLEDeviceParams params = new BLEDeviceParams();

    public Builder setServiceUUID(String uuid) {
      params.serviceUUID = uuid;
      return this;
    }

    public Builder setCharacteristicUUID(String uuid) {
      params.characteristicUUID = uuid;
      return this;
    }

    public Builder setAutoReconnect(boolean autoReconnect, int intervalReconnect) {
      params.autoReconnect = autoReconnect;
      params.intervalReconnect = intervalReconnect;
      return this;
    }

    public BLEDevice create(Context applicationContext, DataParser dataParser) {
      return new BLEDevice(applicationContext, dataParser, params);
    }
  }

  private static class StopQueueCommand extends BaseCommand {

    @Override public InputStream getInputStream() {
      return null;
    }

    @Override public boolean isResponseData(BaseData baseData) {
      return false;
    }

    @Override public boolean isOKResponse(BaseData returnData) {
      return false;
    }
  }

  private class WriteToDeviceThread extends Thread {
    public WriteToDeviceThread() {
      super();
      setName("BLE-Command-Thread");
    }

    @Override public void run() {
      WearableLog.i(getName() + " --start");
      try {
        while (!isInterrupted()) {
          WearableLog.i("write_to_device_q,queue size:%d", mCommandQueue.size());
          BaseCommand command = mCommandQueue.take();
          if (command instanceof StopQueueCommand) {
            WearableLog.i("StopQueueCommand");
            break;
          }
          WearableLog.v("write_to_device_start:%s", command.toString());
          byte[] buffer = new byte[PACKAGE_SIZE_COMMAND_WRITE];
          int bufferIndex = 0;
          try {
            InputStream inputStream = command.getInputStream();
            int readLen;
            int packageIndex = 0;
            while (true) {
              if (interrupted()) {
                throw new IOException("thread is interrupted");
              }
              readLen = inputStream.read(buffer, bufferIndex, buffer.length - bufferIndex);
              if (readLen > 0) {
                bufferIndex += readLen;
              }
              if ((bufferIndex == buffer.length) || (readLen < 0 && bufferIndex > 0)) {
                byte[] temp = new byte[bufferIndex];
                System.arraycopy(buffer, 0, temp, 0, bufferIndex);
                synchronized (BLEDevice.this) {
                  if (mCharacteristic == null) {
                    WearableLog.i("connection is reset.");
                    break;
                  }
                  mCharacteristic.setValue(temp);
                  WearableLog.v("write_to_device_send_packaging...... %d -- %s", packageIndex++,
                      DataConverter.bytesToHex(temp, ','));
                  if (!mBluetoothGatt.writeCharacteristic(mCharacteristic)) {
                    WearableLog.e("write_to_device_send_error %s", command.toString());
                    throw new IOException("can not write to device");
                  }
                }
                synchronized (mWriteToDeviceLock) {
                  mWriteToDeviceLock.wait();
                }
                if (mWriteToDeviceStatus != BluetoothGatt.GATT_SUCCESS){
                  WearableLog.e("write_to_device_send_error ", mWriteToDeviceStatus);
                  throw new IOException("can not write to device");

                }
                bufferIndex = 0;
              }
              if (readLen < 0) {
                break;
              }
            }
          } catch (IOException e) {
            e.printStackTrace();
            WearableLog.e(e, e.getMessage());
            command.setError(e);
          }
          synchronized (command) {
            command.notify();
          }
        }
        WearableLog.i(getName() + " --stop");
      } catch (InterruptedException e) {
        e.printStackTrace();
        WearableLog.e(e, e.getMessage());
        WearableLog.i(getName() + " --stop");
      }
    }
  }
}