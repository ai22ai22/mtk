package com.mediatek.iot.data.ble;

import java.io.IOException;

public class EngineeringModeData extends BLEBaseData {
  private boolean isEnabled;

  public EngineeringModeData(byte[] bytes) throws IOException {
    super(bytes);
  }

  public boolean isEnabled() {
    return isEnabled;
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    isEnabled = bytes[0] == 0x01;
  }

  @Override protected String toStringBody() {
    return String.format("isEnabled:%s", isEnabled);
  }
}
