package com.mediatek.iot.data.ble;

import java.io.IOException;

public class SystemInfoNotifySwitchData extends BLEBaseData {
  public final static int SWITCH_THEATER =                0b00000001;
  public final static int SWITCH_DAILY_GOAL_ACHIEVED =  0b00000010;
  public final static int SWITCH_SEDENTARY =              0b00000100;
  public final static int SWITCH_WEARING_LOOSE =          0b00010000;
  public final static int SWITCH_PHONE_RANG =              0b00100000;

  private int iSwitch;
  protected SystemInfoNotifySwitchData(byte[] bytes) throws IOException {
    super(bytes);
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    iSwitch = (bytes[0] & 0xFF) | ((bytes[1] & 0xFF) << 8);
  }
  public int getSwitch(){
    return iSwitch;
  }
  @Override protected String toStringBody() {
    return String.format("switch: %2x", iSwitch);
  }
}
