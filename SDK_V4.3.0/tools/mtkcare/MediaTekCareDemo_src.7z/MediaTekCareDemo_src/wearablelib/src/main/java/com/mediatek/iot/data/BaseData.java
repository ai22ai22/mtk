package com.mediatek.iot.data;


public abstract class BaseData {
  public BaseData(){

  }
}
