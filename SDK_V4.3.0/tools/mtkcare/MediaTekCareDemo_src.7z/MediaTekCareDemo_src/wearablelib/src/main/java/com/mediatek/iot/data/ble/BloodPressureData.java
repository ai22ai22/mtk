package com.mediatek.iot.data.ble;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Arrays;

public class BloodPressureData extends BLEBaseData {
  private int sys;
  private int dias;
  private int hr;
  private int[] pwtts;

  protected BloodPressureData(byte[] bytes) throws IOException {
    super(bytes);
  }

  public int getDias() {
    return dias;
  }

  public int getHr() {
    return hr;
  }

  public int[] getPwtts() {
    return pwtts;
  }

  public int getSys() {
    return sys;
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
    sys = byteArrayInputStream.read() & 0xFF;
    dias = byteArrayInputStream.read() & 0xFF;
    hr = byteArrayInputStream.read() & 0xFF;
    pwtts = new int[byteArrayInputStream.available()];
    int pwtt;
    int i = 0;
    while ((pwtt = byteArrayInputStream.read()) > -1) {
      pwtts[i++] = pwtt & 0xFF;
    }
  }

  public boolean isValid() {
    return getSys() > 0 && getSys() < 255 &&
        getDias() > 0 && getDias() < 255;
  }

  @Override protected String toStringBody() {
    return String.format("sys:%d, dias:%d, hr:%d, pwtt:%s", sys, dias, hr, Arrays.toString(pwtts));
  }
}
