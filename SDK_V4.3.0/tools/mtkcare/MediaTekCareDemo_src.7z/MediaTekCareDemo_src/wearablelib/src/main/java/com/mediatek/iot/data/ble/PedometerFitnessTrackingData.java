/*package com.mediatek.iot.data.ble;

import com.mediatek.iot.utils.DataConverter;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;

public class PedometerFitnessTrackingData extends BLEBaseData {
  private int endTime;
  private FitnessTracking[] fitnessTracking;

  protected PedometerFitnessTrackingData(byte[] bytes) throws IOException {
    super(bytes);
  }

  public int getEndTime() {
    return endTime;
  }

  public FitnessTracking[] getFitnessTracking() {
    return fitnessTracking;
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
    byte[] buffer = new byte[4];
    byteArrayInputStream.read(buffer);
    endTime = DataConverter.bytesToInt(buffer);
    ArrayList<FitnessTracking> list = new ArrayList<>();
    while (byteArrayInputStream.available() > 0) {
      list.add(new FitnessTracking(byteArrayInputStream));
    }
    fitnessTracking = list.toArray(new FitnessTracking[list.size()]);
  }

  @Override protected String toStringBody() {
    return String.format("endTime: %d, fitnessTracking:%s",endTime, Arrays.toString(fitnessTracking));
  }

  public static class FitnessTracking {
    private int hourlyStep;
    private int runStepCount;
    private int hourlyWalkDuration;
    private int hourlyRunDuration;

    public FitnessTracking(InputStream inputStream) throws IOException {
      hourlyStep = read2ByteToInt(inputStream);
      runStepCount = read2ByteToInt(inputStream);
      hourlyWalkDuration = read2ByteToInt(inputStream);
      hourlyRunDuration = read2ByteToInt(inputStream);
    }

    public int getHourlyRunDuration() {
      return hourlyRunDuration;
    }

    public int getHourlyStep() {
      return hourlyStep;
    }

    public int getHourlyWalkDuration() {
      return hourlyWalkDuration;
    }

    public int getRunStepCount() {
      return runStepCount;
    }

    private int read2ByteToInt(InputStream inputStream) throws IOException {
      byte[] buffer = new byte[2];
      int len = inputStream.read(buffer);
      if (len == 2) {
        return DataConverter.bytesToInt(buffer);
      } else {
        throw new IOException("data format error len:" + len);
      }
    }

    @Override public String toString() {
      return String.format("hourlyStep:%d, runStepCount:%d, hourlyWalkDuration:%d, hourlyRunDuration:%d",hourlyStep, runStepCount, hourlyWalkDuration, hourlyRunDuration);
    }
  }
}*/
