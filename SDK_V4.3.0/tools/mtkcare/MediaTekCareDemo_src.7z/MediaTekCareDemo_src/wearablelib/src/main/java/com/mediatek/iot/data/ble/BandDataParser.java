package com.mediatek.iot.data.ble;

import com.mediatek.iot.WearableLog;
import com.mediatek.iot.data.BaseData;
import com.mediatek.iot.data.DataParser;
import com.mediatek.iot.utils.DataConverter;
import java.io.IOException;

public class BandDataParser extends DataParser {
  private byte[] dataBuffer;
  private int dataBufferIndex;

  @Override protected BaseData parseData(byte[] data) throws IOException {
    int alg_feature_id = ((data[0] & 0xFF) << 8) | data[6];
    BaseData baseData;
    switch (alg_feature_id) {
      case 0x0101:
      case 0x0102: {
        baseData = new HeartRateData(data);
        break;
      }
      case 0x0201:{
        baseData =  new SleepTrackerData(data);
        break;
      }
      case 0x0202: {
        baseData =  new SleepFeatureData(data);
        break;
      }
      case 0x0401: {
        baseData =  new HRVData(data);
        break;
      }
      case 0x0501: {
        baseData =new BloodPressureData(data);
        break;
      }
      case 0x0601:{
        baseData =new CalibrationResultData(data);
        break;
      }
      case 0x4001: {
        baseData =new  PedometerRealTimeData(data);
        break;
      }
      case 0x4003: {
        baseData =  new PedometerSedentaryData(data);
        break;
      }
      case 0x6001: {
        baseData =  new SystemInfoBasicData(data);
        break;
      }
      case 0x6002: {
        baseData =  new SystemInfoSignalQualityData(data);
        break;
      }
      case 0x6003: {
        baseData =  new SystemInfoNotifySwitchData(data);
        break;
      }
      case 0x6004: {
        baseData =  new EngineeringModeData(data);
        break;
      }
      case 0x6005:{
        baseData =  new SystemInfoModeDurationData(data);
        break;
      }
      case 0x6006: {
        baseData =  new SystemInfoHistoryStatusData(data);
        break;
      }
      case 0x7001: {
        baseData =  new SystemInfoGoalData(data);
        break;
      }
      case 0x7101:{
        baseData =  new ProfileData(data);
        break;
      }
      case 0xfe01: {
        baseData =  new ReturnData(data);
        break;
      }
      default: {
        baseData =  new UnknownData(data);
        break;
      }
    }
    WearableLog.v("%s",baseData.toString());
    return baseData;
  }

  @Override public void receiveData(byte[] buffer) {
    if (buffer != null && buffer.length > 0) {
      WearableLog.v("dataAvailable: %s", DataConverter.bytesToHex(buffer ,','));
      if (dataBuffer == null) {
        int dataLength = buffer[1] & 0xFF;
        if (dataLength == buffer.length) {
          postData(buffer);
          dataBufferIndex = 0;
        } else {
          dataBuffer = new byte[dataLength];
          System.arraycopy(buffer, 0, dataBuffer, 0, buffer.length);
          dataBufferIndex = buffer.length;
        }
      } else {
        System.arraycopy(buffer, 0, dataBuffer, dataBufferIndex, buffer.length);
        dataBufferIndex += buffer.length;
        if (dataBufferIndex == dataBuffer.length) {
          postData(dataBuffer);
          dataBufferIndex = 0;
          dataBuffer = null;
        }
      }
    }
  }

  @Override public void reset() {
    dataBufferIndex = 0;
    dataBuffer = null;
  }

  @Override protected boolean isRememberData(BaseData baseData) {
    return (baseData instanceof SystemInfoBasicData);
  }
}
