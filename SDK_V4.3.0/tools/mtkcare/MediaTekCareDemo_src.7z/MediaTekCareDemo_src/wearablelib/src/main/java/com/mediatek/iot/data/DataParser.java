package com.mediatek.iot.data;

import com.mediatek.utils.RxBus;
import java.io.IOException;
import timber.log.Timber;

public abstract class DataParser {



  protected void postData(byte[] data) {

    try {
      BaseData baseData = parseData(data);
      if (isRememberData(baseData)) {
        RxBus.getInstance().postAndRemember(baseData);
      }else {
        RxBus.getInstance().post(baseData);
      }

    } catch (IOException e) {
      Timber.e(e, "wearableLib %s", e.getMessage());
    }
  }
  protected abstract BaseData parseData(byte[] data) throws IOException;

  public  void  receiveData(byte[] buffer) throws IOException{
    postData(buffer);
  }
  public void reset(){

  }

  protected boolean isRememberData(BaseData baseData){
    return false;
  }

}
