package com.mediatek.iot.ble;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import com.mediatek.iot.BluetoothDeviceInfo;
import com.mediatek.iot.Scanner;
import com.mediatek.iot.WearableLog;
import com.mediatek.iot.utils.DataConverter;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action0;
import rx.functions.Action1;
import rx.subjects.PublishSubject;
import rx.subscriptions.CompositeSubscription;

public class BLEDeviceScanner implements Scanner {
  public static final int DEFAULT_SCAN_PERIOD = 60000;
  public static final int DEFAULT_MIN_SCAN_PERIOD = 5000;

  public PublishSubject<BluetoothDeviceInfo> mDeviceSubject;
  private CompositeSubscription mSubscriptions = new CompositeSubscription();

  private final UUID[] uuids;
  private int mScanPeriod = DEFAULT_SCAN_PERIOD;
  private int mFoundDeviceCount = 0;
  private long mStartScanTimestamp;
  private int mMinScanPeriod = DEFAULT_MIN_SCAN_PERIOD;
  private boolean mScanning = false;

  private final BluetoothAdapter mBluetoothAdapter;
  private BluetoothAdapter.LeScanCallback mLeScanCallback = new BluetoothAdapter.LeScanCallback() {
    @Override public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
      ++mFoundDeviceCount;
      BluetoothDeviceInfo info = new BluetoothDeviceInfo(
          device.getName(), device.getAddress(), rssi, parseBleAdvertisement(scanRecord));
      mDeviceSubject.onNext(info);
      WearableLog.i("found_device: %s -- %s -- %d -- %s -- %s", device.getName(),
          device.getAddress(), rssi, info.getExtras(BluetoothDeviceInfo.EXTRA_UUIDS),
          info.getExtras(BluetoothDeviceInfo.EXTRA_DEVICE_ID));
      if (isScanTimeOut(mMinScanPeriod)) {
        stopScan();
      }
    }
  };

  public BLEDeviceScanner(Context applicationContext) {
    this(applicationContext, DEFAULT_SCAN_PERIOD, DEFAULT_MIN_SCAN_PERIOD);
  }

  public BLEDeviceScanner(Context applicationContext, int scanPeriod, int minPeriod) {
    this(applicationContext, scanPeriod,minPeriod, null);
  }

  public BLEDeviceScanner(Context applicationContext, int scanPeriod, int minPeriod, UUID[] uuids) {
    this.mScanPeriod = scanPeriod;
    this.uuids = uuids;
    this.mMinScanPeriod = minPeriod;
    final BluetoothManager bluetoothManager =
        (BluetoothManager) applicationContext.getSystemService(Context.BLUETOOTH_SERVICE);
    mBluetoothAdapter = bluetoothManager.getAdapter();
  }

  @Override public synchronized Observable<BluetoothDeviceInfo> startScan() {
    if(mScanning){
      stopScan();
    }
    WearableLog.i("startScan");
    mScanning = true;
    mStartScanTimestamp = System.currentTimeMillis();
    mFoundDeviceCount = 0;
    mDeviceSubject = PublishSubject.create();
    mBluetoothAdapter.startLeScan(mLeScanCallback);
    mSubscriptions.add(Observable.interval(mMinScanPeriod, TimeUnit.MILLISECONDS)
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new Action1<Long>() {
          @Override public void call(Long aLong) {
            WearableLog.i("ble_scan_check_timeout");
            WearableLog.d(BtLogger.getLog());
            if(mFoundDeviceCount > 0 || isScanTimeOut(DEFAULT_SCAN_PERIOD)) {
              stopScan();
            }
          }
        }));

    return mDeviceSubject.asObservable().doOnUnsubscribe(new Action0() {
      @Override public void call() {
        stopScan();
      }
    });
  }

  @Override public synchronized void stopScan() {
    if(mScanning) {
      mSubscriptions.clear();
      if (mDeviceSubject != null) {
        mDeviceSubject.onCompleted();
      }
      mBluetoothAdapter.stopLeScan(mLeScanCallback);
      WearableLog.i("stopScan");
      mScanning = false;
    }

  }

  private boolean isScanTimeOut(int periodInMillis) {
    return System.currentTimeMillis() - mStartScanTimestamp >= periodInMillis;
  }

  private HashMap parseBleAdvertisement(byte[] advertisedData) {
    HashMap<String, Object> hashMap = new HashMap<>();
    ArrayList<UUID> uuids = new ArrayList<>();
    hashMap.put(BluetoothDeviceInfo.EXTRA_UUIDS, uuids);
    ByteBuffer buffer = ByteBuffer.wrap(advertisedData).order(ByteOrder.LITTLE_ENDIAN);

    while (buffer.remaining() > 2) {
      byte length = buffer.get();
      if (length == 0) break;

      byte type = buffer.get();
      length -= 1;
      switch (type) {
        case 0x01: // Flags
          hashMap.put(BluetoothDeviceInfo.EXTRA_FLAGS, buffer.get());
          length--;
          break;
        case 0x02: // Partial list of 16-bit UUIDs
        case 0x03: // Complete list of 16-bit UUIDs
        case 0x14: // List of 16-bit Service Solicitation UUIDs
          while (length >= 2) {
            uuids.add(UUID.fromString(
                String.format("%08x-0000-1000-8000-00805f9b34fb", buffer.getShort())));
            length -= 2;
          }
          break;
        case 0x04: // Partial list of 32 bit service UUIDs
        case 0x05: // Complete list of 32 bit service UUIDs
          while (length >= 4) {
            uuids.add(UUID.fromString(
                String.format("%08x-0000-1000-8000-00805f9b34fb", buffer.getInt())));
            length -= 4;
          }
          break;
        case 0x06: // Partial list of 128-bit UUIDs
        case 0x07: // Complete list of 128-bit UUIDs
        case 0x15: // List of 128-bit Service Solicitation UUIDs
          while (length >= 16) {
            long lsb = buffer.getLong();
            long msb = buffer.getLong();
            uuids.add(new UUID(msb, lsb));
            length -= 16;
          }
          break;
        case 0x08: // Short local device name
        case 0x09: // Complete local device name
        {
          byte sb[] = new byte[length];
          buffer.get(sb, 0, length);
          length = 0;
          hashMap.put(BluetoothDeviceInfo.EXTRA_DEVICE_NAME, new String(sb).trim());
          break;
        }
        case 0x10: {
          byte sb[] = new byte[length];
          buffer.get(sb, 0, length);
          length = 0;
          hashMap.put(BluetoothDeviceInfo.EXTRA_DEVICE_ID, DataConverter.bytesToHex(sb, '\0'));
          break;
        }
        case (byte) 0xFF: // Manufacturer Specific Data
          hashMap.put(BluetoothDeviceInfo.EXTRA_SPECIFIC_DATA, buffer.getShort());
          length -= 2;
          break;
        default: // skip
          break;
      }
      if (length > 0) {
        buffer.position(buffer.position() + length);
      }
    }
    return hashMap;
  }
}
