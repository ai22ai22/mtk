package com.mediatek.iot;

import rx.Observable;


public interface Scanner {
  Observable<BluetoothDeviceInfo> startScan();
  void stopScan();
}
