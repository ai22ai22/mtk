package com.mediatek.iot.ble;

import android.util.Log;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BtLogger {
  private static final String TAG = BtLogger.class.getCanonicalName();
  private static final String processId = Integer.toString(android.os.Process
      .myPid());

  public static String getLog() {

    StringBuilder builder = new StringBuilder();

    try {
      String[] command = new String[] { "logcat", "-d", "-v", "time",
          "BluetoothLeScanner:D BluetoothGatt:D BluetoothDevice:D BluetoothAdapter:D", "*:S" };

      Process process = Runtime.getRuntime().exec(command);

      BufferedReader bufferedReader = new BufferedReader(
          new InputStreamReader(process.getInputStream()));

      String line;
      while ((line = bufferedReader.readLine()) != null) {
        if (line.contains(processId)) {
          builder.append(line).append("\n");
        }
      }

      Runtime.getRuntime().exec(new String[] { "logcat", "-c"});
    } catch (IOException ex) {
      Log.e(TAG, "getLog failed", ex);
    }

    String log = builder.toString();
    builder.setLength(0);

    return log;
  }
}
