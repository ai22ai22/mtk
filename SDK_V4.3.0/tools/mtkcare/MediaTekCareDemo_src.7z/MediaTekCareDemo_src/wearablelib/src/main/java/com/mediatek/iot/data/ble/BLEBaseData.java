package com.mediatek.iot.data.ble;

import com.mediatek.iot.data.BaseData;
import com.mediatek.iot.utils.DataConverter;
import java.io.IOException;

public abstract class BLEBaseData extends BaseData{

  protected int timestamp;
  protected int algId;
  protected int featureId;

  protected BLEBaseData(byte[] bytes) throws IOException {
    super();
    algId = bytes[0] & 0xFF;
    featureId = bytes[6] & 0xFF;
    byte[] buffer = new byte[4];
    System.arraycopy(bytes, 2, buffer, 0, 4);
    timestamp = DataConverter.bytesToInt(buffer);

    buffer = new byte[bytes.length - 7];
    System.arraycopy(bytes, 7, buffer, 0, buffer.length);
    parseValue(buffer);
  }

  public int getAlgId() {
    return algId;
  }

  public int getFeatureId() {
    return featureId;
  }

  public int getTimestamp() {
    return timestamp;
  }

  protected abstract void parseValue(byte[] bytes) throws IOException;

  @Override public String toString() {
    return String.format("%s-%2x-%2x-%s:\t %s", getClass().getSimpleName(), getAlgId(),
        getFeatureId(), DataConverter.formatTimestamp(getTimestamp()), toStringBody());
  }
  protected abstract String toStringBody();
}
