package com.mediatek.iot;

import java.util.HashMap;

public class BluetoothDeviceInfo implements Comparable<BluetoothDeviceInfo> {
  public static final String EXTRA_DEVICE_ID = "DeviceId";
  public static final String EXTRA_DEVICE_NAME = "DeviceName";
  public static final String EXTRA_FLAGS = "Flags";
  public static final String EXTRA_UUIDS = "UUIDs";
  public static final String EXTRA_SPECIFIC_DATA = "SpecificData";

  private final String macAddress;
  private final String name;
  private final int rssi;
  private final HashMap extrasData;

  public BluetoothDeviceInfo(String name, String macAddress, int rssi) {
    this(name, macAddress, rssi, null);
  }

  public BluetoothDeviceInfo(String name, String macAddress, int rssi, HashMap extrasData) {
    this.name = name;
    this.macAddress = macAddress;
    this.rssi = rssi;
    this.extrasData = extrasData;
  }

  public String getMacAddress() {
    return macAddress;
  }

  public String getName() {
    return name;
  }

  public Object getExtras(String name) {
    return extrasData.get(name);
  }

  /**
   * Device rssi in ascending order
   * @param anotherDevice instanceof {@link BluetoothDeviceInfo}
   * @return integer > 0 if this.rssi is bigger than anotherDevice.rssi
   */
  @Override public int compareTo(BluetoothDeviceInfo anotherDevice) {
    return rssi - anotherDevice.rssi;
  }

  @Override public String toString() {
    return String.format("%s - %s", getName(), getMacAddress());
  }

  public int getRssi() {
    return rssi;
  }
}
