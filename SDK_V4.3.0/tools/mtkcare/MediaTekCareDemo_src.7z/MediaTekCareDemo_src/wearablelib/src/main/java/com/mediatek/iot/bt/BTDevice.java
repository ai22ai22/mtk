package com.mediatek.iot.bt;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import com.mediatek.iot.Device;
import com.mediatek.iot.command.BaseCommand;
import com.mediatek.iot.data.DataParser;
import com.mediatek.utils.RxBus;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import rx.Observable;
import rx.Subscriber;
import timber.log.Timber;

public class BTDevice extends Device {
  private final BluetoothAdapter mAdapter;
  private UUID uuid =
      // UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");
      UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); // 1st SPP for default
  private ConnectThread mConnectThread;
  private ConnectedThread mConnectedThread;

  public BTDevice(Context applicationContext, DataParser dataParser) {
    super(applicationContext, dataParser);
    mAdapter = BluetoothAdapter.getDefaultAdapter();
  }

  @Override public synchronized void connect(String address) {
    super.connect(address);
    if (getState() == STATE_CONNECTED) {
      return;
    }
    // Cancel any thread attempting to make a connection
    if (getState() == STATE_CONNECTING) {
      if (mConnectThread != null) {
        mConnectThread.cancel();
        mConnectThread = null;
      }
    }

    // Cancel any thread currently running a connection
    if (mConnectedThread != null) {
      mConnectedThread.cancel();
      mConnectedThread = null;
    }

    // Start the thread to connect with the given device
    mConnectThread = new ConnectThread(mAdapter.getRemoteDevice(address));
    mConnectThread.start();
    setState(STATE_CONNECTING);
    return;
  }

  @Override public void disconnect() {
    Timber.d("stop");
    if (mConnectThread != null) {
      mConnectThread.cancel();
      mConnectThread = null;
    }

    if (mConnectedThread != null) {
      mConnectedThread.cancel();
      mConnectedThread = null;
    }
    setState(STATE_DISCONNECTED);
  }

  @Override public Observable<Boolean> writeToDevice(final BaseCommand baseCommand){
    return Observable.create(new Observable.OnSubscribe<Boolean>() {
      @Override public void call(Subscriber<? super Boolean> subscriber) {
        // Create temporary object
        ConnectedThread r;
        // Synchronize a copy of the ConnectedThread
        synchronized (this) {
          if (getState() != STATE_CONNECTED) {
            subscriber.onError(new IOException("lost connection"));
          }
          r = mConnectedThread;
        }
        // Perform the write unsynchronized
        try {
          r.write(baseCommand.toBytes());
          subscriber.onCompleted();
        } catch (IOException e) {
          e.printStackTrace();
          subscriber.onError(e);
        }

      }
    });


  }

  private synchronized void connectionFailed() {
    setState(STATE_DISCONNECTED);
  }

  private synchronized void connected(BluetoothSocket socket, BluetoothDevice device) {
    Timber.d("connected");
    // Cancel the thread that completed the connection
    if (mConnectThread != null) {
      mConnectThread.cancel();
      mConnectThread = null;
    }

    // Cancel any thread currently running a connection
    if (mConnectedThread != null) {
      mConnectedThread.cancel();
      mConnectedThread = null;
    }

    // Start the thread to manage the connection and perform transmissions
    mConnectedThread = new ConnectedThread(socket);
    mConnectedThread.start();

    // Send the name of the connected device back to the UI Activity
    setState(STATE_CONNECTED);
  }

  private void connectionLost() {
    setState(STATE_DISCONNECTED);
  }

  private class ConnectThread extends Thread {
    private final BluetoothSocket mmSocket;
    private final BluetoothDevice mmDevice;
    private boolean mCancelled = false;

    public ConnectThread(BluetoothDevice device) {
      mmDevice = device;
      BluetoothSocket tmp = null;

      // Get a BluetoothSocket for a connection with the
      // given BluetoothDevice
      try {
        tmp = device.createInsecureRfcommSocketToServiceRecord(uuid);
      } catch (IOException e) {
        e.printStackTrace();
        Timber.e(e, "create() failed");
      }
      mmSocket = tmp;
    }

    public void run() {
      Timber.i("BEGIN mConnectThread:");
      setName("ConnectThread");

      // Always cancel discovery because it will slow down a connection
      mAdapter.cancelDiscovery();

      // Make a connection to the BluetoothSocket
      try {
        // This is a blocking call and will only return on a
        // successful connection or an exception
        mmSocket.connect();
        synchronized (this) {
          if (mCancelled) {
            mmSocket.close();
          }
        }
      } catch (IOException e) {
        // Close the socket
        e.printStackTrace();
        Timber.w(e, e.getMessage());
        RxBus.getInstance().post(e);
        try {
          mmSocket.close();
        } catch (IOException e2) {
          e2.printStackTrace();
          Timber.w(e2, e2.getMessage());
          Timber.e(e2, "unable to close() socket during connection failure");
        }
        connectionFailed();
        return;
      }

      // Reset the ConnectThread because we're done
      synchronized (BTDevice.this) {
        mConnectThread = null;
      }

      // Start the connected thread
      connected(mmSocket, mmDevice);
    }

    public synchronized void cancel() {
      try {
        mCancelled = true;
        mmSocket.close();
      } catch (IOException e) {
        Timber.e(e, "close() of connect  socket failed");
      }
    }
  }

  private class ConnectedThread extends Thread {
    private final BluetoothSocket mmSocket;
    private final InputStream mmInStream;
    private final OutputStream mmOutStream;

    public ConnectedThread(BluetoothSocket socket) {
      Timber.d("create ConnectedThread: ");
      mmSocket = socket;
      InputStream tmpIn = null;
      OutputStream tmpOut = null;

      // Get the BluetoothSocket input and output streams
      try {
        tmpIn = socket.getInputStream();
        tmpOut = socket.getOutputStream();
      } catch (IOException e) {
        Timber.e(e, "temp sockets not created");
      }

      mmInStream = tmpIn;
      mmOutStream = tmpOut;
    }

    public void run() {
      Timber.i("BEGIN mConnectedThread");
      byte[] buffer = new byte[64];
      int bytes;

      // Keep listening to the InputStream while connected
      while (!isInterrupted()) {
        try {
          // Read from the InputStream
          bytes = mmInStream.read(buffer);
          byte[] data = new byte[bytes];
          System.arraycopy(buffer, 0, data, 0, bytes);
          dataAvailable(data);
        } catch (IOException e) {
          Timber.e(e, "disconnected");
          connectionLost();
          break;
        }
      }
    }

    /**
     * Write to the connected OutStream.
     *
     * @param buffer The bytes to write
     */
    public void write(byte[] buffer) throws IOException {
        mmOutStream.write(buffer);
    }

    public void cancel() {
      try {
        interrupt();
        mmSocket.close();
      } catch (IOException e) {
        Timber.e(e, "close() of connect socket failed");
      }
    }
  }
}
