package com.mediatek.iot.data.ble;

import com.mediatek.iot.utils.DataConverter;
import java.io.ByteArrayInputStream;
import java.io.IOException;

public class PedometerRealTimeData extends BLEBaseData {
  private int endTime;
  private int totalStepCount;
  private int runStepCount;
  private int totalWalkDuration;
  private int totalRunDuration;
  private int burnedCalories;
  private int walkStepCount;

  public PedometerRealTimeData(byte[] bytes) throws IOException {
    super(bytes);
  }

  public int getEndTime() {
    return endTime;
  }

  public int getRunStepCount() {
    return runStepCount;
  }

  public int getTotalRunDuration() {
    return totalRunDuration;
  }

  public int getTotalStepCount() {
    return totalStepCount;
  }

  public int getTotalWalkDuration() {
    return totalWalkDuration;
  }

  public int getBurnedCalories() {
    return burnedCalories;
  }

  public int getWalkStepCount() {
    return walkStepCount;
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
    byte[] buffer2 = new byte[2];
    byte[] buffer4 = new byte[4];
    byteArrayInputStream.read(buffer2);
    endTime = DataConverter.bytesToInt(buffer2);

    byteArrayInputStream.read(buffer4);
    totalStepCount = DataConverter.bytesToInt(buffer4);

    byteArrayInputStream.read(buffer4);
    runStepCount = DataConverter.bytesToInt(buffer4);
    if (runStepCount < 0) {
      runStepCount = 0;
    }

    byteArrayInputStream.read(buffer2);
    totalWalkDuration =  DataConverter.bytesToInt(buffer2);

    byteArrayInputStream.read(buffer2);
    totalRunDuration = DataConverter.bytesToInt(buffer2);

    byteArrayInputStream.read(buffer4);
    burnedCalories = DataConverter.bytesToInt(buffer4);

    walkStepCount = totalStepCount - runStepCount;
  }

  @Override protected String toStringBody() {
    return String.format(
        "endTime:%d, totalStepCount:%d, runStepCount:%d, totalWalkDuration:%d, totalRunDuration:%d burnedCalories:%d",
        endTime, totalStepCount, runStepCount, totalWalkDuration, totalRunDuration, burnedCalories);
  }

  public void amendRunStepCount(int runStepCount){
    amend(runStepCount, walkStepCount);
  }
  public void amendRunWalkCount(int walkStepCount){
    amend(runStepCount, walkStepCount);
  }

  public void amend(int runStepCount, int walkStepCount){
    this.runStepCount = runStepCount;
    this.walkStepCount = walkStepCount;
    this.totalStepCount = runStepCount + walkStepCount;
  }



}
