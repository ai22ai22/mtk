package com.mediatek.iot.command;

import com.mediatek.iot.data.BaseData;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public abstract class BaseCommand {
  private Exception error = null;

  public abstract InputStream getInputStream() throws IOException;

  public abstract boolean isResponseData(BaseData baseData);

  public abstract boolean isOKResponse(BaseData returnData);

  public byte[] toBytes() {
    try {
      InputStream inputStream = getInputStream();
      ByteArrayOutputStream buffer = new ByteArrayOutputStream();
      int nRead;
      byte[] data = new byte[256];
      while ((nRead = inputStream.read(data, 0, data.length)) != -1) {
        buffer.write(data, 0, nRead);
      }
      buffer.flush();
      return buffer.toByteArray();
    } catch (IOException e) {
      e.printStackTrace();
      return e.getMessage().getBytes();
    }
  }

  public synchronized void setError(Exception error) {
    this.error = error;
  }

  public Exception getError() {
    return error;
  }
}
