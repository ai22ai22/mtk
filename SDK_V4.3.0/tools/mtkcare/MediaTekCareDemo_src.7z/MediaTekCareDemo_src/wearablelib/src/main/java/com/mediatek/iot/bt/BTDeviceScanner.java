package com.mediatek.iot.bt;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import com.mediatek.iot.BluetoothDeviceInfo;
import com.mediatek.iot.Scanner;
import com.mediatek.iot.WearableLog;

import java.util.Set;
import java.util.concurrent.TimeUnit;
import rx.Observable;
import rx.Subscriber;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.subjects.PublishSubject;
import timber.log.Timber;

public class BTDeviceScanner implements Scanner {
  private final BluetoothAdapter mBtAdapter;
  private Context mContext;
  private PublishSubject<BluetoothDeviceInfo> mDeviceSubject;

  private BroadcastReceiver mReceiver = new BroadcastReceiver() {
    @Override public void onReceive(Context context, Intent intent) {
      String action = intent.getAction();
      // When discovery finds a device
      if (BluetoothDevice.ACTION_FOUND.equals(action)) {
        // Get the BluetoothDevice object from the Intent
        BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
        // If it's already paired, skip it, because it's been listed already
        if (device.getBondState() != BluetoothDevice.BOND_BONDED || true) {
          short rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI,Short.MIN_VALUE);
          Timber.d("found_device:%s", device.getAddress());
          mDeviceSubject.onNext(new BluetoothDeviceInfo(device.getName(), device.getAddress(), rssi));
        }
        // When discovery is finished, change the Activity title
      } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
        mDeviceSubject.onCompleted();
      }
    }
  };

  public BTDeviceScanner(Context applicationContext) {
    this.mContext = applicationContext;
    mBtAdapter = BluetoothAdapter.getDefaultAdapter();

  }

  @Override public synchronized Observable<BluetoothDeviceInfo> startScan() {
    stopScan();
    mDeviceSubject = PublishSubject.create();
    return Observable.create(new Observable.OnSubscribe<BluetoothDeviceInfo>() {
      @Override public void call(final Subscriber<? super BluetoothDeviceInfo> subscriber) {
        mDeviceSubject.asObservable().subscribe(subscriber);

        Set<BluetoothDevice> pairedDevices = mBtAdapter.getBondedDevices();
        Observable.from(pairedDevices).map(new Func1<BluetoothDevice, BluetoothDeviceInfo>() {
          @Override public BluetoothDeviceInfo call(BluetoothDevice bluetoothDevice) {
            return new BluetoothDeviceInfo(bluetoothDevice.getName(), bluetoothDevice.getAddress(), 0);
          }
        }).subscribe(new Action1<BluetoothDeviceInfo>() {
          @Override public void call(BluetoothDeviceInfo bluetoothDeviceInfo) {
            mDeviceSubject.onNext(bluetoothDeviceInfo);
          }
        });

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothDevice.ACTION_FOUND);
        intentFilter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        mContext.registerReceiver(mReceiver, intentFilter);
        if (!mBtAdapter.isDiscovering()) {
          mBtAdapter.startDiscovery();
        }
      }
    });
  }

  @Override public synchronized void stopScan() {
    if (mDeviceSubject != null && !mDeviceSubject.hasCompleted()) {
      mContext.unregisterReceiver(mReceiver);
      mDeviceSubject.onCompleted();
    }
    if (mBtAdapter.isDiscovering()) {
      mBtAdapter.cancelDiscovery();
    }
  }
}
