package com.mediatek.iot.data.ble;

import java.io.IOException;

public class SystemInfoHistoryStatusData extends BLEBaseData {
  private int historyAlgoId;
  private int historyFeatureId;
  private boolean hasHistory;

  public SystemInfoHistoryStatusData(byte[] bytes) throws IOException {
    super(bytes);
  }

  public int getHistoryAlgoId() {
    return historyAlgoId;
  }

  public int getHistoryFeatureId() {
    return historyFeatureId;
  }

  public boolean hasHistory() {
    return hasHistory;
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    historyAlgoId = bytes[0] & 0xFF;
    historyFeatureId = bytes[1] & 0xFF;
    hasHistory = 1 == (bytes[2] & 0xFF);
  }

  @Override protected String toStringBody() {
    return String.format("historyAlgoId: (%x)hex, historyFeatureId: (%x)hex, hasHistory:%b",
        historyAlgoId, historyFeatureId, hasHistory);
  }
}
