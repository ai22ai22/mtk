package com.mediatek.iot.events;

import com.mediatek.iot.Device;

public class StateChangeEvent {
  private final int state;
  private final Device device;

  public StateChangeEvent(Device device, int state) {
    this.state = state;
    this.device = device;
  }

  public Device getDevice() {
    return device;
  }

  public int getState() {
    return state;
  }
}
