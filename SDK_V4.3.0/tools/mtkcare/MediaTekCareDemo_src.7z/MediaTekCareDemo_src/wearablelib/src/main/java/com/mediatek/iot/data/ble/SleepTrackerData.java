package com.mediatek.iot.data.ble;

import com.mediatek.iot.utils.DataConverter;
import java.io.IOException;
import java.util.Arrays;

public class SleepTrackerData extends BLEBaseData {
  private SleepValue[] sleepValues;

  protected SleepTrackerData(byte[] bytes) throws IOException {
    super(bytes);
  }

  public SleepValue[] getSleepValues() {
    return sleepValues;
  }

  @Override protected String toStringBody() {
    return String.format("%s", Arrays.toString(sleepValues));
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    if (bytes.length % 8 != 0) {
      throw new IOException(String.format("%s data format invalid", getClass().getSimpleName()));
    }
    sleepValues = new SleepValue[bytes.length / 8];
    for (int i = 0; i < sleepValues.length; ++i) {
      byte[] buffer = new byte[8];
      System.arraycopy(bytes, i * 8, buffer, 0, 8);
      sleepValues[i] = new SleepValue(buffer);
    }
  }

  public static class SleepValue {
    public final int value;
    public final int timestamp;

    protected SleepValue(byte[] bytes) {
      byte[][] data = DataConverter.splitBytes(bytes, 0, 4);
      this.timestamp = DataConverter.bytesToInt(data[0]);
      this.value = DataConverter.bytesToInt(data[1]);
    }

    @Override public String toString() {
      return String.format("%d/%d", timestamp, value);
    }
  }
}
