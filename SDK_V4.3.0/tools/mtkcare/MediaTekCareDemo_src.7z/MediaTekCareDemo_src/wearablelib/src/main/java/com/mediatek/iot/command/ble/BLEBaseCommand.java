package com.mediatek.iot.command.ble;

import com.mediatek.iot.command.BaseCommand;
import com.mediatek.iot.data.BaseData;
import com.mediatek.iot.data.ble.ReturnData;
import com.mediatek.iot.utils.DataConverter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.SequenceInputStream;

public abstract class BLEBaseCommand extends BaseCommand {
  private int commandId;
  private int timestamp;

  protected BLEBaseCommand(int commandId) {
    this(commandId, (int) (System.currentTimeMillis() / 1000));
  }

  protected BLEBaseCommand(int commandId, int timestamp) {
    this.commandId = commandId;
    this.timestamp = timestamp;
  }

  public int getCommandId() {
    return commandId;
  }

  public int getTimestamp() {
    return timestamp;
  }

  protected abstract byte[] getValueBytes();

  protected InputStream getDataInputStream() {
    return new ByteArrayInputStream(getValueBytes());
  }

  protected int getHeaderLen(){
    return 1 + 1 + 4;
  }
  protected byte[] getCommandLen(int dataLen){
    return new byte[]{ (byte) (dataLen + getHeaderLen()) };
  }


  protected void writeHeader(OutputStream headerOutput, int dataLen) throws IOException {
    headerOutput.write(commandId);
    headerOutput.write(getCommandLen(dataLen));
    headerOutput.write(DataConverter.intToBytes(timestamp));
  }

  @Override public InputStream getInputStream() throws IOException {
    InputStream dataInputStream = getDataInputStream();
    ByteArrayOutputStream headerOutput = new ByteArrayOutputStream();
    writeHeader(headerOutput, dataInputStream.available());
    return new SequenceInputStream(new ByteArrayInputStream(headerOutput.toByteArray()),
        dataInputStream);
  }

  @Override public String toString() {
    try {
      InputStream inputStream = getInputStream();
      return String.format("%s-%2x: %s", getClass().getSimpleName(), getCommandId(),
          DataConverter.inputStreamToHex(inputStream));
    } catch (IOException e) {
      e.printStackTrace();
      return String.format("%s-%2x: %s", getClass().getSimpleName(), getCommandId(),
          e.getMessage());
    }
  }

  @Override public boolean isResponseData(BaseData baseData) {
    if (baseData instanceof ReturnData) {
      ReturnData returnData = (ReturnData) baseData;
      return returnData.getCommandId() == commandId;
    }
    return false;
  }

  @Override public boolean isOKResponse(BaseData baseData) {
    if (!isResponseData(baseData)) {
      return false;
    }
    ReturnData returnData = (ReturnData) baseData;
    return returnData.getResponseCode() == 0;
  }
}
