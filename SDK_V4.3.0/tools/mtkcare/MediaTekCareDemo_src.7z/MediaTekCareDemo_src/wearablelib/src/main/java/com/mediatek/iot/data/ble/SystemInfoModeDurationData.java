package com.mediatek.iot.data.ble;

import com.mediatek.iot.utils.DataConverter;
import java.io.IOException;
import java.util.Arrays;

public class SystemInfoModeDurationData extends BLEBaseData {
  private ModeDuration[] modeDurations;

  protected SystemInfoModeDurationData(byte[] bytes) throws IOException {
    super(bytes);
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    if (bytes.length % 9 != 0) {
      throw new IOException(String.format("%s data format invalid", getClass().getSimpleName()));
    }
    modeDurations = new ModeDuration[bytes.length / 9];
    for (int i = 0; i < modeDurations.length; ++i) {
      byte[] buffer = new byte[9];
      System.arraycopy(bytes, i * 9, buffer, 0, 9);
      modeDurations[i] = new ModeDuration(buffer);
    }
  }

  @Override protected String toStringBody() {
    return String.format("modeDurations:%s", Arrays.toString(modeDurations));
  }

  public static class ModeDuration {
    public static final int MODE_EXERCISE = 0x01;
    public static final int MODE_SLEEP = 0x02;
    public static final int MODE_ENGINNERING = 0xFE;

    private int mode;
    private int startTimestamp;
    private int endTimestamp;

    public ModeDuration(byte[] data) {
      int i = 0;
      mode = data[i++];
      startTimestamp =
          DataConverter.bytesToInt(new byte[] { data[i++], data[i++], data[i++], data[i++] });
      endTimestamp =
          DataConverter.bytesToInt(new byte[] { data[i++], data[i++], data[i++], data[i++] });
    }

    public int getMode() {
      return mode;
    }

    public int getStartTimestamp() {
      return startTimestamp;
    }

    public int getEndTimestamp() {
      return endTimestamp;
    }

    @Override public String toString() {
      return String.format("mode:%d,start:%d,end:%d", mode, startTimestamp, endTimestamp);
    }
  }
}
