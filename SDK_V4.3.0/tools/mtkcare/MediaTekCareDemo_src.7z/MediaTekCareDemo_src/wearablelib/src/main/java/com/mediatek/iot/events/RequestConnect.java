package com.mediatek.iot.events;

public class RequestConnect {
  private final String macAddress;

  public RequestConnect(String macAddress) {
    this.macAddress = macAddress;
  }

  public String getMacAddress() {
    return macAddress;
  }
}
