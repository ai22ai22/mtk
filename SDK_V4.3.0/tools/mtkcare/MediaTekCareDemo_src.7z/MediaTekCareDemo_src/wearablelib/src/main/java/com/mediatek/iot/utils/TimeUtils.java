package com.mediatek.iot.utils;

import java.util.TimeZone;

public class TimeUtils {
  public static short getOffsetInMinutes(int timestamp){
    TimeZone tz = TimeZone.getDefault();
    return (short) (tz.getOffset(timestamp  * 1000L) / 1000 / 60);
  }

}
