package com.mediatek.iot.data.ble;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class HeartRateData extends BLEBaseData {
  private int[] heartRateValues;

  protected HeartRateData(byte[] bytes) throws IOException {
    super(bytes);
  }

  public int[] getHeartRateValues() {
    return heartRateValues;
  }

  @Override protected void parseValue(byte[] bytes) {
    ArrayList<Integer> tempList = new ArrayList<>();
    for (byte b : bytes) {
      int hr = b & 0xFF;
      if (hr != 0xFF) {
        tempList.add(hr);
      }
    }

    heartRateValues = new int[Math.max(tempList.size(),0)];
    for (int i = 0; i < tempList.size(); ++i) {
      heartRateValues[i] = tempList.get(i);
    }
  }

  @Override protected String toStringBody() {
    return String.format("HR:%s", Arrays.toString(heartRateValues));
  }
}
