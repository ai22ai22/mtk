package com.mediatek.iot.data.ble;

import com.mediatek.iot.utils.DataConverter;
import java.io.ByteArrayInputStream;
import java.io.IOException;

public class SystemInfoGoalData extends BLEBaseData {

  private int stepCount;
  private int heartRateGoal;
  private int continueTime;
  private int duration;
  private int calorie;

  public int getCalorie() {
    return calorie;
  }

  public void setCalorie(int calorie) {
    this.calorie = calorie;
  }

  public int getDuration() {
    return duration;
  }

  public void setDuration(int duration) {
    this.duration = duration;
  }

  public int getHeartRateGoal() {
    return heartRateGoal;
  }

  public void setHeartRateGoal(int heartRateGoal) {
    this.heartRateGoal = heartRateGoal;
  }

  public int getStepCount() {
    return stepCount;
  }

  public void setStepCount(int stepCount) {
    this.stepCount = stepCount;
  }

  public int getContinueTime() {
    return continueTime;
  }

  public SystemInfoGoalData(byte[] bytes) throws IOException {
    super(bytes);
  }

  @Override protected void parseValue(byte[] bytes) throws IOException {
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
    stepCount = DataConverter.bytesToInt(new byte[] {
        (byte) byteArrayInputStream.read(), (byte) byteArrayInputStream.read()
    });
    heartRateGoal = byteArrayInputStream.read();
    continueTime = byteArrayInputStream.read();
    duration = byteArrayInputStream.read();
    byte[] intBytes = new byte[4];
    byteArrayInputStream.read(intBytes);
    calorie = DataConverter.bytesToInt(intBytes);
  }

  @Override public String toStringBody() {
    return String.format(" stepCount:%d, heartRateGoal:%d,continueTime:%d, duration:%d, calorie:%d", stepCount,
        heartRateGoal,continueTime, duration, calorie);
  }
}
