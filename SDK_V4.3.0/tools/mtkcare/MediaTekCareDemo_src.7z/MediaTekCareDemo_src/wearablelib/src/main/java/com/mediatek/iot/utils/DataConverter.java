package com.mediatek.iot.utils;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class DataConverter {
  final protected static char[] hexArray = "0123456789ABCDEF".toCharArray();
  private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

  public static byte[] hexStringToByteArray(String s) {
    int len = s.length();
    byte[] data = new byte[len / 2];
    for (int i = 0; i < len; i += 2) {
      data[i / 2] =
          (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i + 1), 16));
    }
    return data;
  }

  public static int bytesToInt(byte[] bytes) {
    int result = 0;
    for (int i = bytes.length - 1; i >= 0; --i) {
      result = (result << 8) | (bytes[i] & 0xFF);
    }
    return result;
  }

  public static short bytesToShort(byte[] bytes) {
    short result = 0;
    for (int i = bytes.length - 1; i >= 0; --i) {
      result = (short) ((result << 8) | (bytes[i] & 0xFF));
    }
    return result;
  }

  public static String bytesToHex(byte[] bytes) {
    return bytesToHex(bytes, 0, bytes.length, '\0');
  }

  public static String bytesToHex(byte[] bytes, char split) {
    return bytesToHex(bytes, 0, bytes.length, split);
  }

  public static String bytesToHex(byte[] bytes, int offset, int len, char split) {
    int step = 2;
    int strlen = len * step;
    if (split > 0) {
      step = 3;
      strlen = len * step - 1;
    }

    char[] hexChars = new char[strlen];
    for (int i = offset; i < strlen; i += step) {
      int v = bytes[i / step] & 0xFF;
      hexChars[i] = hexArray[v >>> 4];
      hexChars[i + 1] = hexArray[v & 0x0F];
      if (split > 0 && i + 2 < strlen) {
        hexChars[i + 2] = split;
      }
    }
    return new String(hexChars);
  }

  public static String inputStreamToHex(InputStream inputStream) {
    final int MAX_STRING_LENGTH = 100;
    try {
      char[] hexChars = new char[MAX_STRING_LENGTH * 3];
      int v = -1;
      int j = 0;
      while ((v = inputStream.read()) > -1 && j < hexChars.length / 3) {
        hexChars[j * 3] = hexArray[v >>> 4];
        hexChars[j * 3 + 1] = hexArray[v & 0x0F];
        hexChars[j * 3 + 2] = ',';
        ++j;
      }
      return new String(hexChars).trim();
    } catch (IOException e) {
      e.printStackTrace();
      return e.toString();
    }
  }

  public static float ecgConvertToMv(int data_ecg) {
    float ekg_vpp = 4; // unit: bits
    float ekg_bits = 23; // unit: bits
    float ekg_adc_lsb = (float) (ekg_vpp / Math.pow(2, ekg_bits));
    float ekg_gain = 6; // 6: ekg measurement
    if (data_ecg > Math.pow(2, 22)) {
      data_ecg -= Math.pow(2, 23); //unsigned -> signed
    }
    return data_ecg * ekg_adc_lsb * 1000.0f / ekg_gain;
  }

  public static float ppg1ConvertToMv(int data_ppg1) {
    float ppg_vpp = 3.2f; // unit: volt
    float ppg_bits = 16; // unit: bits
    float ppg_adc_lsb = (float) (ppg_vpp / Math.pow(2, ppg_bits));
    float ppg_tia_gain = 1;
    float ppg_pga_gain = 1;

    if (data_ppg1 > Math.pow(2, 22)) data_ppg1 -= Math.pow(2, 23);
    return data_ppg1 * ppg_adc_lsb * 1000.0f / (ppg_tia_gain * ppg_pga_gain); // convert to mV
  }

  public static int[] convertIntegers(List<Integer> integers) {
    int[] ret = new int[integers.size()];
    for (int i = 0; i < ret.length; i++) {
      ret[i] = integers.get(i).intValue();
    }
    return ret;
  }

  public static byte[] intToBytes(int i) {
    byte[] bytes = new byte[4];
    bytes[0] = (byte) (i & 0xFF);
    bytes[1] = (byte) ((i >> 8) & 0xFF);
    bytes[2] = (byte) ((i >> 16) & 0xFF);
    bytes[3] = (byte) ((i >> 24) & 0xFF);
    return bytes;
  }

  public static byte[] shortToBytes(short s) {
    byte[] bytes = new byte[2];
    bytes[0] = (byte) (s & 0xFF);
    bytes[1] = (byte) ((s >> 8) & 0xFF);
    return bytes;
  }

  public static String intArrayToString(int[] ints, int startIndex) {
    StringBuilder stringBuilder = new StringBuilder();
    if (ints.length > startIndex) {
      stringBuilder.append(ints[startIndex]);

      for (int i = startIndex + 1; i < ints.length; ++i) {
        stringBuilder.append(",");
        stringBuilder.append(ints[i]);
      }
    }
    return stringBuilder.toString();
  }

  public static String str2HexStr(String str) {

    char[] chars = "0123456789ABCDEF".toCharArray();
    StringBuilder sb = new StringBuilder("");
    byte[] bs = str.getBytes();
    int bit;

    for (int i = 0; i < bs.length; i++) {
      bit = (bs[i] & 0x0f0) >> 4;
      sb.append(chars[bit]);
      bit = bs[i] & 0x0f;
      sb.append(chars[bit]);
      sb.append("");
    }
    return sb.toString().trim();
  }

  public static byte[][] splitBytes(byte[] data, int start, int itemCount) {
    int len = (data.length - start) / itemCount;
    byte[][] result = new byte[len][];
    for (int i = 0; i < len; ++i) {
      result[i] = new byte[itemCount];
      System.arraycopy(data, start + i * itemCount, result[i], 0, itemCount);
    }
    return result;
  }

  public static String formatTimestamp(int timestamp) {
    return simpleDateFormat.format(new Date(timestamp * 1000L));
  }
}
