package com.mediatek.iot.data;

public class OutputRawData {
  public byte[] getByte(){
    return new byte[1];
  }
}
