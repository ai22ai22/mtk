package com.mediatek.iot.command.ble;

public class SetExerciseDurationGoalCommand extends BLEBaseCommand {
  public final static int COMMAND_ID = 0xC5;
  private final int durationGoal;

  public SetExerciseDurationGoalCommand(int durationGoal) {
    super(COMMAND_ID);
    this.durationGoal = durationGoal;
  }

  @Override protected byte[] getValueBytes() {
    return new byte[]{ (byte) (durationGoal & 0xff) };
  }
}
