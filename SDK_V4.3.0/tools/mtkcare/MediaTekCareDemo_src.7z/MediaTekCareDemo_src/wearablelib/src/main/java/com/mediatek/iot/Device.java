package com.mediatek.iot;

import android.content.Context;
import com.mediatek.iot.command.BaseCommand;
import com.mediatek.iot.data.BaseData;
import com.mediatek.iot.data.DataParser;
import com.mediatek.iot.events.StateChangeEvent;
import com.mediatek.iot.exceptions.DeviceException;
import com.mediatek.utils.RxBus;
import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import rx.Observable;
import rx.Scheduler;
import rx.Subscriber;
import rx.functions.Action0;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.schedulers.Schedulers;
import rx.subjects.PublishSubject;
import rx.subscriptions.CompositeSubscription;
import rx.subscriptions.Subscriptions;

public abstract class Device {
  public static final int STATE_DISCONNECTED = 0x10;
  public static final int STATE_CONNECTING = 0x20;
  public static final int STATE_CONNECTED = 0x30;
  private static final int TIMEOUT_COMMAND = 10000;

  protected final Context mContext;
  protected final DataParser dataParser;
  private final Scheduler mWorkScheduler;
  private final Scheduler mCommandReturnScheduler;
  private final Object mCommandLock = new Object();
  private int mConnectionState = STATE_DISCONNECTED;
  private PublishSubject<Integer> mStateSubject = PublishSubject.create();
  private String address;
  private String mClsName = getClass().getSimpleName();
  protected Device(Context applicationContext, DataParser dataParser) {
    this.dataParser = dataParser;
    mContext = applicationContext;
    mWorkScheduler = Schedulers.from(Executors.newFixedThreadPool(1));
    mCommandReturnScheduler = Schedulers.from(Executors.newFixedThreadPool(1));
  }

  public String getAddress() {
    return address;
  }
  public void connect(String address){
    this.address = address;
    WearableLog.i("%s_connect to macAddress:%s", mClsName,address);
  }

  public abstract void disconnect();

  public abstract Observable writeToDevice(BaseCommand baseCommand);

  protected void reset() {
    dataParser.reset();
  }

  protected void dataAvailable(byte[] buffer) {
    try {
      dataParser.receiveData(buffer);
    } catch (IOException e) {
      WearableLog.e(e,e.getMessage());
    }
  }

  public Observable<Integer> getStateObservable() {
    return mStateSubject.asObservable();
  }

  public int getState() {
    return mConnectionState;
  }

  protected synchronized void setState(int newState) {
    WearableLog.i("%s_StateChange:%d", mClsName,newState);
    if (newState < STATE_CONNECTED) {
      reset();
    }
    if (mConnectionState != newState) {
      mConnectionState = newState;
      mStateSubject.onNext(newState);
      RxBus.getInstance().post(new StateChangeEvent(this, newState));
    }
  }

  public Observable<Boolean> sendCommand(final BaseCommand command) {
    return sendCommand(command, TIMEOUT_COMMAND);
  }

  public Observable<Boolean> sendCommand(final BaseCommand command, final int timeout) {
    WearableLog.d("%s_send_command", mClsName);
    return Observable.create(new CommandOnSubscribe(command, timeout)).subscribeOn(mWorkScheduler);
  }

  private void notifyCommandLock() {
    WearableLog.d("%s_send_command_release_lock",mClsName);
    synchronized (mCommandLock) {
      mCommandLock.notify();
    }
  }

  private class CommandOnSubscribe implements Observable.OnSubscribe<Boolean> {

    private final int timeout;
    private final BaseCommand command;
    private CompositeSubscription mSubscriptions = new CompositeSubscription();

    private CommandOnSubscribe(BaseCommand command, int timeout) {
      this.command = command;
      this.timeout = timeout;
    }

    private void notifyAndUnsubscribe() {
      mSubscriptions.clear();
      notifyCommandLock();
    }

    @Override public void call(final Subscriber<? super Boolean> subscriber) {
      WearableLog.d("send_command_start:%s", command.getClass().getSimpleName());
      if (mConnectionState != STATE_CONNECTED) {
        WearableLog.w("device is not ready" + mConnectionState +" " + command.toString());
        subscriber.onError(new DeviceException("device not ready"));
      } else {

        RxBus.getInstance().post(command);
        mSubscriptions.add(RxBus.getInstance()
            .toObservable(BaseData.class)
            .filter(new Func1<BaseData, Boolean>() {
              @Override public Boolean call(BaseData returnData) {
                return command.isResponseData(returnData);
              }
            })
            .first()
            .observeOn(mCommandReturnScheduler)
            .subscribe(new Subscriber<BaseData>() {
              @Override public void onCompleted() {
                notifyAndUnsubscribe();
               subscriber.onCompleted();
              }

              @Override public void onError(Throwable e) {
                notifyAndUnsubscribe();
                WearableLog.e(e, e.getMessage());
                subscriber.onError(e);
              }

              @Override public void onNext(BaseData returnData) {
                WearableLog.d("send_command_return:%s", returnData.toString());
                if (!command.isOKResponse(returnData)) {
                  WearableLog.e(returnData.toString());
                  subscriber.onError(new DeviceException(returnData.toString()));
                } else {
                  subscriber.onNext(true);
                }
              }
            }));
        mSubscriptions.add(mStateSubject.asObservable().observeOn(mCommandReturnScheduler).
            subscribe(new Action1<Integer>() {
              @Override public void call(Integer state) {
                if (state < STATE_CONNECTED) {
                  notifyAndUnsubscribe();
                  WearableLog.w("connection_is_lost %s", command.getClass().getSimpleName());
                  subscriber.onError(new DeviceException("Not ready"));
                }
              }
            }));
        mSubscriptions.add(Observable.timer(timeout, TimeUnit.MILLISECONDS)
            .observeOn(mCommandReturnScheduler)
            .subscribe(new Action1<Long>() {
              @Override public void call(Long aLong) {
                notifyAndUnsubscribe();
                WearableLog.w("Timeout %s" , command.getClass().getSimpleName());
                subscriber.onError(new DeviceException("Time out"));
              }
            }));

        mSubscriptions.add(writeToDevice(command).subscribeOn(Schedulers.io())
            .observeOn(mCommandReturnScheduler)
            .subscribe(new Subscriber() {
              @Override public void onCompleted() {

              }

              @Override public void onError(Throwable e) {
                notifyAndUnsubscribe();
                subscriber.onError(e);
              }

              @Override public void onNext(Object o) {

              }
            }));

/*        subscriber.add(Subscriptions.create(new Action0() {
          @Override public void call() {
            notifyCommandLock();
          }
        }));*/
        synchronized (mCommandLock) {
          try {
            WearableLog.d("%s_send_command_waiting", mClsName);
            mCommandLock.wait();
            WearableLog.d("%s_send_command_completed", mClsName);
           // subscriber.onCompleted();
            mSubscriptions.clear();
          } catch (Exception e) {
            WearableLog.e(e, e.getMessage());
            e.printStackTrace();
            mSubscriptions.clear();
            subscriber.onError(e);
          }
        }
      }
    }
  }
}
