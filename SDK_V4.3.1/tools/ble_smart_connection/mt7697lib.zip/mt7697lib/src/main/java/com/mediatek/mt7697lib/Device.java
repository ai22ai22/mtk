package com.mediatek.mt7697lib;


import android.util.Pair;

import rx.Observable;

/**
 * Created by MTK40526 on 4/28/2016.
 */
public interface Device {
    enum BLEStatus{
        DISCONNECTED,
        CONNECTING,
        CONNECTED
    }
    public static final int FIELD_IP = 0x01;
    public static final int FIELD_SSID = 0x02;
    public static final int FIELD_CONNECTED = 0x03;
    //ble connect device
    void bleConnect();
    void bleDisconnect();

    Observable<BLEStatus> getBLEStatus();
    Observable requestWifiConnect(String ssid, String password);
    Observable<Pair<Integer,String>> wifiChange();


}
