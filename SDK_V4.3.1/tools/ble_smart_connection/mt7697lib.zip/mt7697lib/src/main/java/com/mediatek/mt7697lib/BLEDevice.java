package com.mediatek.mt7697lib;

import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;
import android.util.Pair;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import rx.Observable;
import rx.Subscriber;
import rx.functions.Func1;
import rx.subjects.PublishSubject;

/**
 * Created by MTK40526 on 4/28/2016.
 */
class BLEDevice implements Device {


    private final Context mContext;
    private final String mMacAddress;
    private final BroadcastReceiver mGattUpdateReceiver;
    private final ServiceConnection mServiceConnection;
    public PublishSubject<Pair<Integer, String>> mSubjectData = PublishSubject.create();
    private boolean mBind = false;
    private BluetoothLeService mBluetoothLeService;
    private PublishSubject<BLEStatus> mSubjectBLEStatus = PublishSubject.create();
    private BLEStatus mBleStatus = BLEStatus.DISCONNECTED;
    private Subscriber mWriteDataSubscriber;

    protected BLEDevice(Context context, String macAddress) {

        mContext = context;
        mMacAddress = macAddress;
        mServiceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName componentName, IBinder service) {
                mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
                mBind = true;
                if (!mBluetoothLeService.initialize()) {
                }
                // Automatically connects to the device upon successful start-up initialization.
                mBluetoothLeService.connect(mMacAddress);
            }

            @Override
            public void onServiceDisconnected(ComponentName componentName) {
                bleStatusChange(BLEStatus.DISCONNECTED);
                mBluetoothLeService = null;
                mBind = false;
            }
        };


        mGattUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                final String action = intent.getAction();
                if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                 //   bleStatusChange(BLEStatus.CONNECTED);
                } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED.equals(action)) {
                    bleStatusChange(BLEStatus.DISCONNECTED);
                } else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {
                    // Show all the supported services and characteristics on the user interface.

                    List<BluetoothGattService> gattServices =
                            mBluetoothLeService.getSupportedGattServices();
                    if (gattServices != null) {
                        for (BluetoothGattService gattService : gattServices) {
                            Log.v("gattService", gattService.getUuid().toString());
                            List<BluetoothGattCharacteristic> gattCharacteristics =
                                    gattService.getCharacteristics();
                            for (BluetoothGattCharacteristic gattCharacteristic : gattCharacteristics) {
                                Log.v("gattService", gattCharacteristic.getUuid().toString());
                                for (BluetoothGattDescriptor descriptor : gattCharacteristic.getDescriptors()) {
                                    Log.v("gattService", descriptor.getUuid().toString());
                                }
                                if (gattCharacteristic.getUuid()
                                        .toString()
                                        .equalsIgnoreCase(
                                                "00002aaa-0000-1000-8000-00805f9b34fb")) {
                                    bleStatusChange(BLEStatus.CONNECTED);
                                    BluetoothGattDescriptor descriptor = gattCharacteristic.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
                                    descriptor.setValue(new byte[]{0x02, 0x00});
                                    mBluetoothLeService.setCharacteristicNotification(gattCharacteristic, true);
                                    mBluetoothLeService.writeDescriptor(descriptor);
                                }
                            }
                        }
                    }

                    //  displayGattServices(mBluetoothLeService.getSupportedGattServices());
                } else if (BluetoothLeService.ACTION_DATA_AVAILABLE.equals(action)) {
                    //    displayData(intent.getStringExtra(BluetoothLeService.EXTRA_DATA));
                    byte[] bytes = intent.getByteArrayExtra(BluetoothLeService.EXTRA_DATA);
                    parserData(bytes);

                } else if (BluetoothLeService.EXTRA_CHARACTERISTIC_WRITE.equals(action)) {
                    if (mWriteDataSubscriber != null) {
                        int status = intent.getIntExtra("status", 999);
                        if (status != 0) {
                            mWriteDataSubscriber.onError(new Exception("Can not write to ble"));
                        } else {
                            mWriteDataSubscriber.onNext(intent.getIntExtra("status", 0));
                            mWriteDataSubscriber.onCompleted();
                        }
                    }
                }
            }
        };

    }

    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        intentFilter.addAction(BluetoothLeService.EXTRA_CHARACTERISTIC_WRITE);
        return intentFilter;
    }

    private String parseString(byte[] bytes) {
        byte[] strBytes = Arrays.copyOfRange(bytes, 2, bytes[1] + 2);
        return new String(strBytes);

    }

    private void parserData(byte[] bytes) {
        if (bytes != null && bytes.length > 0) {
            switch ((int) bytes[0]) {
                case 0x01:
                    mSubjectData.onNext(new Pair<Integer, String>(Device.FIELD_SSID, parseString(bytes)));
                    break;
                case 0x04:
                    mSubjectData.onNext(new Pair<Integer, String>(Device.FIELD_IP, parseString(bytes)));
                    break;
                case 0x07:
                    mSubjectData.onNext(new Pair<Integer, String>(Device.FIELD_CONNECTED, mContext.getString(R.string.disconnected)));
                    break;
                case 0x08:
                    mSubjectData.onNext(new Pair<Integer, String>(Device.FIELD_CONNECTED, mContext.getString(R.string.connected)));
                    break;
            }
        }
    }

    private void bleStatusChange(BLEStatus newStatus) {
        if (mBleStatus != newStatus) {
            mBleStatus = newStatus;
            mSubjectBLEStatus.onNext(newStatus);

        }
    }

    @Override
    public void bleConnect() {
        bleDisconnect();
        bleStatusChange(BLEStatus.CONNECTING);
        Intent gattServiceIntent = new Intent(mContext, BluetoothLeService.class);
        mContext.bindService(gattServiceIntent, mServiceConnection, mContext.BIND_AUTO_CREATE);
        mContext.registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
    }

    @Override
    public void bleDisconnect() {
        if (mBluetoothLeService != null) {
            bleStatusChange(BLEStatus.DISCONNECTED);
            mBluetoothLeService.disconnect();
            mBluetoothLeService = null;
        }
        try {
            mContext.unbindService(mServiceConnection);
            mContext.unregisterReceiver(mGattUpdateReceiver);
        } catch (IllegalArgumentException e) {

        }
    }

    @Override
    public Observable<BLEStatus> getBLEStatus() {
        return Observable.create(new Observable.OnSubscribe<BLEStatus>() {
            @Override
            public void call(final Subscriber<? super BLEStatus> subscriber) {
                subscriber.onNext(mBleStatus);
                mSubjectBLEStatus.subscribe(new Subscriber<BLEStatus>() {
                    @Override
                    public void onCompleted() {
                        subscriber.onCompleted();
                    }

                    @Override
                    public void onError(Throwable e) {
                        subscriber.onError(e);
                    }

                    @Override
                    public void onNext(BLEStatus bleStatus) {
                        subscriber.onNext(bleStatus);
                    }
                });
            }
        });
    }

    @Override
    public Observable requestWifiConnect(String ssid, String password) {
        WifiUtils.getInstance().init(mContext);

        int authMode = WifiUtils.getInstance().getAuthMode(ssid);
        int encryptMode = WifiUtils.getInstance().getEncryptMode(ssid);

        Charset charset = Charset.forName("US-ASCII");
        ssid = ("\1" + ((char) ssid.length()) + ssid);
        password = "\2" + ((char) password.length()) + password;

        String sm = "\3" + "\2" + ((char) authMode) + ((char) encryptMode);

        ArrayList<byte[]> byteList = new ArrayList<>();
        byteList.add(ssid.getBytes(charset));
        byteList.add(password.getBytes(charset));
        byteList.add(sm.getBytes(charset));
        return Observable.from(byteList).concatMap(new Func1<byte[], Observable<Object>>() {
            @Override
            public Observable call(byte[] bytes) {
                Log.v("writeCharacteristic", new String(bytes));
                return write(bytes);
            }
        });

    }

    @Override
    public Observable<Pair<Integer, String>> wifiChange() {
        return mSubjectData.asObservable();
    }


    private Observable write(final byte[] data) {

        return Observable.create(new Observable.OnSubscribe<Object>() {
            @Override
            public void call(Subscriber<? super Object> subscriber) {
                boolean isFound = false;
                mWriteDataSubscriber = subscriber;
                List<BluetoothGattService> gattServices =
                        mBluetoothLeService.getSupportedGattServices();
                for (BluetoothGattService gattService : gattServices) {
                    List<BluetoothGattCharacteristic> gattCharacteristics =
                            gattService.getCharacteristics();
                    for (BluetoothGattCharacteristic gattCharacteristic : gattCharacteristics) {
                        if (gattCharacteristic.getUuid()
                                .toString()
                                .equalsIgnoreCase(
                                        "00002aaa-0000-1000-8000-00805f9b34fb")) {
                            isFound = true;
                            gattCharacteristic.setValue(data);
                            if (!mBluetoothLeService.writeCharacteristic(gattCharacteristic)) {
                                subscriber.onError(new Exception("can not write to device"));
                            }
                        }
                    }
                }
                if (!isFound){
                    subscriber.onError(new Exception(mContext.getString(R.string.ble_not_ready)));
                }
            }
        });


    }
}
