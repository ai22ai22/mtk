package com.mediatek.mt7697lib;

import android.content.Context;

/**
 * Created by MTK40526 on 4/28/2016.
 */
public class DeviceFactory {
    public static Device createDevice(Context context, String macAddress){
        return new BLEDevice(context,macAddress);
    }
}
