package com.mediatek.mt7697lib;

import android.content.Context;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.util.Log;

import java.util.List;

class WifiUtils {
    private static WifiUtils instance;
    public WifiManager wifiManager;
    private Context mContext;
    private String mAuthString;

    private byte mAuthMode;
    private byte AuthModeOpen = 0x00;
    private byte AuthModeShared = 0x01;
    private byte AuthModeAutoSwitch = 0x02;
    private byte AuthModeWPA = 0x03;
    private byte AuthModeWPAPSK = 0x04;
    private byte AuthModeWPANone = 0x05;
    private byte AuthModeWPA2 = 0x06;
    private byte AuthModeWPA2PSK = 0x07;
    private byte AuthModeWPA1WPA2 = 0x08;
    private byte AuthModeWPA1PSKWPA2PSK = 0x09;
    private byte mEncryptMode;
    private byte EncryptModeWEP = 0x00;
    private byte EncryptModeOpen = 0x01;
    private byte EncryptModeTKIP = 0x04;
    private byte EncryptModeCCMP = 0x06;
    private byte EncryptModeTKIPCCMP = 0x08;


//    open --> 1
//    wep -->0
//    TKIP --> 4
//    CCMP -->6
//    TKIP+CCMP -->8
    private byte EncryptModeNoMatch = 0x63;
    private WifiUtils() {

    }

    public static synchronized WifiUtils getInstance() {
        if (instance == null) instance = new WifiUtils();
        return instance;
    }

    public void init(Context context) {
        mContext = context;
        wifiManager = (WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);
    }

    public String getSSID() {
        String mConnectedSsid = "";
        if (WifiUtils.getInstance().wifiManager.isWifiEnabled()) {
            mConnectedSsid = wifiManager.getConnectionInfo().getSSID();

            if (mConnectedSsid == null) {
                mConnectedSsid = wifiManager.getScanResults().get(0).SSID;
            }
            int iLen = mConnectedSsid.length();
            if (mConnectedSsid.startsWith("\"") && mConnectedSsid.endsWith("\"")) {
                mConnectedSsid = mConnectedSsid.substring(1, iLen - 1);
            }
        }
        return mConnectedSsid;
    }

    public String getAuthString() {
        String mConnectedSsid = getSSID();
        List<ScanResult> ScanResultlist = wifiManager.getScanResults();
        for (int i = 0, len = ScanResultlist.size(); i < len; i++) {
            ScanResult AccessPoint = ScanResultlist.get(i);

            if (AccessPoint.SSID.equals(mConnectedSsid)) {
                boolean WpaPsk = AccessPoint.capabilities.contains("WPA-PSK");
                boolean Wpa2Psk = AccessPoint.capabilities.contains("WPA2-PSK");
                boolean Wpa = AccessPoint.capabilities.contains("WPA-EAP");
                boolean Wpa2 = AccessPoint.capabilities.contains("WPA2-EAP");

                Log.d("test", "getAuthString AccessPoint.capabilities =" + AccessPoint.capabilities + ".");


                if (AccessPoint.capabilities.contains("WEP")) {
                    mAuthString = "OPEN-WEP";
                    mAuthMode = AuthModeOpen;
                    break;
                }

                if (WpaPsk && Wpa2Psk) {
                    mAuthString = "WPA-PSK WPA2-PSK";
                    mAuthMode = AuthModeWPA1PSKWPA2PSK;
                    break;
                } else if (Wpa2Psk) {
                    mAuthString = "WPA2-PSK";
                    mAuthMode = AuthModeWPA2PSK;
                    break;
                } else if (WpaPsk) {
                    mAuthString = "WPA-PSK";
                    mAuthMode = AuthModeWPAPSK;
                    break;
                }

                if (Wpa && Wpa2) {
                    mAuthString = "WPA-EAP WPA2-EAP";
                    mAuthMode = AuthModeWPA1WPA2;
                    break;
                } else if (Wpa2) {
                    mAuthString = "WPA2-EAP";
                    mAuthMode = AuthModeWPA2;
                    break;
                } else if (Wpa) {
                    mAuthString = "WPA-EAP";
                    mAuthMode = AuthModeWPA;
                    break;
                }

                mAuthString = "OPEN";
                mAuthMode = AuthModeOpen;

            }
        }

        Log.d("test", "Auth Mode = " + mAuthString + ".");

        return mAuthString;
    }

    public int getAuthMode(String ssid) {
        String mConnectedSsid = ssid;
        List<ScanResult> ScanResultlist = wifiManager.getScanResults();
        for (int i = 0, len = ScanResultlist.size(); i < len; i++) {
            ScanResult AccessPoint = ScanResultlist.get(i);

            if (AccessPoint.SSID.equals(mConnectedSsid)) {
                boolean WpaPsk = AccessPoint.capabilities.contains("WPA-PSK");
                boolean Wpa2Psk = AccessPoint.capabilities.contains("WPA2-PSK");
                boolean Wpa = AccessPoint.capabilities.contains("WPA-EAP");
                boolean Wpa2 = AccessPoint.capabilities.contains("WPA2-EAP");

                Log.d("test", "getAuthMode AccessPoint.capabilities =" + AccessPoint.capabilities + ".");


                if (AccessPoint.capabilities.contains("WEP")) {
                    mAuthString = "OPEN-WEP";
                    mAuthMode = AuthModeOpen;
                    break;
                }

                if (WpaPsk && Wpa2Psk) {
                    mAuthString = "WPA-PSK WPA2-PSK";
                    mAuthMode = AuthModeWPA1PSKWPA2PSK;
                    break;
                } else if (Wpa2Psk) {
                    mAuthString = "WPA2-PSK";
                    mAuthMode = AuthModeWPA2PSK;
                    break;
                } else if (WpaPsk) {
                    mAuthString = "WPA-PSK";
                    mAuthMode = AuthModeWPAPSK;
                    break;
                }

                if (Wpa && Wpa2) {
                    mAuthString = "WPA-EAP WPA2-EAP";
                    mAuthMode = AuthModeWPA1WPA2;
                    break;
                } else if (Wpa2) {
                    mAuthString = "WPA2-EAP";
                    mAuthMode = AuthModeWPA2;
                    break;
                } else if (Wpa) {
                    mAuthString = "WPA-EAP";
                    mAuthMode = AuthModeWPA;
                    break;
                }

                mAuthString = "OPEN";
                mAuthMode = AuthModeOpen;

            }
        }

        Log.d("test", "getAuthMode Auth Mode = " + mAuthMode + ".");

        return (int) mAuthMode;
    }

    public int getEncryptMode(String ssid) {
        String mConnectedSsid = ssid;
        List<ScanResult> ScanResultlist = wifiManager.getScanResults();
        for (int i = 0, len = ScanResultlist.size(); i < len; i++) {
            ScanResult AccessPoint = ScanResultlist.get(i);

            if (AccessPoint.SSID.equals(mConnectedSsid)) {

                mEncryptMode = EncryptModeNoMatch;

                Log.d("test", "getEncryptMode AccessPoint.capabilities = " + AccessPoint.capabilities + ".");

//                AccessPoint.capabilities= "[WEP][ESS]";

                if (AccessPoint.capabilities.contains("WEP")) {
                    mEncryptMode = EncryptModeWEP;
                }

                if (AccessPoint.capabilities.equals("[ESS]")) {
                    mEncryptMode = EncryptModeOpen;
                }

                if (AccessPoint.capabilities.contains("TKIP")) {
                    mEncryptMode = EncryptModeTKIP;
                }

                if (AccessPoint.capabilities.contains("CCMP")) {
                    mEncryptMode = EncryptModeCCMP;
                }

                if (AccessPoint.capabilities.contains("CCMP+TKIP")) {
                    mEncryptMode = EncryptModeTKIPCCMP;
                }

            }
        }

        Log.d("test", "getEncryptMode mEncryptMode = " + mEncryptMode + ".");

        return (int) mEncryptMode;
    }


}
